"""osk.update — 정본 릴리스를 인스턴스로 갱신 (하류 쪽).

구현 근거: Mechanism §1-2(정본과 갱신), 시행령 §10 6항(인스턴스는 갱신으로
정본 릴리스를 받아들이고, 비준증빙에 없는 것은 받지 않는다).

기본 동작은 **보고**다. 첫 `--apply`는 변경집합을 제시하고 거부한다.
사용자 명시 재승인 뒤 같은 변경집합의 재시도 한 번만 비대화형 적용한다.

축의 분리 — 데이터 동기화 데몬은 인스턴스 자신의 원격만 다루고(vault_sync),
갱신은 정본 저장소에서 프레임워크를 받는다. 두 축은 섞이지 않는다.

적용 범위는 릴리스 안의 발행 매니페스트가 정한다(별도 갱신 매니페스트 없음):
- MAP 대상 → 적용   - KEEP(정본 저장소 전용) → 건너뜀
- SKEL → 없는 자리에만 골격
그리고 무엇이 와도 **인스턴스 소유 바닥**(Mechanism §1-2 5항)에는 쓰지
않는다 — `00_Scope`·`00_Domain`·`00_Person`과 이름이 다른 같은 Space의 루트 아래(골격 제외)·`_ledger/`·`_raw/`·`_sources/`·
`.osk/`. 바닥은 매니페스트가 아니라 이 모듈의 상수다.

적용 규율 (Mechanism §1-2 6항):
- 직전 적용 상태(저널의 인과 극대)와 같은 파일 → 덮는다.
- 로컬 수정이 있는 파일 → 덮지 않는다. 문서는 `<이름>.upstream-<버전>`
  사본을 옆에 두어 표면화하고, **엔진 파일의 로컬 수정은 갱신 전체를
  중단한다** — 엔진을 고치는 자리는 정본이다.
- 기존 인스턴스의 최초 편입은 `--adopt`로 현재 릴리스를 기준선 삼는다.
"""
from __future__ import annotations
import argparse, base64, errno, json, os, re, shutil, signal, stat, subprocess, sys, tarfile, tempfile, time
from contextlib import contextmanager
from pathlib import Path

from .core import (ROOT, LEDGER, causal_maxima, ledger_append, ledger_damage,
                   ledger_read, resolve_one, sha256_file, sha256_bytes, posix_rel,
                   local_lock_path, SPACE_ROOTS, _within, _canon_rel)
from .core import mutation_lock_path as core_mutation_lock_path
from .core import fsync_dir as _fsync_dir, mkdirs_durable as _mkdirs_durable
from ._portalock import lock_exclusive, unlock
from .layout import KINDS, PREFIXES, adapt_path
from . import publish

UPDATE_JOURNAL = LEDGER / "update.jsonl"     # 운영 저널 — 권위 대장이 아니다
CONFIG = ROOT / ".osk" / "config.json"       # 인스턴스 소유 로컬 설정
TXN_DIR = ROOT / ".osk" / "txn"              # 크래시-안전 트랜잭션 영역(비동기화)
TXN_MANIFEST = TXN_DIR / "manifest.json"     # 존재 = 미완료 트랜잭션(복구 대상)
TXN_BACKUP = TXN_DIR / "backup"
DEFAULT_UPSTREAM = "https://github.com/lpaiu-cs/osk-system.git"
ATTESTATION = "release.json"
ENGINE_PREFIX = "_governance/_engine/"
VERSION_RE = r"^v\d+\.\d+\.\d+$"             # 릴리스·태그·자동 탐색이 공유하는 계약

# 인스턴스 소유 바닥 — 릴리스·매니페스트가 무엇을 말하든 쓰지 않는다.
# (골격 .gitkeep은 디렉터리가 없을 때만 예외 — _skel에서 별도 처리)
SKEL_ROOTS = tuple(prefix + kind for prefix in PREFIXES for kind in KINDS)
FLOOR_HEADS = SKEL_ROOTS + ("_ledger", "_raw", "_sources", ".osk", ".git")


class UpdateError(RuntimeError):
    """갱신 중단 — 인스턴스에 아무것도 쓰지 않는다."""


def _floor(rel: str) -> bool:
    head = rel.split("/", 1)[0]
    if head in FLOOR_HEADS:
        return True
    return any(f"/{seg}/" in f"/{rel}" for seg in ("_ledger", "_raw"))


# 골격을 만들어도 되는 곳은 **최상위 Space 루트 셋**뿐이다. 그 아래는 전부
# 인스턴스 소유 바닥이므로, `SKEL Scope/UserData/newdir` 같은 지시는 사용자
# 영역에 디렉터리를 만들게 된다 — 접두만 보지 않고 정확히 이 셋만 허용한다.
def _allowed_skel(s: str) -> Path | None:
    """SKEL이 만들어도 되는 절대 경로 — 아니면 None. 골격은 **루트 안으로
    봉쇄된 최상위 Space 루트**만 만든다(Mechanism §1-2 5항의 바닥은 매니페스트가
    무엇을 말하든 지켜진다). `../` 탈출·하위 경로·비Space 경로는 거부."""
    if s not in SKEL_ROOTS:
        return None
    s = adapt_path(s, SPACE_ROOTS)
    p = _within(ROOT, s)                         # `..`·절대경로·심볼릭 탈출은 None
    if p is None:
        return None
    try:
        parts = p.relative_to(Path(os.path.realpath(ROOT))).parts
    except ValueError:
        return None
    if len(parts) != 1 or parts[0] not in SPACE_ROOTS.values():
        return None                              # 최상위 Space 루트만 골격 대상
    return p


def load_config() -> dict:
    if CONFIG.exists():
        try:
            return json.loads(CONFIG.read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            raise UpdateError(f"로컬 설정 판독 실패 {CONFIG}: {e}")
    return {"upstream": {"source": "git", "url": DEFAULT_UPSTREAM, "pin": None}}


# ── 출처 — 전송만 다르고 검증은 같다 (Mechanism §1-2 3항) ────────────────

def _semver(tag) -> tuple[int, int, int] | None:
    """`vX.Y.Z`(VERSION_RE)의 정수 세 쌍 — 그 형식이 아니면 None. 판본의 순서는
    문자열이 아니라 이 값으로 잰다(`v4.10.0`이 `v4.9.0`보다 새롭다)."""
    m = re.fullmatch(r"v(\d+)\.(\d+)\.(\d+)", tag) if isinstance(tag, str) else None
    return tuple(int(g) for g in m.groups()) if m else None


def latest_release_tag(url: str, *, timeout: float = 60,
                       unattended: bool = False) -> str | None:
    """정본의 정식 릴리스 태그 중 최신 semver(`vX.Y.Z`) — 없으면 None.
    갱신의 기본은 브랜치 HEAD가 아니라 태그다(Mechanism §1-2 3항) — HEAD를
    받으면 릴리스 이후의 개발 커밋이 딸려 와 attestation과 어긋난다.

    `unattended`는 사람이 없는 확인(`update_check`의 분리 프로세스)이다.
    - 사람에게 묻지 않는다. 저장된 자격 증명은 쓰되, 없으면 조회 실패로 끝난다.
      git은 터미널에 묻기 전에 `GIT_ASKPASS`, `core.askPass`, `SSH_ASKPASS` 순으로
      인증 도우미를 띄우므로 `GIT_TERMINAL_PROMPT=0`만으로는 창이 뜬다. 두 환경
      변수를 걷어 내고 `-c core.askPass=`로 빈 도우미를 준다. git은 빈 도우미를
      실행하지 않고 `SSH_ASKPASS`로 넘어가지도 않는다. Git Credential Manager는
      `GCM_INTERACTIVE=never`면 창을 띄우지 않는다.
    - Windows에서 콘솔 창을 만들지 않는다. 창 없는 부모가 콘솔 프로그램인 git을
      띄우면 Windows가 새 콘솔을 할당한다(vault_sync가 데몬의 검은 창을 막는 규율).
    - 출력은 파이프가 아니라 임시 파일로 받는다. Windows의 `subprocess.run`은 시한을
      넘긴 자식을 죽인 뒤 파이프를 시한 없이 다시 비우는데, git이 남긴 손자(자격 증명
      도우미)가 파이프를 쥐면 그 대기가 끝나지 않는다 — overview 무기한 행과 같은
      경로다. 끝나지 않는 확인은 확인 잠금을 영영 쥔다."""
    query = ["ls-remote", "--tags", "--refs", url]
    if unattended:
        code, stdout, stderr = git_unattended(query, timeout=timeout)
    else:
        r = subprocess.run(["git", *query], capture_output=True, text=True, timeout=timeout)
        code, stdout, stderr = r.returncode, r.stdout, r.stderr
    if code != 0:
        raise UpdateError(f"정본 태그 조회 실패({url}): {stderr.strip()[-200:]}")
    best = None
    for line in stdout.splitlines():
        name = line.rsplit("refs/tags/", 1)[-1].strip()
        key = _semver(name)
        if key and (best is None or key > best[0]):
            best = (key, name)
    return best[1] if best else None


def git_unattended(args: list[str], *, timeout: float) -> tuple[int, str, str]:
    """사람에게 묻지 않는 git — (종료코드, 표준 출력, 표준 오류). 규율은
    `latest_release_tag`의 `unattended`와 같다(인증 도우미·창·파이프)."""
    env = {k: v for k, v in os.environ.items() if k not in ("GIT_ASKPASS", "SSH_ASKPASS")}
    env.update(LC_ALL="C", LANG="C", GIT_TERMINAL_PROMPT="0", GCM_INTERACTIVE="never")
    with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
        r = subprocess.run(
            ["git", "-c", "core.askPass=", *args], stdin=subprocess.DEVNULL,
            stdout=out, stderr=err, timeout=timeout, env=env,
            creationflags=0x08000000 if os.name == "nt" else 0)
        out.seek(0)
        err.seek(0)
        return (r.returncode, out.read().decode("utf-8", "replace"),
                err.read().decode("utf-8", "replace"))


def tag_exists(url: str, tag: str) -> bool:
    """정본에 `refs/tags/<tag>`가 실제로 있는가 — 명시 ref가 브랜치로
    릴리스 경계를 우회하는 것을 막는다(`--branch`는 태그·브랜치 모두 받는다)."""
    r = subprocess.run(["git", "ls-remote", "--tags", "--refs", url,
                        f"refs/tags/{tag}"], capture_output=True, text=True,
                       timeout=60)
    return r.returncode == 0 and bool(r.stdout.strip())


def fetch_git(url: str, tag: str, dest: Path) -> Path:
    """정본의 그 **태그가 가리키는 정확한 커밋**을 얕게 받는다. `clone --branch`는
    동명 브랜치(`refs/heads/<tag>`)를 대신 고를 수 있으므로 쓰지 않는다 —
    `refs/tags/<tag>`를 명시 fetch해 FETCH_HEAD(태그의 peeled 커밋)에 detached
    checkout한다. 이렇게 해야 태그 경계가 브랜치로 우회되지 않는다."""
    d = dest / "tree"
    def _g(*a, **k):
        r = subprocess.run(["git", *a], capture_output=True, text=True,
                           timeout=300, **k)
        if r.returncode != 0:
            raise UpdateError(f"정본 fetch 실패({url} {tag}): "
                              f"{r.stderr.strip()[-300:]}")
        return r
    _g("init", "-q", str(d))
    # 체크아웃 바이트를 **인스턴스의 git 설정에서 떼어 낸다.** 증빙의 해시는
    # 정본이 git object(LF)에서 뜬 값인데, 임시 저장소는 전역·시스템 설정을
    # 물려받으므로 `core.autocrlf=true`(Git for Windows 설치 기본값)인 기기에서는
    # 체크아웃이 CRLF가 되어 **모든 텍스트 파일이 해시 불일치**로 중단된다 —
    # 메시지가 "해시 불일치"라 위조·손상으로 오인된다(실측: 루트 파일 6개).
    # 로컬 설정이 전역·시스템을 이기므로 여기서 못박으면 기기와 무관해진다.
    _g("-C", str(d), "config", "core.autocrlf", "false")
    _g("-C", str(d), "config", "core.eol", "lf")
    _g("-C", str(d), "fetch", "-q", "--depth", "1", url,
       f"refs/tags/{tag}")                        # FETCH_HEAD = 태그의 커밋
    _g("-C", str(d), "checkout", "-q", "--detach", "FETCH_HEAD")
    return d


def fetch_bundle(src: str, dest: Path) -> Path:
    """로컬 반입 — 디렉터리 또는 tar(.tar/.tar.gz/.tgz). **snapshot**을 만든다:
    디렉터리 bundle을 원본 그대로 반환하면 검증 후 write 때까지 같은 파일을 다시
    읽어 TOCTOU가 열린다(검증 직후 원본이 바뀌면 미검증 bytes 적용). tar처럼
    temp tree로 복사해, 이후 검증·plan·write가 전부 이 snapshot만 보게 한다."""
    p = Path(src).expanduser()
    if p.is_dir():
        out = dest / "tree"
        shutil.copytree(p, out, symlinks=True,   # symlink는 보존 → _within이 거른다
                        ignore=shutil.ignore_patterns(".git", "__pycache__"))
        return out
    if p.is_file() and p.suffix in (".tar", ".gz", ".tgz"):
        out = dest / "tree"
        out.mkdir()
        with tarfile.open(p) as tf:
            tf.extractall(out, filter="data")   # 경로 탈출 차단
        inner = [d for d in out.iterdir() if d.is_dir()]
        return inner[0] if len(inner) == 1 and not any(
            f.is_file() for f in out.iterdir()) else out
    raise UpdateError(f"bundle이 아니다(디렉터리·tar만): {src}")


# ── 비준증빙 대조 ────────────────────────────────────────────────────────

def load_release(tree: Path) -> dict:
    ap = tree / ATTESTATION
    if not ap.exists():
        raise UpdateError("정본 릴리스가 아니다 — 비준증빙(release.json)이 없다"
                          " (시행령 §10 6항)")
    try:
        rel = json.loads(ap.read_text(encoding="utf-8"))
    except ValueError as e:
        raise UpdateError(f"비준증빙 판독 실패: {e}")
    if not isinstance(rel.get("files"), dict) or not rel.get("version"):
        raise UpdateError("비준증빙 형식 위반 — version·files가 필요하다")
    if not re.match(VERSION_RE, str(rel["version"])):
        raise UpdateError(f"비준증빙 version 형식 위반(vX.Y.Z): {rel['version']}")
    return rel


def verify_attestation(tree: Path, rel: dict) -> list[str]:
    """전수 대조 — 증빙의 파일이 다 있고 해시가 맞다. 적용은 오직 증빙이
    모는 파일(`rel["files"]`)만 하고 그 하나하나를 해시로 검증하므로, 증빙
    밖에 있는 디스크 파일은 적용 자체가 되지 않는다 — 트리에 딸린 미추적
    부산물(pyc·.DS_Store)로 갱신을 막지 않는다(그건 안전이 아니라 오탐이다).

    증빙 key는 신뢰 밖 입력이다 — I/O 전에 tree 안으로 봉쇄한다(경로 탈출 차단)."""
    errs = []
    for p, h in sorted(rel["files"].items()):
        f = _within(tree, p)
        if f is None:
            errs.append(f"증빙 경로가 트리 밖으로 벗어난다(경로 봉쇄 실패): {p}")
        elif not f.is_file():
            errs.append(f"증빙의 파일이 없다: {p}")
        elif sha256_file(f) != h:
            errs.append(f"해시 불일치: {p}")
    return errs


# ── 적용 집합 — 릴리스 안의 발행 매니페스트가 정한다 ─────────────────────

def _map_dest(ap: str, man: dict) -> str | None:
    """증빙 경로(정본 source)를 발행 매니페스트 MAP으로 인스턴스 경로에 사상한다
    — publish.collect과 같은 `src/a -> dst/a` 사상이다(dst-prefix 매칭이 아니라).
    비항등 MAP도 올바로 반영하고, 어느 MAP에도 안 걸리면 None(매니페스트 밖)."""
    for s, d in man["map"]:
        if not s.endswith("/"):
            if ap == s:
                return d
        elif ap.startswith(s.rstrip("/") + "/"):
            return d.rstrip("/") + "/" + ap[len(s.rstrip("/")) + 1:]
    return None


def apply_set(tree: Path, rel: dict):
    """((source, dest) 사상 목록, 골격 절대경로 목록, 건너뜀 보고).
    KEEP은 정본 저장소 전용이라 제외. dest는 floor·루트 봉쇄를 통과한 것만."""
    man_rel = "_governance/_engine/scripts/publish-manifest.txt"
    # 매니페스트는 적용 범위를 정하는 **control plane**이다. 증빙 밖 파일은
    # 적용 대상이 아니지만(허용), 그런 파일이 증빙된 bytes의 목적지·정책을
    # 지배해서는 안 된다 — 반드시 증빙에 있고 이미 해시 검증된 것이어야 한다.
    if man_rel not in rel["files"]:
        raise UpdateError(
            f"발행 매니페스트가 비준증빙에 없다 — 적용 범위를 신뢰할 수 없다: "
            f"{man_rel}")
    man_path = tree / man_rel
    if not man_path.exists():
        raise UpdateError("릴리스에 발행 매니페스트가 없다 — 적용 범위 불명")
    man = publish.parse_manifest(man_path)
    keep = set(man["keep"])
    targets, skipped = [], []
    for ap in sorted(rel["files"]):
        if ap in keep or ap == ATTESTATION:
            skipped.append(f"{ap} (정본 저장소 전용)")
            continue
        if publish._denied(ap, man["deny"]):
            skipped.append(f"{ap} (DENY)")
            continue
        dest = _map_dest(ap, man)
        if dest is None:
            skipped.append(f"{ap} (매니페스트 밖)")
            continue
        # dest는 신뢰 밖 입력에서 파생된다 — canonical 경로로 봉쇄한 뒤 그
        # canonical에 floor를 건다(정규화 전 문자열 판정 우회 차단, P1).
        cdest = _canon_rel(ROOT, dest)
        if cdest is None or _floor(cdest):
            skipped.append(f"{dest} (바닥·경로 봉쇄 — 쓰지 않는다)")
            continue
        targets.append((ap, cdest))
    # SKEL은 허용 골격(루트 봉쇄된 빈 Space 루트)만 통과시킨다
    skel = []
    for s in man["skel"]:
        d = _allowed_skel(s.rstrip("/"))
        if d is None:
            skipped.append(f"{s} (SKEL 허용 밖 — 쓰지 않는다)")
        else:
            skel.append(d)
    return targets, skel, skipped


# ── 저널 — 직전 적용 상태의 정본 ─────────────────────────────────────────

def _done_txns(recs: list[dict]) -> set:
    return {r.get("txn") for r in recs
            if r.get("kind") == "done" and r.get("txn")}


def _is_committed(r: dict, done: set) -> bool:
    """`done`이 그 트랜잭션의 커밋 지점이다(Mechanism §1-2 7항). 커밋 전에 죽어
    남은 `apply`/`remove`는 파일이 pre-image로 복구되므로 상태의 후보가 아니다.
    `txn`이 없는 유산 기록은 그대로 후보다(호환 경계)."""
    return not r.get("txn") or r["txn"] in done


def committed(recs: list[dict]) -> list[dict]:
    """커밋된 기록만 남긴 목록 — **존재 검사 전용**(has_history). 인과 판정에는
    쓰지 않는다: 목록에서 빼면 그 기록이 잇던 parents 간선도 끊겨 남은 기록들이
    거짓 분기가 된다. 판정은 `causal_maxima(..., candidate=...)`로 후보만
    제한한다."""
    done = _done_txns(recs)
    return [r for r in recs if _is_committed(r, done)]


def _committed_maximum(recs: list[dict], rel_path: str) -> dict | None:
    """그 경로의 **커밋된 기록 중 인과 극대**. 조상 관계는 전체 저널의 DAG로
    계산한다(미커밋 기록이 사슬을 끊지 않게).

    극대가 여럿이어도 그것들이 **같은 최종 상태**(kind·hash 동일)를 말하면
    동치로 수렴시킨다 — 다기기가 같은 릴리스를 각각 정상 적용한 뒤 저널이
    union 병합되면 값이 같은 병렬 극대가 생기는데, 그걸 미확정으로 보면
    baseline이 사라져 멀쩡한 파일이 전부 drift로 오판된다. 값이 실제로 갈리는
    경우만 미확정(None)이다."""
    done = _done_txns(recs)
    m = causal_maxima(recs, rel_path, None, "path",
                      candidate=lambda r: _is_committed(r, done))
    if len(m) == 1:
        return m[0]
    if m and all((r.get("kind"), r.get("hash"))
                 == (m[0].get("kind"), m[0].get("hash")) for r in m):
        return m[0]
    return None


def last_applied_hash(recs: list[dict], rel_path: str) -> str | None:
    r = _committed_maximum(recs, rel_path)
    return r.get("hash") if r and r.get("kind") == "apply" else None


def managed_paths(recs: list[dict]) -> dict[str, str]:
    """지금 이 인스턴스가 정본으로부터 관리 중인 경로 → 기준선 해시.
    경로별(커밋된) 인과 극대가 `apply`면 관리 중, `remove`면 삭제됨
    (last_applied_hash와 같은 규율). 삭제 전파의 '직전 관리 집합'이 여기서 나온다."""
    out = {}
    for p in {r.get("path") for r in recs if r.get("path")}:
        r = _committed_maximum(recs, p)
        if r and r.get("kind") == "apply":
            out[p] = r.get("hash")
    return out


def current_version(recs: list[dict] | None = None) -> str | None:
    """현재 판본 — `done` 기록의 **인과 극대**(물리 마지막 행이 아니다).
    update.jsonl은 union 병합되는 대장이므로 파일 순서는 정본이 아니다
    (core 판정 계약 · sibling `last_applied_hash`와 같은 규율). 병렬 극대도
    version과 릴리스 증빙 해시(attest)가 모두 같으면 같은 판본이다. 증빙 없는
    구판 기록은 유일 극대일 때만 읽고, 동치를 증명할 수 없는 분기는 None."""
    recs = ledger_read(UPDATE_JOURNAL) if recs is None else recs
    maxima = causal_maxima(recs, "done", field="kind")
    if len(maxima) <= 1:
        return maxima[0].get("version") if maxima else None
    version, attest = maxima[0].get("version"), maxima[0].get("attest")
    if (isinstance(version, str) and version and isinstance(attest, str)
            and re.fullmatch(r"sha256:[0-9a-f]{64}", attest)
            and all((r.get("version"), r.get("attest")) == (version, attest)
                    for r in maxima)):
        return version
    return None


def has_history(recs: list[dict] | None = None) -> bool:
    """이 인스턴스가 이미 갱신 관리 이력을 가졌는가 — **커밋된** apply·remove·
    done 중 하나라도 있으면 참. adopt(최초 편입)의 허용 판정에 쓴다. 커밋 전에
    죽어 남은 기록으로 adopt가 막히면 복구가 불가능해지므로 committed로 본다."""
    recs = committed(ledger_read(UPDATE_JOURNAL) if recs is None else recs)
    return any(r.get("kind") in ("apply", "remove", "done") for r in recs)


# ── 크래시-안전 트랜잭션 (Mechanism §1-2 7항) ────────────────────────────
#
# 프로토콜 — 파일과 저널을 **하나의 txn id**로 묶는다:
#   ①pre-image 백업 fsync → ②manifest(txn) 원자 기록·fsync  ← 트랜잭션 시작
#   ③저널 begin(txn) → ④파일 조작 → ⑤저널 apply/remove(txn) → ⑥저널 done(txn)
#   ⑦manifest 제거                                            ← 트랜잭션 종료
# 복구 판정은 결정적이다: manifest의 txn이 저널에 `done`이면 **roll-forward**
# (파일은 이미 새 판이므로 manifest만 정리), 없으면 **rollback**(pre-image 복구).
# 커밋 전 apply/remove는 `committed()`가 판정에서 가린다 — 파일과 저널이 어긋나지
# 않는 이유다. 복구 실패는 fail-closed로 백업을 보존한 채 중단한다.

def _fsync_file(p: Path) -> None:
    """파일의 메타데이터까지 내구화 — `chmod` 뒤 fsync하지 않으면 내용은
    복구됐는데 권한 변경만 유실될 수 있다.

    핸들은 **쓰기 가능**으로 연다. Windows CRT는 읽기 전용 핸들에 `_commit`을
    허용하지 않아 `O_RDONLY`로 열면 `os.fsync`가 `EBADF`를 낸다(실측: O_RDONLY
    → errno 9, O_RDWR → OK). 이 함수를 부르는 유일한 자리가 롤백 루프이므로,
    그 EBADF는 **모든 롤백을 첫 파일에서 중단**시켜 half-applied를 영구
    고착시켰다 — 정상 경로는 여기 오지 않아 드러나지 않았다.

    핸들을 못 얻으면 조용히 넘긴다. 내구화는 최선 노력이고, 그 실패로 이미
    복구된 내용을 되돌리는 것이 더 나쁘다 — `_fsync_dir`이 EACCES·EPERM에
    쓰는 규율과 같다."""
    try:
        fd = os.open(str(p), os.O_RDWR)
    except OSError:
        return          # 읽기 전용·부재 — 내구화할 핸들이 없다
    try:
        os.fsync(fd)
    except OSError as e:
        if e.errno not in (errno.EINVAL, errno.ENOTSUP, errno.EBADF,
                           errno.EACCES):
            raise
    finally:
        os.close(fd)


def _fsync_journal_home() -> None:
    """저널 파일의 **디렉터리 엔트리**를 내구화한다. `ledger_append`가 처음
    만든 대장의 엔트리를 내구화하지만, 직전 실행이 행 fsync 직후·엔트리 내구화
    전에 죽었으면 이름 자체가 전원 차단에 유실될 수 있다 — 그 상태에서 트랜잭션
    표식까지 지우면 파일은 새 판인데 baseline·관리 이력이 통째로 사라진다. ROOT
    까지 조상을 함께 내구화한다(대장 구획도 이번에 생겼을 수 있다)."""
    d = UPDATE_JOURNAL.parent
    root_real = Path(os.path.realpath(ROOT))
    while True:
        _fsync_dir(d)
        if Path(os.path.realpath(d)) == root_real or d.parent == d:
            break
        d = d.parent


def _planned_dirs(rels: list[str]) -> list[str]:
    """이 트랜잭션이 새로 만들 수 있는 디렉터리(canonical 상대, 얕은 순).
    manifest에 미리 담아 두면 rollback이 **비어 있는 것만** 되돌릴 수 있다 —
    SKEL은 디렉터리 존재 자체가 적용 결과이므로 잔재로 남겨서는 안 된다."""
    out: set[str] = set()
    root_real = Path(os.path.realpath(ROOT))
    for rel in rels:
        p = (ROOT / rel).parent
        while True:
            try:
                cp = p.relative_to(ROOT)
            except ValueError:
                break
            if not cp.parts or p.exists() or Path(os.path.realpath(p)) == root_real:
                break
            out.add(cp.as_posix())
            p = p.parent
    return sorted(out, key=lambda s: (s.count("/"), s))


def _txn_clear() -> None:
    """트랜잭션 영역을 지운다. 정리도 상태 전이의 일부이므로 **성공을 확인**한다 —
    표식이 남으면 데몬이 모든 tick을 거부하고 다음 갱신이 남은 백업과 충돌한다."""
    if TXN_DIR.exists():
        shutil.rmtree(TXN_DIR, ignore_errors=True)
    if TXN_DIR.exists() or TXN_MANIFEST.exists():
        raise UpdateError(
            f"트랜잭션 영역 정리 실패 — 수동 개입 필요(권한·파일시스템 확인): "
            f"{TXN_DIR}")
    _fsync_dir(TXN_DIR.parent if TXN_DIR.parent.exists() else ROOT)


def _txn_begin(txn: str, version: str, touch: list[str]) -> None:
    """건드릴 파일(canonical ROOT-상대 경로)의 pre-image를 영속 백업·fsync한 뒤
    manifest를 원자 기록한다. manifest 기록이 트랜잭션 시작의 커밋 지점이므로,
    그 전에 죽으면 target은 아직 손대지 않은 상태다. 경로는 절대경로로 굳히지
    않는다 — 복구 시 다시 봉쇄·정체성 검증하기 위해 canonical 상대로 남긴다."""
    _txn_clear()
    # `.osk/`까지 처음 만들 수 있다 — 만든 각 디렉터리의 부모(최상단은 ROOT)를
    # 내구화해야 target은 남고 복구 표식만 유실되는 창이 닫힌다.
    _mkdirs_durable(TXN_BACKUP)
    entries = []
    for i, rel in enumerate(touch):
        key = f"{i:06d}"
        p = ROOT / rel
        existed = p.is_file()
        h = mode = None
        if existed:
            mode = stat.S_IMODE(p.stat().st_mode)   # 권한도 pre-image의 일부다
            data = p.read_bytes()
            bp = TXN_BACKUP / key
            _write_atomic(bp, data)              # 백업 자체도 fsync된다
            h = sha256_file(bp)
        entries.append({"rel": rel, "backup": key, "existed": existed,
                        "hash": h, "mode": mode})
    _fsync_dir(TXN_BACKUP)
    _write_atomic(TXN_MANIFEST, json.dumps(
        {"txn": txn, "version": version, "entries": entries,
         "dirs": _planned_dirs(touch)},           # rollback이 되돌릴 새 디렉터리
        ensure_ascii=False).encode())
    _fsync_dir(TXN_DIR)


def _journal_lenient() -> list[dict]:
    """**복구 판정 전용** 관대한 판독 — 판독 가능한 행만 모은다.

    크래시가 저널 append 도중이었으면 부분 JSON 행이 남는데, 엄격 판독
    (`ledger_read`)은 거기서 즉시 실패한다. 그러면 트랜잭션 표식이 남은 바로
    그 상황에서 복구에 도달하지 못한다 — 복구 판정에 필요한 것은 `done(txn)`의
    존재 여부뿐이므로, 그 판정만 관대하게 하고 저널의 엄격 검증은 복구 뒤
    정상 경로에 맡긴다(독립 `recover.py`와 같은 규율)."""
    if not UPDATE_JOURNAL.exists():
        return []
    out = []
    for line in UPDATE_JOURNAL.read_text(encoding="utf-8",
                                         errors="ignore").split("\n"):
        line = line.strip()
        if not line:
            continue
        try:
            r = json.loads(line)
        except ValueError:
            continue                    # 부분 행 — 복구 판정에서 건너뛴다
        if isinstance(r, dict):
            out.append(r)
    return out


def _txn_pending() -> dict | None:
    """미완료(또는 미정리) 트랜잭션 manifest — 없으면 None. 판독 실패는 손상이며
    **지우지 않는다**(유일한 복구 자료다) — 호출부가 fail-closed로 중단한다."""
    if not TXN_MANIFEST.is_file():
        return None
    try:
        man = json.loads(TXN_MANIFEST.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise UpdateError(
            f"트랜잭션 manifest 손상 — 자동 복구 불가, 수동 개입 필요: {e} "
            f"(백업은 {TXN_DIR} 에 보존했다)")
    if not isinstance(man.get("entries"), list) or not man.get("txn"):
        raise UpdateError(
            f"트랜잭션 manifest 형식 위반 — 수동 개입 필요 (보존: {TXN_DIR})")
    return man


def _txn_recover(recs: list[dict]) -> str | None:
    """미완료 트랜잭션을 결정적으로 처리한다 — 'rollback'|'roll-forward'|None.

    저널에 그 txn의 `done`이 있으면 커밋된 것이므로 파일은 새 판이 정답이고
    manifest만 정리한다(roll-forward). 없으면 pre-image로 되돌린다(rollback).
    복구 대상 경로는 다시 봉쇄·정체성 검증하며, 하나라도 되돌리지 못하면
    백업을 보존한 채 중단한다(fail-closed)."""
    man = _txn_pending()
    if man is None:
        return None
    txn = man["txn"]
    if any(r.get("kind") == "done" and r.get("txn") == txn for r in recs):
        # 커밋됨 — 파일은 그대로 둔다. 다만 직전 실행이 `done` 기록 직후·저널
        # 홈 내구화 **전에** 죽었을 수 있으므로, 그 내구화를 여기서 재시도한
        # 뒤에만 표식을 지운다(안 그러면 누락된 fsync가 영영 재시도되지 않는다).
        _fsync_journal_home()
        _txn_clear()
        return "roll-forward"
    for e in man["entries"]:
        rel = e.get("rel")
        cp = _canon_rel(ROOT, str(rel)) if rel else None
        if cp is None:
            raise UpdateError(
                f"복구 경로가 봉쇄·정체성 검증에 실패했다 — 중단(보존: {TXN_DIR}): {rel}")
        p = ROOT / cp
        try:
            if e.get("existed"):
                bp = TXN_BACKUP / str(e.get("backup"))
                if not bp.is_file():
                    raise UpdateError(
                        f"백업이 없다 — 복구 불가, 수동 개입 필요: {rel}")
                if e.get("hash") and sha256_file(bp) != e["hash"]:
                    raise UpdateError(
                        f"백업이 손상됐다 — 복구 불가, 수동 개입 필요: {rel}")
                _write_atomic(p, bp.read_bytes())
                # 삭제됐던 파일은 대상이 없어 _write_atomic이 기본 권한을 쓴다 —
                # pre-image의 권한을 명시 복원해야 복구가 완전해진다.
                if e.get("mode") is not None:
                    os.chmod(p, int(e["mode"]))
                    _fsync_file(p)       # 권한 변경도 내구화한 뒤 표식을 지운다
            else:
                p.unlink(missing_ok=True)
                _fsync_dir(p.parent)
        except OSError as ex:
            raise UpdateError(
                f"복구 실패 — 중단(백업 보존: {TXN_DIR}): {rel} {ex}")
    # 파일을 되돌린 뒤, 이 트랜잭션이 만든 디렉터리 중 **비어 있는 것만** 깊은
    # 순서로 제거한다 — SKEL은 디렉터리 존재 자체가 적용 결과라 잔재로 남으면
    # 'pre-image로 복구'가 성립하지 않는다. 비어 있지 않으면(사용자 파일 등) 둔다.
    for rel in sorted(man.get("dirs") or [], key=lambda s: -s.count("/")):
        cp = _canon_rel(ROOT, str(rel))
        if cp is None:
            raise UpdateError(                   # 경로 정체성이 바뀌었다 — 중단
                f"복구 대상 디렉터리가 봉쇄·정체성 검증에 실패했다 "
                f"— 중단(보존: {TXN_DIR}): {rel}")
        d = ROOT / cp
        try:
            d.rmdir()
        except OSError as ex:
            # 허용하는 것은 둘뿐이다: 이미 없다(ENOENT), 사용자 파일이 생겨
            # 비어 있지 않다(ENOTEMPTY/EEXIST). 권한·I/O 오류는 복구 실패이므로
            # 파일 복구와 같은 규율로 fail-closed한다.
            if ex.errno in (errno.ENOENT, errno.ENOTEMPTY, errno.EEXIST):
                continue
            raise UpdateError(
                f"디렉터리 복구 실패 — 중단(백업 보존: {TXN_DIR}): {cp} {ex}")
        _fsync_dir(d.parent)
    _txn_clear()
    return "rollback"


@contextmanager
def _exclusive(path: Path, busy: str):
    """비차단 배타 잠금 — 경합이면 `busy` 사유로 중단한다. **획득한 경우에만**
    해제한다(소유하지 않은 구간의 unlock은 Windows에서 실제 해제 연산이라
    원래 결과를 덮는 오류를 낸다)."""
    f = open(path, "w")
    ok = False
    try:
        try:
            lock_exclusive(f, blocking=False)
            ok = True
        except OSError:
            raise UpdateError(busy)
        yield
    finally:
        if ok:
            unlock(f)
        f.close()


def _sync_lock_path() -> Path:
    """엔진·데몬과 **공유하는 mutation 잠금** — 데몬 싱글턴 잠금이 아니다.
    노드 쓰기·보호영역 조작·데몬의 working-tree 구간이 모두 이 하나를 잡으므로,
    update가 이걸 잡으면 그 사이 누구도 혼합 상태를 만들거나 커밋·push하지
    못한다. 자리의 정의는 엔진에 한 벌뿐이다(core.mutation_lock_path)."""
    return core_mutation_lock_path()


DAEMON_RESTART_WAIT = 30   # 초 — 멈춘 데몬이 다시 보일 때까지 기다리는 한도


def _daemon_script() -> Path:
    return ROOT / "_governance" / "_engine" / "sync_daemon.py"


def _powershell(script: str) -> str:
    """인용 규칙을 거치지 않도록 EncodedCommand로 넘기고 UTF-8로 받는다."""
    code = "[Console]::OutputEncoding = [Text.Encoding]::UTF8\n" + script
    r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-EncodedCommand",
                        base64.b64encode(code.encode("utf-16-le")).decode()],
                       capture_output=True, timeout=120)
    return r.stdout.decode("utf-8", "replace")


def _daemon_pids() -> list[int]:
    """이 vault의 `sync_daemon.py`를 **절대 경로로** 실행 중인 프로세스들.
    예약 작업·launchd·systemd 예시가 모두 절대 경로로 띄운다. Windows의 venv
    pythonw는 실제 인터프리터를 자식으로 띄우므로 둘 다 걸린다."""
    target = str(_daemon_script())
    if os.name == "nt":
        rows = _powershell("Get-CimInstance Win32_Process -Filter \"Name LIKE 'python%'\" | "
                           "ForEach-Object { \"$($_.ProcessId)`t$($_.CommandLine)\" }")
        fold = lambda s: s.replace("/", "\\").lower()
        pairs = [line.partition("\t")[::2] for line in rows.splitlines()]
    else:
        rows = subprocess.run(["ps", "-eo", "pid=,args="], capture_output=True,
                              text=True, timeout=60).stdout
        fold = lambda s: s
        pairs = [line.strip().partition(" ")[::2] for line in rows.splitlines()]
    return [int(pid) for pid, cmd in pairs
            if pid.strip().isdigit() and fold(target) in fold(cmd)]


def _kill(pids: list[int]) -> None:
    for pid in pids:
        if os.name == "nt":          # /T: venv 런처와 자식 인터프리터를 함께
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                           capture_output=True, timeout=60)
        else:
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass


def _lock_within(f, seconds: float, busy: str) -> None:
    deadline = time.monotonic() + seconds
    while True:
        try:
            return lock_exclusive(f, blocking=False)
        except OSError:
            if time.monotonic() > deadline:
                raise UpdateError(busy)
            time.sleep(0.05)


def _start_daemon() -> dict:
    """멈춘 데몬을 다시 띄우고 돌아왔는지 보고한다. Windows는 그 데몬을 띄우는
    예약 작업을 실행하고, launchd KeepAlive·systemd Restart=always는 잠금이
    풀리면 스스로 다시 띄운다."""
    via = "launchd KeepAlive / systemd Restart=always"
    if os.name == "nt":
        path = str(_daemon_script()).lower().replace("'", "''")
        task = _powershell(
            "$p = '__P__'\n"
            "$t = Get-ScheduledTask | Where-Object { (($_.Actions | ForEach-Object "
            "{ \"$($_.Execute) $($_.Arguments)\" }) -join ' ').ToLower().Replace('/', '\\')"
            ".Contains($p) } | Select-Object -First 1\n"
            "if ($t) { Start-ScheduledTask -TaskName $t.TaskName -TaskPath $t.TaskPath; "
            "$t.TaskPath + $t.TaskName }".replace("__P__", path)).strip()
        if not task:
            return {"restarted": False,
                    "note": "이 vault의 데몬을 띄우는 예약 작업이 없다 — 데몬을 직접 띄운다"}
        via = f"scheduled task {task}"
    deadline = time.monotonic() + DAEMON_RESTART_WAIT
    while time.monotonic() < deadline:
        if _daemon_pids():
            return {"restarted": True, "via": via}
        time.sleep(2)
    return {"restarted": False, "via": via,
            "note": f"{DAEMON_RESTART_WAIT}초 안에 데몬이 돌아오지 않았다 — 데몬을 직접 띄운다"}


@contextmanager
def _daemon_stopped(info: dict):
    """적용 내내 데몬 싱글턴(osk-sync.lock)을 쥔다. 이 vault의 데몬이 쥐고
    있으면 **mutation 잠금을 먼저 잡고** 그 데몬을 끝낸다 — 그러면 데몬은
    작업 트리 변경 구간 안에 있지 않고, Git 전송 중 강제 종료는 데몬이 이미
    견딘다(SETUP 동기화 데몬). 풀리는 즉시 싱글턴을 넘겨받아, 서비스 관리자가
    먼저 띄운 구판 데몬이 적용 도중 끼어들지 못하게 한다. 끝나면(실패해도)
    멈춘 데몬을 다시 띄우고 결과를 `info`에 남긴다."""
    from sync_daemon import _lock_path as _dlp
    f = open(_dlp(ROOT, "osk-sync.lock"), "w")
    held = False
    try:
        try:
            lock_exclusive(f, blocking=False)
            held = True
        except OSError:
            pids = _daemon_pids()
            if not pids:
                raise UpdateError(
                    "동기화 데몬 잠금이 잡혀 있는데 이 vault의 sync_daemon.py 프로세스를 "
                    "찾지 못했다 — 데몬을 멈춘 뒤 다시 실행한다")
            m = open(_sync_lock_path(), "w")
            try:
                _lock_within(m, 120, "작업 트리 변경 잠금이 2분 넘게 풀리지 않는다 — "
                                     "잠시 후 다시 실행한다")
                try:
                    _kill(pids)
                    info["stopped"] = pids
                    _lock_within(f, 30, "데몬을 멈췄는데 싱글턴 잠금이 풀리지 않는다 — "
                                        "다시 실행한다")
                    held = True
                finally:
                    unlock(m)
            finally:
                m.close()
        yield
    finally:
        if held:
            unlock(f)
        f.close()
        if "stopped" in info:
            info.update(_start_daemon())


# ── 계획과 적용 ──────────────────────────────────────────────────────────

def plan(tree: Path, targets: list, adopt: bool) -> dict:
    """targets는 (source, dest) 사상. add/update/rebaseline/conflict는 파일을
    읽어야 하므로 (source, dest)를, engine_drift/remove/remove_conflict는 보고·
    삭제만 하므로 dest 문자열을 담는다."""
    recs = ledger_read(UPDATE_JOURNAL)
    add, same, rebaseline = [], [], []
    update, conflict, engine_drift, adopted = [], [], [], []
    dests = set()
    for src, dest in targets:
        dests.add(dest)
        s, d = tree / src, ROOT / dest
        if not d.exists():
            add.append((src, dest))
            continue
        if d.read_bytes() == s.read_bytes():
            # 내용은 upstream과 같다 — 기준선이 없거나(adopt·수동 동기화) 낡았으면
            # 저널만 갱신한다. 안 하면 다음 릴리스에서 이 파일이 drift로 오판된다.
            if last_applied_hash(recs, dest) != sha256_file(d):
                rebaseline.append((src, dest))
            else:
                same.append(dest)
            continue
        base = last_applied_hash(recs, dest)
        drifted = base is None or sha256_file(d) != base
        if drifted and not adopt:
            if dest.startswith(ENGINE_PREFIX):
                engine_drift.append(dest)
            else:
                conflict.append((src, dest))
        else:
            update.append((src, dest))
            if drifted:
                # **adopt가 로컬 수정 위에 덮는 자리다.** 편입의 뜻이 "현재
                # 릴리스를 기준선 삼는다"이므로 덮는 것 자체는 맞다. 맞지 않은
                # 것은 그것이 보고에서 평범한 `update`와 구별되지 않고, 성공하면
                # pre-image까지 `_txn_clear`가 지워 **되돌릴 길이 없다**는 것이다
                # (실측: 보고 update=[…], conflict=[], 사이드카 없음).
                adopted.append((src, dest))
    # 삭제 전파 — 직전까지 관리하던 파일이 새 릴리스에서 빠졌으면 인스턴스에서도
    # 제거한다(안 하면 하류가 정본과 다른 프레임워크를 실행한다). 로컬 수정이
    # 있는 삭제 대상은 지우지 않고 보존·보고한다. 바닥은 애초에 관리 대상이 아니다.
    remove, remove_conflict = [], []
    for p, h in sorted(managed_paths(recs).items()):
        cp = _canon_rel(ROOT, p)                 # 병합된 저널 path도 봉쇄(P1)
        if cp is None or cp in dests or _floor(cp):
            continue
        rp = ROOT / cp
        if not rp.exists():
            continue
        (remove if sha256_file(rp) == h else remove_conflict).append(cp)
    return {"add": add, "same": len(same), "rebaseline": rebaseline,
            "update": update, "conflict": conflict, "engine_drift": engine_drift,
            "adopted": adopted,
            "remove": remove, "remove_conflict": remove_conflict}


def _sidecar_plan(p: dict, tree: Path, version: str, dests: set) -> tuple:
    """conflict 사이드카를 (쓸 것, 이미 같아 인정할 것, 손대지 않을 것)으로 가른다.

    사이드카는 사용자가 **수동 병합에 쓰는 작업 파일**이다. 같은 버전을 다시
    적용할 때 무조건 덮으면 그 작업이 영구히 사라진다(성공 후 pre-image도
    지워지므로 복구 경로가 없다). 그래서 내용이 incoming과 같을 때만 그대로
    인정하고, 다르면 **덮지 않고 보고**한다.

    `dests`에는 이번에 **적용할 경로와 삭제할 경로를 모두** 넘긴다 — 삭제 예정
    경로와 사이드카 이름이 겹치면 '보존·인정'으로 보고한 파일이 뒤의 삭제 단계에서
    사라져 보고가 거짓이 된다. 겹치면 갱신을 중단한다."""
    write, kept, held, collide = [], [], [], []
    for src, dest in p["conflict"]:
        side = dest + f".upstream-{version}"
        if side in dests:                        # 관리·삭제 예정 경로와 충돌
            collide.append(side)
            continue
        sp = ROOT / side
        if not sp.exists():
            write.append((src, side))
        elif sp.read_bytes() == (tree / src).read_bytes():
            kept.append(side)                    # 이미 같다 — 그대로 인정
        else:
            held.append(side)                    # 사용자 작업 — 손대지 않는다
    return write, kept, held, collide


def _adopt_sidecar_plan(p: dict, version: str, dests: set) -> tuple:
    """adopt가 덮을 로컬 내용을 옆에 남길 계획 — (쓸 것, 인정할 것, 보존할 것,
    겹친 것). 반환의 첫 항은 `(로컬 바이트, 사이드카 경로)`다.

    `--adopt`는 "현재 릴리스를 기준선 삼는다"는 뜻이므로 덮는 것 자체는 맞다.
    문제는 **되돌릴 길이 없다**는 것이었다: 성공하면 `_txn_clear`가 pre-image를
    지우고, 보고에서도 평범한 `update`와 구별되지 않아 사용자는 자기 수정이
    사라진 사실조차 모른다(실측). 그래서 덮기 **전에** 로컬 내용을
    `<경로>.local-<판본>`으로 남긴다.

    `conflict`의 사이드카(`.upstream-…`)와 방향이 반대다 — 저기서는 로컬이
    제자리에 남고 incoming을 옆에 두지만, 여기서는 incoming이 제자리를 갖고
    로컬을 옆에 둔다. 이름이 그 방향을 말한다.

    이미 있는 사이드카를 무조건 덮지 않는 것과 관리·삭제 예정 경로와 겹치면
    중단하는 것은 `_sidecar_plan`과 같다. **다른 것이 하나 있다:** 내용이 다른
    사이드카가 이미 있으면 여기서는 `held`로 넘기고 진행할 수 없다.

    conflict의 `held`가 안전한 것은 **원본이 제자리에 남기** 때문이다 — 갱신하지
    못한 것은 옆에 둘 사본뿐이다. adopt는 반대로 원본을 덮으므로, 사이드카를
    쓰지 못한 채 진행하면 로컬 내용이 어디에도 남지 않는다(pre-image는 성공 후
    `_txn_clear`가 지운다). 사용자가 같은 이름의 `.local-<판본>`을 이미 가지고
    있는 것만으로 그 자리의 수정이 영구히 사라지는 셈이다(리뷰 지적). 그래서
    **덮기를 시작하지 않는다** — 무엇을 잃을지 모르는 채 파괴하지 않는다."""
    write, kept, blocked, collide = [], [], [], []
    for _src, dest in p["adopted"]:
        side = dest + f".local-{version}"
        if side in dests:
            collide.append(side)
            continue
        local = (ROOT / dest).read_bytes()      # **덮기 전** 바이트
        sp = ROOT / side
        if not sp.exists():
            write.append((local, side))
        elif sp.read_bytes() == local:
            kept.append(side)                   # 이미 같다 — 그대로 인정
        else:
            blocked.append(side)                # 다른 내용 — 진행하면 원본을 잃는다
    return write, kept, blocked, collide


def _write_atomic(dst: Path, data: bytes) -> None:
    """원자 교체. `mkstemp`는 0600으로 만들므로 **기존 권한을 보존**한다 —
    보존하지 않으면 갱신이 0644 프레임워크 파일을 0600으로 바꿔 다른 계정의
    서비스가 읽지 못하고, rollback도 원래 권한을 되돌리지 못한다."""
    _mkdirs_durable(dst.parent)     # 새 조상 각각의 부모까지 내구화
    try:
        mode = stat.S_IMODE(dst.stat().st_mode)
    except OSError:
        mode = 0o644                # 새 파일 — 프레임워크의 기본 권한
    fd, tmp = tempfile.mkstemp(dir=str(dst.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            # mode를 **fsync 앞에서** 확정한다 — 뒤에 chmod하면 그 메타데이터가
            # 내구화되지 않아, 내용은 신판인데 권한만 mkstemp의 0600으로 남는
            # 창이 생긴다(부모 디렉터리 fsync는 rename 엔트리의 내구성이지
            # 파일 mode의 내구성이 아니다). 한 번의 fsync가 둘 다 내구화한다.
            try:
                os.fchmod(f.fileno(), mode)
            except (AttributeError, OSError):    # Windows 등 — 경로로 대체
                os.chmod(tmp, mode)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, dst)
        _fsync_dir(dst.parent)          # rename 자체의 내구성 (전원 차단 대비)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def run(source: str | None = None, ref: str | None = None,
        bundle: str | None = None, apply: bool = False,
        adopt: bool = False) -> dict:
    """기본은 보고. `apply`면 **가장 먼저** mutation 잠금을 잡고 미완료 트랜잭션을
    복구한 뒤에야 상태를 판정한다(Mechanism §1-2 7항) — 복구가 판정 뒤에 오면
    half-applied 상태가 drift·adopt 거부로 오판되어 복구에 도달하지 못한다."""
    if not apply:
        return _run_locked(source, ref, bundle, False, adopt)
    reviewed = None
    # The first attempt must show the plan while the daemon and MCP can stay up.
    # Crash recovery is different: restore the already-authorized pre-image first.
    if not TXN_MANIFEST.exists():
        preview = _run_locked(source, ref, bundle, False, adopt)
        with _exclusive(local_lock_path("osk-update-review.lock"),
                        "다른 업데이트 확인이 진행 중이다 — 잠시 후 재시도한다"):
            ticket = local_lock_path(CONFIRMATION)
            try:
                pending = json.loads(ticket.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                pending = {}
            if (not isinstance(pending, dict)
                    or pending.get("review_id") != preview["review_id"]
                    or not isinstance(pending.get("at"), (int, float))
                    or not 0 <= time.time() - pending["at"] < 3600):
                return _request_approval(preview)
            ticket.unlink()  # One retry only; even a failed apply needs fresh consent.
            reviewed = preview["review_id"]
    # 잠금 순서는 데몬과 같다: **싱글턴 → mutation**. 싱글턴(osk-sync.lock)은
    # probe로 잠깐 잡았다 놓으면 그 틈에 구버전 데몬이 떠 버리므로(TOCTOU),
    # 갱신 **수명 내내 보유**한다 — 구·신 데몬 모두 이 잠금을 먼저 잡기 때문에
    # 새 mutation 규약을 모르는 구 데몬의 동시 실행까지 함께 막힌다. 데몬이
    # 쥐고 있으면 `_daemon_stopped`가 멈추고 적용 뒤 다시 띄운다.
    daemon: dict = {}
    with _daemon_stopped(daemon),\
            _exclusive(_sync_lock_path(),
                       "다른 갱신이 vault를 잠갔다 — 잠시 후 다시 실행한다"):
        # 복구는 어떤 상태 판정보다 먼저다(잠금 안에서). 저널은 **관대하게**
        # 읽는다 — 크래시가 append 도중이면 부분 행이 남는데, 엄격 판독으로
        # 여기서 실패하면 정작 복구에 도달하지 못한다.
        recovered = _txn_recover(_journal_lenient())
        if recovered == "rollback":
            try:
                ledger_append(UPDATE_JOURNAL,
                              {"kind": "rollback",
                               "why": "미완료 트랜잭션 크래시 복구"})
            except Exception:
                pass                    # 저널이 손상돼 기록을 못 남겨도 **파일
                                        # 복구는 유효하다**. 손상 자체는 아래
                                        # 정상 경로의 엄격 판독이 보고한다.
        rep = _run_locked(source, ref, bundle, True, adopt, reviewed)
        if recovered:
            rep["recovered"] = recovered
    if daemon:
        rep["daemon"] = daemon
    return rep


CONFIRMATION = "osk-update-confirmation.json"   # 기기 로컬 확인표 {review_id, at}


def confirm(review_id: str) -> None:
    """이 갱신 계획이 확인됐다고 적는다 — 1시간 안의 다음 `--apply` 한 번이, 잠금 안에서
    다시 세운 계획이 이 `review_id`일 때만 적용한다. 설치 도구(`osk.setup`)는 사용자가
    확인한 자기 계획에 담긴 `review_id`를 여기 적고 적용을 한 번만 부른다."""
    _write_atomic(local_lock_path(CONFIRMATION), json.dumps(
        {"review_id": review_id, "at": time.time()}).encode())


def withdraw() -> None:
    """확인표를 지운다 — 사용자에게 보이지 않은 계획의 확인이 남지 않게."""
    local_lock_path(CONFIRMATION).unlink(missing_ok=True)


def _request_approval(report: dict) -> dict:
    """A workflow checkpoint, not proof of a human utterance or a security boundary."""
    confirm(report["review_id"])
    return dict(report, ok=False, approval_required=True, instruction=(
        "여기서 멈추고 사용자에게 이번 업데이트 변경사항과 하네스 재시작 필요성을 "
        "설명한 뒤 명시적 재승인을 요청하라. 기존 구현·릴리스 승인으로 대신하지 마라. "
        "사용자 재승인을 받기 전에는 자동 재시도하지 마라. 재승인 후 같은 명령을 "
        "1시간 안에 한 번 재시도하면 적용한다 — 이 vault의 동기화 데몬은 적용 단계가 "
        "멈추고 끝나면 다시 띄운다. 릴리스·로컬 변경집합이 달라지거나 적용이 실패하면 "
        "새 확인을 요구한다. 적용 후 모든 연결 하네스의 MCP 서버를 재시작해야 한다."
        + _PROTECT_NOTE.get(report.get("governance", {}).get("protect"), "")))


# 통치 구획 지정 여부는 확인 대상의 일부다 — 사용자가 무엇에 답하는지 알게 한다.
_PROTECT_NOTE = {
    "establish": " 이 적용은 통치 구획(_governance)을 비준증빙 내용 그대로 "
                 "보호영역으로 지정한다 — 이후 통치 문서의 로컬 수정은 pending으로 "
                 "드러난다. 이것도 함께 알린다.",
    "withheld": " 통치 구획에 비준증빙과 다른 로컬 내용(governance.unattested)이 "
                "있거나 승인 기록부가 손상돼 보호영역으로 지정하지 않는다 — 사용자가 "
                "차이를 검토한 뒤(손상은 수동 복구가 먼저다) 대화형 단말에서 "
                "`osk protect _governance`로 지정할 수 있다고 함께 알린다.",
}


def _governance_review(tree: Path, p: dict, side_write: list, ad_write: list,
                       targets: list, rel: dict) -> dict:
    """Hash the exact post-update region, including pre-existing local changes."""
    from . import approvals
    recs = approvals.records()
    state = approvals.state("_governance", recs)
    if state == "stale":
        raise UpdateError("통치 구획 승인본이 stale이다 — 사용자 검토로 먼저 해소한다")
    files = {rel: sha256_file(path) for rel, path in
             approvals._region_files(ROOT / "_governance")}
    before = sha256_bytes(approvals._manifest_blob(sorted(files.items())))
    base = approvals.approved_hash("_governance")
    prior = approvals.changeset("_governance") if base else None
    for src, dest in p["add"] + p["update"] + side_write:
        if dest.startswith("_governance/") and not approvals._excluded_rel(dest, "_governance"):
            files[dest] = sha256_file(tree / src)
    for data, dest in ad_write:
        if dest.startswith("_governance/") and not approvals._excluded_rel(dest, "_governance"):
            files[dest] = sha256_bytes(data)
    for dest in p["remove"]:
        files.pop(dest, None)
    out = {"state": state, "base": base, "before": before,
           "after": sha256_bytes(approvals._manifest_blob(sorted(files.items()))),
           "existing_changes": prior if state == "pending" else None}
    if state != "unprotected":
        return out
    # 통치 구획은 상설 보호영역이다(헌법 10조 1항). 지정 이력이 없는 설치에서는
    # 확인받은 적용이 지정까지 한다 — 단 적용 뒤 구획이 **비준증빙이 정한 내용과
    # 정확히 같을 때만**. 로컬 차이(충돌 사이드카·증빙 밖 파일 포함)를 초기
    # 승인본으로 축복하지 않고 보고한다. 사용자가 해제한 구획은 다시 지정하지
    # 않는다(해제는 제도의 개정과 함께 한다 — 시행령 §6 1항).
    if any(r.get("region") == "_governance" for r in recs):
        out["protect"] = "released"
        return out
    attested = {dest: rel["files"][src] for src, dest in targets
                if dest.startswith("_governance/")
                and not approvals._excluded_rel(dest, "_governance")}
    diff = sorted(k for k in files.keys() | attested.keys()
                  if files.get(k) != attested.get(k))
    out["protect"] = "withheld" if diff or approvals._damaged(recs) else "establish"
    if diff:
        out["unattested"] = diff[:20]
    return out


def _run_locked(source: str | None, ref: str | None, bundle: str | None,
                apply: bool, adopt: bool, reviewed: str | None = None) -> dict:
    cfg = load_config().get("upstream", {})
    source = source or ("bundle" if bundle else cfg.get("source", "git"))
    self_tag = None
    # adopt는 **최초 편입** 전용이다 — 이미 관리 이력이 있으면 거부한다. 안 그러면
    # 정상 관리 인스턴스에서 로컬 수정(엔진 포함)을 아무 때나 덮는 force가 된다.
    if adopt and has_history():
        raise UpdateError(
            "이미 갱신 관리 이력이 있다 — adopt는 최초 편입에만 허용된다. "
            "로컬 수정은 정본에서 고치거나 로컬 사본을 정리한 뒤 갱신한다")
    with tempfile.TemporaryDirectory() as td:
        if source == "git":
            url = cfg.get("url", DEFAULT_UPSTREAM)
            pin = ref or cfg.get("pin")
            if pin is not None:
                # 명시 ref/pin도 정식 릴리스 태그여야 한다 — 브랜치(`--to main`)로
                # 태그 경계를 우회하지 못하게, 형식·실재를 함께 확인한다(§1-2 3항).
                if not re.match(VERSION_RE, str(pin)):
                    raise UpdateError(f"명시 ref/pin은 vX.Y.Z 태그여야 한다: {pin}")
                if not tag_exists(url, pin):
                    raise UpdateError(f"정본에 그 릴리스 태그가 없다: {pin}")
                tag = pin
            else:
                tag = latest_release_tag(url)   # 기본은 최신 정식 태그(HEAD 아님)
                if tag is None:
                    raise UpdateError(
                        "정본에 정식 릴리스 태그(vX.Y.Z)가 없다 — 정본에서 "
                        "먼저 릴리스하거나 --to로 참조를 지정한다")
            tree = fetch_git(url, tag, Path(td))
            self_tag = tag                       # 증빙 version이 이 태그와 같아야 한다
        elif source == "bundle":
            if not bundle:
                raise UpdateError("bundle 출처에는 --from <경로>가 필요하다")
            tree = fetch_bundle(bundle, Path(td))
        else:
            raise UpdateError(f"미정의 출처: {source} (git·bundle)")

        rel = load_release(tree)
        if self_tag is not None and rel["version"] != self_tag:
            raise UpdateError(
                f"요청 태그와 증빙 version이 다르다 — 태그 {self_tag} 의 "
                f"release.json은 {rel['version']} 이다(태그 위조·오지정 차단)")
        errs = verify_attestation(tree, rel)
        if errs:
            raise UpdateError("비준증빙 대조 실패 — 아무것도 쓰지 않았다:\n  "
                              + "\n  ".join(errs[:10]))
        # **버전 불변성**: 같은 version이 다른 릴리스 identity로 오면 거부한다.
        # 태그 이름과 증빙의 version만 맞춰서는, 원격에서 태그를 다른 커밋으로
        # force-move한 뒤 자기일관적 증빙만 갖추면 그대로 통과한다(엔진까지
        # 덮인다). 증빙 파일 자체의 해시를 identity로 삼아 저널에 고정한다.
        attest_id = sha256_file(tree / ATTESTATION)
        for r in _journal_lenient():
            if (r.get("kind") == "done" and r.get("version") == rel["version"]
                    and r.get("attest") and r["attest"] != attest_id):
                raise UpdateError(
                    f"같은 버전인데 릴리스 identity가 다르다 — 중단"
                    f"(태그 force-move·위조 의심): {rel['version']}\n"
                    f"  적용된 증빙: {r['attest']}\n  받은 증빙: {attest_id}")
        targets, skel, skipped = apply_set(tree, rel)
        p = plan(tree, targets, adopt)
        dests = lambda pairs: [d for _s, d in pairs]
        out = {"ok": True, "applied": False, "version": rel["version"],
               "current": current_version(), "files": len(targets),
               "add": dests(p["add"]), "update": dests(p["update"]),
               "same": p["same"], "rebaseline": dests(p["rebaseline"]),
               "conflict": dests(p["conflict"]), "engine_drift": p["engine_drift"],
               "adopted": dests(p["adopted"]),
               "remove": p["remove"], "remove_conflict": p["remove_conflict"],
               "skipped": len(skipped)}
        if p["engine_drift"]:
            raise UpdateError(
                "엔진 파일에 로컬 수정이 있다 — 갱신 전체를 중단한다. 엔진을 "
                "고치는 자리는 정본이다(Mechanism §1-2 6항). 기존 인스턴스의 "
                "최초 편입이면 --adopt로 현재 릴리스를 기준선 삼는다:\n  "
                + "\n  ".join(p["engine_drift"][:10]))
        # (잠금·미완료 트랜잭션 복구는 run()이 이미 끝냈다 — 여기는 잠금 안이다.)
        v = rel["version"]
        # 사이드카는 사용자의 수동 병합 작업 파일이다 — 덮을 것/인정할 것/보존할
        # 것을 먼저 가른다. 관리 파일과 경로가 겹치면 중단한다.
        _dests = {d for _s, d in targets} | set(p["remove"])
        side_write, side_kept, side_held, side_collide = _sidecar_plan(
            p, tree, v, _dests)
        # adopt가 덮을 로컬 내용도 같은 규율로 옆에 남긴다 — 덮기 전 바이트를
        # 여기서 읽어 둔다(아래 적용 루프가 그 자리를 먼저 덮을 수 있다).
        ad_write, ad_kept, ad_blocked, ad_collide = _adopt_sidecar_plan(
            p, v, _dests)
        out["sidecar_held"] = side_held
        out["adopt_blocked"] = ad_blocked
        if ad_blocked:
            raise UpdateError(
                "adopt가 덮을 자리의 사이드카가 이미 있고 내용이 다르다 — "
                "아무것도 쓰지 않았다. 진행하면 지금 파일의 로컬 수정이 어디에도 "
                "남지 않는다(성공 뒤 pre-image도 지워진다). 그 사이드카를 확인해 "
                "필요한 것을 챙긴 뒤 옮기거나 지우고 다시 실행하라:\n  "
                + (chr(10) + "  ").join(ad_blocked[:10]))
        side_collide = side_collide + ad_collide
        if side_collide:
            raise UpdateError(
                "사이드카 경로가 정식 관리 파일과 겹친다 — 갱신을 중단한다"
                "(관리 파일을 되덮게 된다):\n  " + "\n  ".join(side_collide[:10]))
        governance = _governance_review(tree, p, side_write, ad_write, targets, rel)
        out["governance"] = governance
        out["restart_required"] = True
        out["attestation"] = attest_id
        out["layout"] = SPACE_ROOTS
        # Bind consent to content, not mtime or the version label. The second read
        # under the mutation lock catches changes during the confirmation window.
        paths = sorted(_dests | {s for _, s in side_write + ad_write}
                       | {posix_rel(d / ".gitkeep", ROOT) for d in skel})
        local = [(path, sha256_file(ROOT / path) if (ROOT / path).is_file()
                  else "directory" if (ROOT / path).exists() else None) for path in paths]
        identity = {"root": str(ROOT), "plan": out, "local": local,
                    "adopt": adopt, "journal": _journal_lenient()}
        out["review_id"] = sha256_bytes(json.dumps(
            identity, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode())
        if not apply:
            if TXN_MANIFEST.is_file():
                out["pending_txn"] = True
            return out
        if reviewed != out["review_id"]:
            return _request_approval(out)
        # 저널이 **기록 가능한지 먼저 본다.** `_txn_begin`이 manifest를 남긴
        # 뒤에 `ledger_append`가 손상으로 죽으면(그 호출은 아래 try 밖이다)
        # 표식만 남아 데몬이 영원히 `pending-txn`으로 tick을 거부하고, 다음
        # `--apply`가 같은 자리에서 또 죽으며 표식을 다시 만든다 — 지워도 벗어날
        # 수 없는 상태다(실측). 손상 위에 이력을 더 쌓지 않는다(Mechanism §3 2항).
        try:
            _dmg = ledger_damage(ledger_read(UPDATE_JOURNAL), UPDATE_JOURNAL)
        except Exception as e:
            raise UpdateError(f"갱신 저널을 읽지 못했다 — 아무것도 쓰지 않았다: {e}")
        if _dmg:
            raise UpdateError(
                "갱신 저널이 손상됐다 — 아무것도 쓰지 않았다 "
                "(Mechanism §3 8항의 수동 복구가 먼저다):\n  "
                + "\n  ".join(_dmg[:5]))
        txn = os.urandom(8).hex()                # 파일과 저널을 묶는 트랜잭션 id
        # 이번에 건드릴 파일(canonical 상대)의 pre-image를 영속 백업하고 manifest를
        # 기록한 **뒤에만** target을 건드린다. 이후 크래시는 다음 실행이 판정한다:
        # done(txn)이 있으면 roll-forward, 없으면 rollback.
        touch = [dest for _s, dest in p["add"] + p["update"]]
        touch += list(p["remove"])
        touch += [side for _s, side in side_write]
        touch += [side for _b, side in ad_write]
        touch += [posix_rel(d / ".gitkeep", ROOT) for d in skel if not d.exists()]
        from . import approvals
        accept_governance = governance["base"] and governance["after"] != governance["base"]
        establish = governance.get("protect") == "establish"
        if accept_governance or establish:
            touch.append(posix_rel(approvals.APPROVALS, ROOT))
        _txn_begin(txn, v, touch)
        ledger_append(UPDATE_JOURNAL, {"kind": "begin", "txn": txn,
                                       "version": v, "adopt": bool(adopt)})
        applied, removed, sidecars, made_skel = [], [], [], []
        try:
            for local, side in ad_write:      # **덮기 전에** 로컬을 옆에 남긴다
                _write_atomic(ROOT / side, local)
                sidecars.append(side)
            sidecars += ad_kept
            for src, dest in p["add"] + p["update"]:
                _write_atomic(ROOT / dest, (tree / src).read_bytes())
                applied.append(dest)
            for path in p["remove"]:              # path는 이미 canonical(P1)
                tp = ROOT / path
                tp.unlink(missing_ok=True)
                _fsync_dir(tp.parent)             # 삭제 엔트리 내구화(전원 차단)
                removed.append(path)
            for src, side in side_write:          # 없던 사이드카만 쓴다
                _write_atomic(ROOT / side, (tree / src).read_bytes())
                sidecars.append(side)
            sidecars += side_kept                 # 이미 같은 것은 그대로 인정
            for d in skel:                        # 이미 _allowed_skel로 봉쇄·검증됨
                if not d.exists():
                    _mkdirs_durable(d)            # 만든 각 조상의 부모까지 내구화
                    _write_atomic(d / ".gitkeep", b"")
                    made_skel.append(posix_rel(d, ROOT))
            if accept_governance:
                approvals._approve_locked("_governance", governance["base"],
                                          governance["after"],
                                          f"osk.update {v}; user confirmation: {reviewed}")
            if establish:                     # 확인받은 증빙 tree 그대로만 지정
                approvals.protect("_governance",
                                  f"osk.update {v}; user confirmation: {reviewed}",
                                  expect_work=governance["after"], _locked=True)
        except (OSError, ValueError) as e:
            _txn_recover(ledger_read(UPDATE_JOURNAL))   # done(txn) 없음 → rollback
            ledger_append(UPDATE_JOURNAL,
                          {"kind": "rollback", "txn": txn, "version": v,
                           "why": str(e)[:200]})
            raise UpdateError(f"갱신 적용 중 실패 — 원상복구했다: {e}")

        # 파일 조작 성공 후에 적용 상태를 저널에 남긴다. 이 기록들은 마지막
        # `done(txn)`이 append될 때까지 `committed()`가 판정에서 가린다 —
        # 중간에 죽어도 파일(pre-image 복구)과 판정이 어긋나지 않는다.
        for dest in applied:
            ledger_append(UPDATE_JOURNAL, {
                "kind": "apply", "txn": txn, "version": v, "path": dest,
                "hash": sha256_file(ROOT / dest)})
        for _src, dest in p["rebaseline"]:        # 내용 동일·기준선만 갱신
            ledger_append(UPDATE_JOURNAL, {
                "kind": "apply", "txn": txn, "version": v, "path": dest,
                "hash": sha256_file(ROOT / dest)})
        for path in removed:
            ledger_append(UPDATE_JOURNAL, {"kind": "remove", "txn": txn,
                                           "version": v, "path": path})
        # skip은 conflict **사건**이지 적용 상태 변경이 아니다 — `skipped_path`로
        # 남겨 baseline/관리 판정(`path` 키)이 이를 보지 않게 한다(P2).
        for _src, dest in p["conflict"]:
            ledger_append(UPDATE_JOURNAL, {
                "kind": "skip", "txn": txn, "version": v, "skipped_path": dest,
                "why": "로컬 수정 — upstream 사본을 옆에 두었다"})
        for path in p["remove_conflict"]:
            ledger_append(UPDATE_JOURNAL, {
                "kind": "skip", "txn": txn, "version": v, "skipped_path": path,
                "why": "upstream 삭제됐으나 로컬 수정 — 보존한다"})
        ledger_append(UPDATE_JOURNAL, {
            "kind": "done", "txn": txn, "version": v, "attest": attest_id,
            "applied": len(applied), "removed": len(removed),
            "conflicts": len(sidecars)})
        # 커밋 기록의 **디렉터리 엔트리**까지 내구화한 뒤에만 표식을 지운다 —
        # 저널이 이번에 처음 생겼으면 이름이 유실될 수 있고, 그러면 파일은 새
        # 판인데 복구 표식도 없어 baseline이 통째로 사라진다.
        _fsync_journal_home()
        _txn_clear()                              # 커밋 완료 — 트랜잭션 영역 정리
        out.update(applied=True, applied_files=len(applied),
                   removed=removed, sidecars=sidecars, skel_created=made_skel,
                   governance_accepted=bool(accept_governance),
                   governance_protected=("established" if establish
                                         else governance.get("protect")),
                   note="엔진이 갱신되었으면 실행 중인 MCP 서버를 재시작한다 — "
                        "이 기기의 동기화 데몬은 갱신이 멈췄다 다시 띄운다(daemon)")
        return out


def main(argv=None):
    ap = argparse.ArgumentParser(
        prog="osk-update",
        description="정본 릴리스로 갱신 — 기본은 보고, 쓰기는 --apply")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--to", help="버전 태그 pin (기본: 설정의 pin 또는 최신 릴리스 태그)")
    ap.add_argument("--from", dest="bundle", help="로컬 bundle 경로 (오프라인)")
    ap.add_argument("--source", choices=("git", "bundle"))
    ap.add_argument("--adopt", action="store_true",
                    help="기존 인스턴스의 최초 편입 — 현재 릴리스를 기준선 삼는다")
    ap.add_argument("--check", action="store_true",
                    help="정본의 최신 릴리스 태그만 묻는다 — 받지도 적용하지도 않는다")
    a = ap.parse_args(argv)
    if a.check:
        if a.apply or a.adopt or a.to or a.bundle or a.source:
            sys.exit("[중단] --check는 다른 선택지와 함께 쓰지 않는다 — 태그만 묻는다")
        from . import update_check
        try:
            rep = update_check.check()
        except UpdateError as e:
            sys.exit(f"[중단] {e}")
        print(json.dumps(rep, ensure_ascii=False, indent=2))
        if rep.get("error"):
            raise SystemExit(1)
        return
    try:
        rep = run(a.source, a.to, a.bundle, a.apply, a.adopt)
    except UpdateError as e:
        sys.exit(f"[중단] {e}")
    print(json.dumps(rep, ensure_ascii=False, indent=2))
    if rep.get("approval_required"):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
