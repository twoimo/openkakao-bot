"""osk.publish — 공개 미러 발행 (v2).

구현 근거: Mechanism §1 1항(공개 repo는 발행 미러이며 범위는 allowlist가 정한다),
헌법 10조(서명은 사용자 전속), 시행령 §11(실패는 보류·보고).

**왜 다시 짰는가.** 구 절차(`sync-template.sh`)는 사설 커밋을 공개 저장소로
cherry-pick하는 방식이었고, 그것은 두 저장소의 **경로가 같다**는 전제 위에
있었다. v2.1에서 통치 구획이 사설·공개 모두 `_governance/`로 같아져 사상이
`_governance/`에 있어 경로가 사상된다 — cherry-pick으로는 표현할 수 없다.
그래서 v2는 **사설 트리에서 공개 트리를 빌드하는 export 모델**이다.

발행은 되돌리기 어려운 바깥 행위다. 그래서 이 모듈의 기본 동작은 **보고**이고,
쓰기는 명시 인자로만 한다. 가드는 전부 fail-closed다 — 하나라도 걸리면
아무것도 쓰지 않는다.

가드 (모두 통과해야 발행):
1. **매니페스트 밖 금지** — 나가는 모든 파일은 MAP이 사상한 것이어야 한다.
2. **DENY 조각** — 대장·`_raw`·`_sources`·부산물은 대상 안이라도 제외.
3. **지식 유출 금지** — `_governance/` 밖에 노드형(frontmatter) 파일이 있으면
   중단. 통치 문서·사료는 특수한 노드라 통치 구획 안의 frontmatter는 정상이다.
4. **비밀값** — 나가는 전 파일을 `secrets.PATTERNS`로 훑는다.
5. **검증기 PASS** — 깨진 vault에서 발행하지 않는다.

발행에 서명 가드는 없다 — 통치 문서의 비준은 정본 저장소에 대한 사용자의
확정이고 정식 릴리스의 비준증빙이 고정하며(헌법 14조 1항·시행령 §10 2·6항),
서명은 각 인스턴스 사용자의 수용 기록이지 발행·효력의 요건이 아니다.
"""
from __future__ import annotations
import argparse, os, re, shutil, subprocess, sys, tempfile
from pathlib import Path

from .core import ROOT, posix_rel
from . import graph, secrets, validate

MANIFEST = ROOT / "_governance" / "_engine" / "scripts" / "publish-manifest.txt"


class PublishError(RuntimeError):
    """발행 중단. 어느 단계에서 걸려도 공개 저장소에는 아무것도 쓰지 않는다."""


def parse_manifest(path: Path = MANIFEST) -> dict:
    """MAP·DENY·SKEL 세 갈래. 코드를 읽지 않고 이 파일만 보면 무엇이 나가는지
    알 수 있어야 하므로, 형식은 일부러 단순하다."""
    maps, deny, skel, keep = [], [], [], []
    for i, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        kind, _, rest = line.partition(" ")
        rest = rest.strip()
        if kind == "MAP":
            src, arrow, dst = rest.partition("->")
            if not arrow:
                raise PublishError(f"매니페스트 {path}:{i} — MAP에 '->'가 없다")
            maps.append((src.strip(), dst.strip()))
        elif kind == "DENY":
            deny.append(rest)
        elif kind == "SKEL":
            skel.append(rest)
        elif kind == "KEEP":
            keep.append(rest)
        else:
            raise PublishError(f"매니페스트 {path}:{i} — 미정의 지시어 {kind!r}")
    if not maps:
        raise PublishError("매니페스트에 MAP이 없다 — 발행할 것이 없다")
    return {"map": maps, "deny": deny, "skel": skel, "keep": keep}


def _denied(rel: str, deny: list[str]) -> str | None:
    for d in deny:
        if d in rel or rel.endswith(d.rstrip("/")):
            return d
    return None


def collect(man: dict, root: Path | None = None) -> list[tuple[Path, str]]:
    """(사설 절대경로, 공개 상대경로) 목록. DENY에 걸리는 것은 여기서 빠진다."""
    out: list[tuple[Path, str]] = []
    root = ROOT if root is None else root
    for src, dst in man["map"]:
        s = root / src.rstrip("/")
        if not s.resolve().is_relative_to(root.resolve()):
            raise PublishError(f"MAP 출처가 vault 밖이다: {src}")
        if src.endswith("/"):
            if not s.is_dir():
                raise PublishError(f"MAP 출처가 디렉터리가 아니다: {src}")
            for p in sorted(s.rglob("*")):
                if not p.is_file():
                    continue
                rel = posix_rel(p, s)
                if _denied(rel, man["deny"]):
                    continue
                out.append((p, dst.rstrip("/") + "/" + rel))
        else:
            if not s.is_file():
                raise PublishError(f"MAP 출처가 파일이 아니다: {src}")
            if not _denied(src, man["deny"]):
                out.append((s, dst))
    return out


# ── 가드 ─────────────────────────────────────────────────────────────────

GOVERNANCE_DST = "_governance/"


def guard_knowledge(items: list[tuple[Path, str]]) -> list[str]:
    """`_governance/` 밖에 노드형 파일이 나가면 지식 코퍼스 유출이다.
    공개 미러는 프레임워크이지 이 인스턴스의 지식이 아니다. 통치 구획의
    노드형은 정상이다 — 통치 문서·사료는 특수한 노드다(시행령 §10 1항)."""
    errs = []
    for src, dst in items:
        if dst.startswith(GOVERNANCE_DST) or src.suffix != ".md":
            continue
        try:
            head = src.read_text(encoding="utf-8", errors="ignore")[:4]
        except OSError:
            continue
        if head.startswith("---\n"):
            errs.append(f"노드형 파일이 발행 대상에 있다: {dst}")
    return errs


def guard_secrets(items: list[tuple[Path, str]]) -> list[str]:
    """나가는 전 파일을 훑는다. 보고에는 경로와 패턴 이름만 싣는다 —
    비밀값 자체는 어디에도 적지 않는다(Mechanism §9)."""
    errs = []
    for src, dst in items:
        if src.name == "secrets.py" and "osk" in src.parts:
            continue
        try:
            text = src.read_text(encoding="utf-8", errors="ignore")
        except OSError as e:
            errs.append(f"{dst}: 판독 실패 {e}")
            continue
        _, hits = secrets.filter_text(text)
        if hits:
            errs.append(f"{dst}: 비밀값 패턴 {sorted(set(hits))}")
    return errs


def guard_vault(root: Path | None = None) -> list[str]:
    """깨진 vault에서 발행하지 않는다."""
    try:
        if root is not None:
            from .release import _validate_at
            return _validate_at(root)
        rep = validate.run()
    except Exception as e:
        return [f"검증기 실행 실패: {e}"]
    if rep["verdict"] != "PASS":
        return [f"검증기 {rep['verdict']}: "
                + "; ".join(list(f)[0] for f in rep["fail"])]
    return []


# ── 빌드·비교 ────────────────────────────────────────────────────────────

def _snapshot_ignored(directory: str, names: list[str], mapped_roots: set[str]) -> set[str]:
    # layout_violations가 보지 않는 루트 도구 디렉터리만 뺀다. 노드 군집의
    # 같은 이름 폴더나 승인 blob·대장·raw는 전역 검증 대상이므로 보존한다.
    root = Path(directory)
    # 검증기 제외 구획이어도 명시적인 MAP 출처와 그 조상은 발행에 필요하다.
    ignored = {n for n in names if root == ROOT and "" not in mapped_roots
               and n not in mapped_roots and
               (n == ".git" or ((n.startswith(".") or n == "__pycache__")
                                and (root / n).is_dir()))}
    # 검증기는 복사한 .py를 적재해야 한다. 같은 시각·크기의 낡은 pyc를
    # 재사용하지 않되 이 폴더의 .md 등 실제 배치 검사 대상은 남긴다.
    if "_engine" in root.parts and root.name == "__pycache__":
        ignored.update(n for n in names if n.endswith(".pyc"))
    with os.scandir(root) as entries:
        for entry in entries:
            if entry.name not in ignored and graph._is_reparse(entry):
                raise PublishError(f"발행 스냅샷은 리파스 경로를 복사하지 않는다: {entry.path}")
    return ignored


def build(items: list[tuple[Path, str]], man: dict, dest: Path) -> None:
    for src, rel in items:
        t = dest / rel
        t.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, t)
    for s in man["skel"]:
        d = dest / s.rstrip("/")
        d.mkdir(parents=True, exist_ok=True)
        (d / ".gitkeep").write_text("", encoding="utf-8")


def _git_paths(public: Path, *args: str) -> set[str]:
    """git이 내놓는 경로 목록을 읽는다. **반드시 `-z`로** 읽어야 한다 —
    기본 출력은 core.quotePath 때문에 비ASCII 이름을 따옴표와 8진 이스케이프로
    감싸므로(`"\354\270\265.md"`), 그 문자열은 실제 경로와 같지 않다. 그러면
    한글 이름 파일이 want와 영원히 어긋나 매번 remove로 잡히고, 스테이지도
    삭제도 조용히 빗나간다."""
    r = subprocess.run(["git", "-C", str(public), *args, "-z"],
                       capture_output=True, text=True, timeout=30)
    return {l for l in r.stdout.split("\0") if l.strip()}


def _tracked(public: Path) -> set[str]:
    return _git_paths(public, "ls-files")


def _untracked(public: Path) -> set[str]:
    return _git_paths(public, "ls-files", "--others", "--exclude-standard")


def plan(public: Path, man: dict, items: list[tuple[Path, str]]) -> dict:
    """무엇이 더해지고 바뀌고 **사라지는가**. 사라지는 것을 보여주는 것이
    중요하다 — 매니페스트에서 빠진 경로는 공개에서 지워지기 때문이다."""
    want = {rel for _s, rel in items}
    want |= {s.rstrip("/") + "/.gitkeep" for s in man["skel"]}
    want |= set(man["keep"])          # 공개 전용 — 사상 대상은 아니나 지우지 않는다
    have = _tracked(public)
    add, gone, same, diff = [], sorted(have - want), [], []
    for src, rel in items:
        cur = public / rel
        if not cur.exists():
            add.append(rel)
        elif cur.read_bytes() == src.read_bytes():
            same.append(rel)
        else:
            diff.append(rel)
    # 매니페스트가 통제하지 않는데 디스크에 있는 파일. 발행은 이들을 커밋하지도
    # 지우지도 않는다 — 다만 미러가 빌드 결과와 다르다는 사실은 보여야 한다.
    return {"add": sorted(add), "change": sorted(diff),
            "remove": gone, "same": len(same),
            "stray": sorted(_untracked(public) - want)}


def run(public: Path, apply: bool = False, push: bool = False,
        message: str | None = None, manifest: Path | None = None) -> dict:
    """기본은 보고다. `apply`가 있어야 공개 트리에 쓰고, `push`가 있어야 올린다."""
    if not (public / ".git").exists():
        raise PublishError(f"공개 저장소가 아니다: {public}")
    man = parse_manifest(manifest or MANIFEST)
    mapped_roots = set()
    for src, _dst in man["map"]:
        source = (ROOT / src.rstrip("/")).resolve()
        if not source.is_relative_to(ROOT.resolve()):
            raise PublishError(f"MAP 출처가 vault 밖이다: {src}")
        parts = source.relative_to(ROOT.resolve()).parts
        mapped_roots.add(parts[0] if parts else "")  # vault 전체 MAP도 보존한다.
    # ponytail: 발행마다 검증 대상 전체를 복사한다. 복사 비용이 병목으로
    # 측정되면 검증 가능한 파일시스템 snapshot으로 대체한다.
    with tempfile.TemporaryDirectory(prefix="osk-publish-") as td:
        snap = Path(td) / "vault"
        try:
            shutil.copytree(ROOT, snap, symlinks=True,
                            ignore=lambda d, ns: _snapshot_ignored(d, ns, mapped_roots))
            items = collect(man, snap)
            # OSK_VAULT_ROOT로 데이터만 별도 배치한 경우에도 검증기는 이
            # 프로세스의 엔진 사본을 쓴다. 추가한 엔진은 발행 목록에 넣지 않는다.
            snap_engine = snap / "_governance" / "_engine"
            if not (snap_engine / "osk").is_dir():
                shutil.copytree(Path(__file__).resolve().parent.parent, snap_engine,
                                ignore=shutil.ignore_patterns("__pycache__", ".git", ".venv"),
                                dirs_exist_ok=True,
                                copy_function=lambda src, dst: dst if Path(dst).exists()
                                else shutil.copy2(src, dst))
        except OSError as e:
            raise PublishError(f"발행 스냅샷 생성 실패 — 아무것도 쓰지 않았다: {e}") from e
        errs = guard_knowledge(items) + guard_secrets(items) + guard_vault(snap)
        if errs:
            raise PublishError("발행 가드 위반 — 아무것도 쓰지 않았다:\n  "
                               + "\n  ".join(errs))
        p = plan(public, man, items)
        if not apply:
            return {"ok": True, "applied": False, "files": len(items), **p}
        build(items, man, public)
    for rel in p["remove"]:
        (public / rel).unlink(missing_ok=True)
    # **매니페스트가 통제하는 경로만** 스테이지한다. `git add -A`는 디스크에
    # 남아 있는 아무 파일이나 함께 커밋해 위의 가드를 통째로 우회한다 —
    # 실제로 v1 잔재(지식 노드 포함)가 그렇게 들어간 적이 있다.
    # **KEEP은 스테이지하지 않는다.** KEEP의 뜻은 "지우지 않는다"이고 그것은
    # 위의 `want`(삭제 집합 제외)가 이미 낸다. 여기에 넣으면 `git add --all`이
    # 공개 저장소에 남아 있던 **로컬 수정·삭제까지** 발행 커밋에 싣는데, KEEP
    # 경로는 사설에 원본이 없어 `items`에 들지 않으므로 `guard_secrets`·
    # `guard_knowledge`·`plan()`의 어느 검사도 그 내용을 보지 않는다 — 검증을
    # 통과하지 않은 변경이 발행으로 나가는 길이다. CI workflow처럼 특권을 가진
    # 파일이 그 길에 있으면 조용한 변경이 그대로 공개된다.
    controlled = sorted({rel for _s, rel in items}
                        | {s.rstrip("/") + "/.gitkeep" for s in man["skel"]}
                        | set(p["remove"]))
    for rel in controlled:
        subprocess.run(["git", "-C", str(public), "add", "--all", "--", rel],
                       check=False, timeout=60)
    staged = _git_paths(public, "diff", "--cached", "--name-only")
    stray = sorted(staged - set(controlled))
    if stray:
        subprocess.run(["git", "-C", str(public), "reset", "-q"], timeout=60)
        raise PublishError(
            "매니페스트 밖 파일이 스테이지됐다 — 발행하지 않았다: " + str(stray[:10]))
    if not staged:
        return {"ok": True, "applied": True, "committed": False,
                "note": "변경 없음", "files": len(items), **p}
    subprocess.run(["git", "-C", str(public), "commit", "-q", "-m",
                    message or "governance: 발행 갱신"], check=True, timeout=60)
    out = {"ok": True, "applied": True, "committed": True,
           "files": len(items), **p}
    if push:
        subprocess.run(["git", "-C", str(public), "push", "-q", "origin", "main"],
                       check=True, timeout=180)
        out["pushed"] = True
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(
        prog="osk-publish",
        description="공개 미러 발행 — 기본은 보고, 쓰기는 --apply, 올리기는 --push")
    ap.add_argument("--public", default=os.environ.get("OSK_PUBLIC_ROOT"),
                    help="공개 저장소 경로 (또는 OSK_PUBLIC_ROOT)")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--push", action="store_true")
    ap.add_argument("-m", "--message")
    ap.add_argument("--manifest", help="기본: _engine/scripts/publish-manifest.txt")
    a = ap.parse_args(argv)
    if not a.public:
        sys.exit("공개 저장소 경로가 필요하다: --public <경로> 또는 OSK_PUBLIC_ROOT")
    if a.push and not sys.stdin.isatty():
        sys.exit("발행은 바깥으로 나가는 행위다 — 대화형 단말에서만 push한다")
    try:
        rep = run(Path(a.public).resolve(), a.apply, a.push, a.message,
                  Path(a.manifest) if a.manifest else None)
    except PublishError as e:
        sys.exit(f"[중단] {e}")
    import json
    print(json.dumps(rep, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
