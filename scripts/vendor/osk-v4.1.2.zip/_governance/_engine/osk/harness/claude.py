"""Claude Code 어댑터."""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

from .base import MCP_NAME, Adapter

_SEMVER = r"\d+\.\d+\.\d+(?:-[\w.]+)?"


class Claude(Adapter):
    name = "claude"
    title = "Claude Code"
    cli = "claude"
    # 2026-09-26 이 기기에서 osk 훅이 포착한 가장 새 대화의 판(2.1.280 14건, 2.1.281 1건 오류 없이).
    verified = "2.1.281"
    fork = True
    guide = "3b"
    reload = "Claude Code는 훅을 세션을 시작할 때 읽는다 — 새 세션을 열고 `/hooks`에서 확인한다"
    login = "auth login"
    # 셸 형식 훅은 Git Bash로 돈다(2026-09-27 2.1.251에서 실측). Git Bash가 없으면 PowerShell이라,
    # 인용 없이 두는 글자는 PowerShell도 맨 낱말로 읽는 것만이다(`base._BARE`).
    hook_shell = "bash"

    def home(self) -> Path:
        return Path(os.environ.get("CLAUDE_CONFIG_DIR", str(Path.home() / ".claude")))

    def claims(self, sid, path):
        # 새 대화의 전사는 SessionStart 뒤에야 생길 수 있다 — 파일이 아니라 자리로 안다.
        if not (path and sid and Path(path).stem == sid):
            return False
        return Path(path).resolve().is_relative_to((self.home() / "projects").resolve())

    def claims_row(self, row):
        return bool(row.get("sessionId"))

    def transcripts(self, sid):
        return list((self.home() / "projects").glob(f"*/{sid}.jsonl"))

    def parse_version(self, text):
        m = re.search(r"(?<![\w.])(" + _SEMVER + r")\s*\(Claude Code\)", text or "")
        return m[1] if m else None

    def transcript_version(self, path):
        # 행마다 그 행을 쓴 판을 싣는다 — 이어 쓴 대화는 마지막 행이 지금의 판이다.
        # 전사는 수십 MB가 되므로 끝부분만 읽는다.
        with Path(path).open("rb") as f:
            size = f.seek(0, os.SEEK_END)
            f.seek(max(0, size - (1 << 16)))
            lines = f.read().split(b"\n")
        for line in reversed(lines[1:] if size > (1 << 16) else lines):
            try:
                row = json.loads(line)
            except ValueError:
                continue
            version = row.get("version") if isinstance(row, dict) else None
            if isinstance(version, str) and re.fullmatch(_SEMVER, version):
                return version
        return None

    def mcp_argv(self, python, server):
        return ["claude", "mcp", "add", "--scope", "user", MCP_NAME, "--", str(python), str(server)]

    def mcp_remove_argv(self):
        return ["claude", "mcp", "remove", "--scope", "user", MCP_NAME]

    def mcp_files(self):
        # `claude mcp add --scope user`가 쓰는 자리. 설정 폴더를 옮기면 그 안에도 둔다.
        files = [Path.home() / ".claude.json"]
        if os.environ.get("CLAUDE_CONFIG_DIR"):
            files.insert(0, self.home() / ".claude.json")
        return files

    def mcp_servers(self, data):
        return data.get("mcpServers") or {}

    def hook_files(self):
        return [self.home() / "settings.json"]

    def cli_candidates(self):
        # Windows 데스크톱 앱은 판마다 CLI를 `Claude/claude-code/<판>/`에 둔다. 스토어(MSIX)
        # 설치는 그 폴더가 패키지의 LocalCache 아래로 옮겨진다.
        if os.name != "nt":
            return []
        roots = []
        if os.environ.get("APPDATA"):
            roots.append(Path(os.environ["APPDATA"]) / "Claude" / "claude-code")
        if os.environ.get("LOCALAPPDATA"):
            roots += Path(os.environ["LOCALAPPDATA"]).glob(
                "Packages/Claude_*/LocalCache/Roaming/Claude/claude-code")
        return [p for root in roots for p in root.glob("*/claude.exe")]

    def growth_argv(self, cli, python, server, root):
        # 사람이 없는 실행이다. 내장 도구는 모두 끈다(`--tools ""`) — 설정의 허용 규칙이 있어도
        # 파일·셸 도구로 MCP의 보호를 비껴가지 못한다. 남는 이 vault의 MCP 도구는 묻지 않고
        # 허용하고, 그 밖은 묻지 않고 거절한다(dontAsk). 로그인은 claude.ai 구독만 쓴다 —
        # 실행기가 이 선언을 보고 fork와 같은 자격을 적용한다(`subscription_only`).
        # ponytail: 설정 JSON이 argv에 실려, 배치 파일 CLI(npm `claude.cmd`) 뒤에서는 vault 경로의 `&`를
        # cmd가 가른다 — `growth.check_command`가 거절한다. 그런 설치를 살려야 하면 `--mcp-config`에 파일을 준다.
        config = json.dumps({"mcpServers": {MCP_NAME: {"command": python, "args": [server],
                                                       "env": {"OSK_VAULT_ROOT": root}}}})
        return [cli, "-p", "--output-format", "stream-json", "--verbose",
                "--settings", '{"forceLoginMethod":"claudeai"}', "--tools", "",
                "--strict-mcp-config", "--mcp-config", config,
                "--allowedTools", f"mcp__{MCP_NAME}", "--permission-mode", "dontAsk"]

    def subscription_only(self, argv):
        # `growth_argv`가 싣는 선언 — `--settings`의 forceLoginMethod가 claude.ai 구독이다.
        for flag, value in zip(argv, argv[1:]):
            if flag == "--settings":
                try:
                    return json.loads(value).get("forceLoginMethod") == "claudeai"
                except (ValueError, AttributeError):
                    return False
        return False


ADAPTER = Claude()
