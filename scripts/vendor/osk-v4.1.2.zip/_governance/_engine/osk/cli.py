"""osk.cli — 사용자·에이전트 공용 명령.

보호영역의 지정·해제·승인·반려는 사용자 전속 행위다(헌법 10조 1~2항) —
CLI는 대화형 확인을 강제하고, 에이전트는 이 명령을 사용자 지시 없이 실행하지
않는다. 승인/반려는 MCP 표면에 노출하지 않는다(Mechanism §6-2 2항).
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

from .core import ROOT, StaleEngineError
from . import (graph, approvals, authority, raw, scope_memory, validate, search,
               write, evictions)
from . import harness as adapters

ENGINE = Path(__file__).resolve().parents[1]     # …/_governance/_engine


def _confirm(prompt: str) -> None:
    """사용자 전속 행위의 대화형 확인 (헌법 10조 1~2항).
    표준입력이 단말이 아니면 응답이 사용자의 것임을 확인할 수 없으므로
    묻지 않고 중단한다 — 파이프·리다이렉션으로 무인 승인이 성립하지 않게
    한다. 우회 플래그는 두지 않는다(fail-closed)."""
    if not sys.stdin.isatty():
        sys.exit("중단 — 지정·해제·승인·반려는 대화형 단말에서 사용자가 직접 "
                 "확인해야 한다 (헌법 10조 1~2항)")
    if input(prompt).lower() != "y":
        sys.exit("중단")


# `osk <이름> …`의 인자를 **파싱하지 않고 그대로** 넘기는 위임 명령.
DELEGATED = {"update": "정본 릴리스로 갱신 (osk.update로 위임)",
             "release": "[정본 전용] 정식 릴리스 선언 (osk.release로 위임)"}


def _print_changeset(region: str, *, record: dict | None = None,
                     expect_work: str | None = None) -> None:
    """헌법 10조 2항 — 사용자는 **차이를 검토하여** 승인·반려한다. 해시 두 개는
    검토가 아니므로 무엇이 생기고 사라지고 바뀌는지를 파일 단위로 낸다."""
    cs = approvals.changeset(region, record=record, expect_work=expect_work)
    if cs is None:
        raise ValueError("차이를 판정할 수 없다 — 승인본을 복구한 뒤 다시 검토하라")
    moved = {m["to"] for m in cs.get("moves", [])}\
        | {m["from"] for m in cs.get("moves", [])}
    for label, key in (("추가", "added"), ("삭제", "removed"), ("수정", "modified")):
        rows = [r for r in cs[key] if r not in moved]
        if not rows:
            continue
        print(f"  {label} {len(rows)}건")
        for r in rows:
            print(f"    {r}")
    for m in cs.get("moves", []):
        print(f"  이동  {m['from']} → {m['to']}")
    eol = cs.get("eol_only") or []
    if eol:
        print(f"  그중 {len(eol)}건은 **줄바꿈만** 다릅니다 — 내용은 그대로입니다"
              f"(EOL 고정 이행). `git diff`가 빈 출력인 이유가 이것입니다.")
        for r in eol:
            print(f"    ~ {r}")
    legacy = cs.get("legacy_excluded") or []
    if legacy:
        print(f"  개정 전 승인본 — 제외 구획 항목 {len(legacy)}건이 승인본에만 "
              f"남아 있습니다(§3 4항): {', '.join(legacy[:3])}")
        print("  이 승인으로 새 형상의 승인본이 서고, 그 항목은 이후 변경집합에 "
              "들지 않습니다.")
    # 파생 표시(`legacy_excluded`·`eol_only`)는 "차이 없음" 판정에 세지 않는다 —
    # 앞의 것은 승인본 쪽 사정이고, 뒤의 것은 `modified`의 부분집합이다.
    if not any(v for k, v in cs.items()
               if k not in ("legacy_excluded", "eol_only")):
        print("  (파일 단위 차이 없음)")


def _emit(obj) -> None:
    """결과를 **UTF-8 바이트로** 낸다. 이 경로의 소비자는 사람이 아니라 훅이고,
    Windows 콘솔의 기본 코드페이지를 타면 한글이 든 위반 메시지에서
    `UnicodeEncodeError`로 죽는다 — 기록은 남았는데 보고가 죽는 꼴이 된다."""
    sys.stdout.buffer.write(
        (json.dumps(obj, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    sys.stdout.buffer.flush()


def _raw_stdin():
    """훅이 보내는 봉투를 읽는다. **바이트로 읽어 UTF-8로 푼다** — 콘솔
    인코딩을 타면 기록이 그 기기의 코드페이지에 인질이 되는데, `_raw/`는
    append-only라 나중에 고칠 수도 없다."""
    if sys.stdin.isatty():
        sys.exit('stdin으로 JSON 봉투를 넘겨라 (훅·파이프). 형식: '
                 '{"rounds": [{"user": "…", "agent": "…"}, …]}')
    data = sys.stdin.buffer.read()
    if not data.strip():
        sys.exit("빈 stdin — 이을 라운드가 없다")
    try:
        return json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        sys.exit(f"stdin 판독 실패 — {type(e).__name__}: {e}")


def _raw_rounds(env) -> list:
    """봉투에서 라운드 목록을 꺼낸다. 배열 그대로 · `rounds` 키 · 라운드 하나를
    모두 받는다 — 한 라운드만 보내는 흔한 경우에 감싸기를 강요하지 않는다."""
    if isinstance(env, list):
        return env
    if isinstance(env, dict):
        if isinstance(env.get("rounds"), list):
            return env["rounds"]
        if "user" in env or "agent" in env:
            return [env]
    return []


def _raw_cmd(a) -> None:
    """`osk raw` — 하네스 훅이 실제 대화 바이트를 넣는 경로.

    표면의 `append_raw`는 에이전트가 **서술한** 라운드를 받는다. 헌법 4조
    3항이 명하는 것은 전량 포착이므로, 전사를 그대로 나를 수 있는 경로가
    따로 필요하다 — 같은 통로·같은 계약을 쓰고 입력만 기계에서 온다."""
    if a.raw_cmd == "migrate":
        try:
            _emit(raw.migrate(apply=a.apply))
        except (write.WriteError, StaleEngineError, OSError) as e:
            _emit({"ok": False, "violations": getattr(e, "violations", [str(e)])})
            sys.exit(1)
        return
    if a.raw_cmd == "status":
        try:
            _emit(raw.record_state(a.session, a.record, a.space))
        except (write.WriteError, StaleEngineError) as e:
            _emit({"ok": False, "violations": e.violations})
            sys.exit(1)
        return
    env = _raw_stdin()
    meta = env if isinstance(env, dict) else {}
    # 플래그가 봉투를 이긴다 — 봉투는 전사 생성기가, 플래그는 그것을 거는
    # 사람이 쓴다. 어느 자리로 왔는지 모호하면 거는 쪽의 뜻을 따른다.
    session = a.session or meta.get("session")
    record = a.record or meta.get("record")
    space = a.space or meta.get("space")
    missing = [k for k, v in (("session", session), ("record", record)) if not v]
    if missing:
        sys.exit(f"필수 값 없음: {', '.join(missing)} — 플래그나 봉투로 준다")
    try:
        _emit(raw.append_rounds(session, record, _raw_rounds(env), space))
    except (write.WriteError, StaleEngineError) as e:
        _emit({"ok": False, "violations": e.violations})
        sys.exit(1)


def _integration_cmd(a) -> None:
    """Own-conversation capture/review; shared scope writes do not acknowledge it."""
    from . import integration
    try:
        if a.integration_cmd in ("list", "catchup"):
            fn = integration.list_pending if a.integration_cmd == "list" else integration.catchup
            result = fn(limit=a.limit)
        elif a.integration_cmd == "capture":
            result = integration.capture(a.harness, a.conversation,
                                         a.transcript, a.session, a.space)
        elif a.integration_cmd == "prompt":
            result = integration.prompt(a.harness, a.conversation)
        elif a.integration_cmd == "review":
            data = _raw_stdin()
            if not isinstance(data, dict):
                raise ValueError("review stdin must be a JSON object")
            result = integration.acknowledge(
                a.harness, a.conversation, data["through"], data["outcome"],
                data["reason"], targets=data.get("targets"))
        else:
            result = integration.status(a.harness, a.conversation)
        _emit(result)
        if not result.get("ok", True):
            sys.exit(1)
    except (write.WriteError, StaleEngineError, ValueError, KeyError, OSError) as e:
        _emit({"ok": False, "violations": getattr(e, "violations", [str(e)])})
        sys.exit(1)


def _growth_cmd(a) -> None:
    """Bounded scheduler entry; the subprocess still uses MCP for graph writes."""
    from . import growth
    try:
        if a.growth_cmd in ("plan", "prompt"):
            result = growth.plan(limit=a.limit)
            if a.growth_cmd == "prompt":
                sys.stdout.buffer.write(growth.prompt(result).encode("utf-8"))
                return
        elif a.growth_cmd == "review":
            result = growth.review(a.key, a.outcome, target=a.target,
                                   reason=a.reason, manifest=a.manifest)
        elif a.growth_cmd == "checkpoint":
            result = growth.checkpoint(growth._strict_json(
                Path(a.file).read_text(encoding="utf-8-sig")))
        else:
            command = json.loads(Path(a.command_file).read_text(encoding="utf-8-sig"))
            # argv 검사는 실행기의 계약 하나(`growth.check_command`)를 따른다 — 여기서 따로
            # 검사하면 둘이 어긋난다. 빈 인자도 argv다(Claude의 `--tools ""`).
            result = (growth.check_command(command) if a.check else
                      growth.run(command, limit=a.limit, timeout=a.timeout))
        _emit(result)
        if not result.get("ok", True):
            sys.exit(1)
    except (write.WriteError, StaleEngineError, ValueError, OSError) as e:
        _emit({"ok": False, "violations": getattr(e, "violations", [str(e)])})
        sys.exit(1)


def _fork_cmd(a) -> None:
    """`osk fork doctor` — route()의 판정과 근거를 **읽기만** 한다. 상태·설정을 쓰지 않는다."""
    from . import response_growth
    try:
        reports = [response_growth.doctor(h, a.session, a.transcript)
                   for h in ([a.harness] if a.harness else adapters.fork_names())]
    except (ValueError, OSError) as e:
        _emit({"ok": False, "violations": [str(e)]})
        sys.exit(1)
    if a.json:
        return _emit(reports)
    lines = []
    for r in reports:
        v = r.pop("verdict")
        lines.append(f"{r.pop('harness')}: {v['mode']}" + (f" — {v['reason']}" if v["reason"] else ""))
        lines += [f"  {k}: " + (", ".join(f"{x}={y}" for x, y in val.items())
                                if isinstance(val, dict) else str(val)) for k, val in r.items()]
    sys.stdout.buffer.write(("\n".join(lines) + "\n").encode("utf-8"))
    sys.stdout.buffer.flush()


def _doctor_cmd(a) -> None:
    """`osk doctor` — 이 기기의 하네스 연결을 **읽기만** 하며 점검한다. 실패 항목이
    있으면 종료코드 1이다(경고는 0)."""
    from . import doctor
    rep = doctor.report(a.harness)
    if a.json:
        _emit(rep)
    else:
        sys.stdout.buffer.write(doctor.text(rep).encode("utf-8"))
        sys.stdout.buffer.flush()
    if not rep["ok"]:
        sys.exit(1)


def _organization_cmd(a) -> None:
    from . import organization
    try:
        if a.organization_cmd == "review":
            data = _raw_stdin()
            if not isinstance(data, dict):
                raise ValueError("organization review needs a JSON object")
            result = organization.review(**data)
        else:
            result = organization.plan(a.scope, record=not a.preview)
            if result.get("key"):   # 훅은 규칙의 요지만 싣는다 — 전문은 작업 직전 여기서 읽는다
                result = {**result, "guidance": organization.guidance()}
        _emit(result)
    except (write.WriteError, StaleEngineError, ValueError, KeyError, TypeError, OSError) as exc:
        _emit({"ok": False, "violations": [str(exc)]})
        sys.exit(1)


def _sm_cmd(a) -> None:
    """`osk sm` — scope 기억. `show`는 SessionStart 훅이 부르는 자리다.

    **`show`의 기본 출력은 JSON이 아니라 전문 그대로다.** 훅은 이 값을 문맥에
    그대로 넣으므로, 감싸는 껍데기가 있으면 훅마다 벗기는 코드를 쓰게 된다.
    결속이 없으면 빈 출력이고 주입할 것도 없다 — 그것은 오류가 아니다."""
    if a.sm_cmd == "show":
        # 훅이 세션 시작마다 부르는 자리다. 결속이 아직 없는 새 저장소가
        # **첫 호출의 정상 상태**이므로, 거기서 위반 JSON을 내면 훅이 그것을
        # 문맥에 넣거나 종료코드를 보고 조용히 건너뛴다 — 둘 다 나쁘다.
        # 착지를 못 정하면 주입할 것이 없을 뿐이니 빈 출력으로 넘긴다.
        try:
            st = scope_memory.read(a.session, a.space)
        except (write.WriteError, StaleEngineError) as e:
            if a.json:
                _emit({"ok": False, "violations": e.violations, **e.extra})
                sys.exit(1)
            return                      # 빈 stdout · 종료코드 0
        if a.json:
            _emit(st)
        else:
            sys.stdout.buffer.write(st["text"].encode("utf-8"))
            sys.stdout.buffer.flush()
        return
    try:
        _emit(scope_memory.replace(a.session, _stdin_text(), a.expect_hash, a.space))
    except (write.WriteError, StaleEngineError) as e:
        _emit({"ok": False, "violations": e.violations, **e.extra})
        sys.exit(1)


def _tidy_cmd(a) -> None:
    """`osk tidy` — 정돈 (Mechanism §9-3). `list`는 미처분, `prompt`는 전용
    세션의 프롬프트(전문 그대로 — 붙여 넣는 값이다), `settle`은 처분 기록.

    settle은 에이전트가 부르는 **기계 경로**다 — 상주 스키마에 여유가 없어
    표면 도구로 두지 않았고, 대화형 확인을 걸면 훅이 지시한 첫 도구 호출에
    실을 수 없다. 권위 행위가 아니다(§6-2 2항의 넷이 아니다)."""
    try:
        if a.tidy_cmd == "list":
            rows = evictions.unsettled(a.scope)
            _emit({"status": evictions.status(), "items": [
                {"rid": r["rid"], "scope": r.get("scope"), "session": r.get("session"),
                 "at": r.get("at"), "age_days": evictions.age_days(r),
                 "text": r.get("text")} for r in rows]})
        elif a.tidy_cmd == "prompt":
            out = evictions.tidy_prompt(a.scope, sys.executable, str(ENGINE))
            sys.stdout.buffer.write(out.encode("utf-8"))
            sys.stdout.buffer.flush()
        else:
            rec = evictions.settle(a.of, a.outcome, a.target)
            _emit({"ok": True, "rid": rec["rid"], "of": a.of,
                   "outcome": a.outcome, "target": rec.get("target")})
    except ValueError as e:
        sys.exit(f"[중단] {e}")


def _stdin_text() -> str:
    """본문은 **바이트로 읽어 UTF-8로 푼다** — 콘솔 인코딩을 타면 그 기기에서
    쓴 작업 기억만 다른 바이트가 되고, 상한도 해시도 어긋난다."""
    if sys.stdin.isatty():
        sys.exit("본문을 stdin으로 넘겨라 (훅·파이프).")
    try:
        return sys.stdin.buffer.read().decode("utf-8")
    except UnicodeDecodeError as e:
        sys.exit(f"stdin 판독 실패 — {e}")


def build_parser() -> argparse.ArgumentParser:
    """`osk`의 명령 정본 — 파서 구성만 떼어 둔다.

    검증기가 안내문(`docs/SETUP.md`)의 CLI 표를 이것과 대조한다. 구판은
    소스 문자열을 정규식으로 훑었는데, 정의 형태가 조금만 달라도 조용히
    빠졌다 — `DELEGATED`의 두 항목은 들여쓰기가 달라 **하나도 걸리지
    않았다**(실측). 명령이 무엇인지 아는 것은 파서이므로 파서에게 묻는다.
    """
    ap = argparse.ArgumentParser(prog="osk")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("validate", help="검증기 수트 전체 실행")
    sub.add_parser("status", help="체계 현황")
    sub.add_parser("rechecks", help="근거 재검토 후보 전체 (시행령 §7 2항)")
    p = sub.add_parser("search", help="작업 검색")
    p.add_argument("query"); p.add_argument("-k", type=int, default=8)
    p = sub.add_parser("view", help="열람 검색")
    p.add_argument("query"); p.add_argument("-k", type=int, default=8)
    p = sub.add_parser("check", help="권한 사전 검사")
    p.add_argument("action")
    # `raw`는 하네스 훅이 부르는 **기계 경로**다 — 대화형 확인을 걸지 않는다.
    # 사용자 전속 행위가 아니라 표면의 `append_raw`와 같은 행위이고, 거는
    # 순간 훅에서 쓸 수 없어 자동 포착이 성립하지 않는다.
    p = sub.add_parser("raw", help="`_raw/` 세션 기록 (훅 경로)")
    rs = p.add_subparsers(dest="raw_cmd", required=True)
    q = rs.add_parser("migrate", help="기존 Markdown 원료의 숨김 .txt 이관 계획")
    q.add_argument("--apply", action="store_true", help="계획을 적용; 생략하면 읽기 전용")
    q = rs.add_parser("append", help="라운드 append — 본문은 stdin JSON")
    q.add_argument("--session"); q.add_argument("--record")
    q.add_argument("--space", default=None)
    q = rs.add_parser("status", help="기록의 현재 라운드 수 — 중복 방지용")
    q.add_argument("--session", required=True)
    q.add_argument("--record", required=True)
    q.add_argument("--space", default=None)

    p = sub.add_parser("integration", help="대화별 포착·통합 대기 (scope 공유 기억과 별개)")
    ins = p.add_subparsers(dest="integration_cmd", required=True)
    for name in ("list", "catchup"):
        q = ins.add_parser(name)
        q.add_argument("--limit", type=int, default=20)
    for name in ("capture", "status", "prompt", "review"):
        q = ins.add_parser(name)
        q.add_argument("--harness", choices=adapters.NAMES, required=True)
        q.add_argument("--conversation", required=True, help="실제 하네스 대화 ID")
        if name == "capture":
            q.add_argument("--transcript", required=True)
            q.add_argument("--session", required=True, help="고정 scope 라우팅 키")
            q.add_argument("--space", default=None)

    p = sub.add_parser("organization", help="Scope 참조·허브 정돈의 선택과 검증")
    osub = p.add_subparsers(dest="organization_cmd", required=True)
    q = osub.add_parser("plan")
    q.add_argument("--scope", required=True)
    q.add_argument("--preview", action="store_true")
    osub.add_parser("review")

    p = sub.add_parser("growth", help="Scope→Domain 비교·검토·한정 실행")
    gs = p.add_subparsers(dest="growth_cmd", required=True)
    for name in ("plan", "prompt", "run"):
        q = gs.add_parser(name)
        q.add_argument("--limit", type=int, default=3)
        if name == "run":
            q.add_argument("--command-file", required=True, help="에이전트 argv 배열 JSON 파일")
            q.add_argument("--timeout", type=int, default=600)
            q.add_argument("--check", action="store_true", help="실행 파일만 확인; 모델·포착·대장 쓰기 없음")
    q = gs.add_parser("review")
    q.add_argument("key")
    q.add_argument("outcome", choices=("preserved", "no_value", "deferred"))
    q.add_argument("--target", default=None)
    q.add_argument("--reason", required=True)
    q.add_argument("--manifest", required=True, help="실행 전에 고정한 plan rid")
    q = gs.add_parser("checkpoint", help="완료한 개별 작업의 명시적 검토를 즉시 기록")
    q.add_argument("--file", required=True, help="UTF-8 osk_reviews JSON 파일")

    p = sub.add_parser("fork", help="구독 fork 준비 점검 (읽기 전용)")
    fs = p.add_subparsers(dest="fork_cmd", required=True)
    q = fs.add_parser("doctor", help="route()의 판정과 근거 — 상태·설정을 쓰지 않는다")
    q.add_argument("--harness", choices=adapters.fork_names(), default=None, help="기본: 모두")
    q.add_argument("--session", default=None, help="실제 하네스 대화 ID")
    q.add_argument("--transcript", default=None, help="전사 경로 (기본: 훅과 같은 방식으로 찾는다)")
    q.add_argument("--json", action="store_true")

    p = sub.add_parser("doctor", help="이 기기의 하네스 연결 점검 — MCP·훅 등록, 훅 실행, 전달, "
                                      "판본, fork (읽기 전용)")
    p.add_argument("--harness", choices=adapters.NAMES, default=None, help="기본: 모두")
    p.add_argument("--json", action="store_true")

    # `wm`도 기계 경로다 — SessionStart 훅이 `show`를 불러 전문을 주입한다.
    p = sub.add_parser("sm", help="scope 기억 (훅 경로)")
    ws = p.add_subparsers(dest="sm_cmd", required=True)
    q = ws.add_parser("show", help="전문 출력 — 훅이 그대로 문맥에 주입한다")
    q.add_argument("--session", required=True)
    q.add_argument("--space", default=None)
    q.add_argument("--json", action="store_true", help="상태 전체를 JSON으로")
    q = ws.add_parser("write", help="전체 치환 — 본문은 stdin")
    q.add_argument("--session", required=True)
    q.add_argument("--expect-hash", dest="expect_hash", default=None)
    q.add_argument("--space", default=None)

    # `tidy`도 기계 경로다 — 훅이 지시한 처분을 에이전트가 `settle`로 적는다.
    p = sub.add_parser("tidy", help="정돈 — 미처분 퇴출 항목 (Mechanism §9-3)")
    ts = p.add_subparsers(dest="tidy_cmd", required=True)
    q = ts.add_parser("list", help="scope별 미처분 evict 목록과 현황")
    q.add_argument("--scope", default=None)
    q = ts.add_parser("prompt", help="전용 정돈 세션의 프롬프트 — 새 세션에 붙여 넣는다")
    q.add_argument("--scope", default=None, help="기본: 가장 오래 밀린 scope")
    q = ts.add_parser("settle", help="처분 기록 — 노드로 증류·기존 노드에 통합·폐기")
    q.add_argument("of", help="대상 evict의 rid")
    q.add_argument("outcome", choices=evictions.OUTCOMES)
    q.add_argument("--target", default=None, help="노드 제목 (폐기면 없음)")

    p = sub.add_parser("validators",
                       help="[사용자 전속] 검증기 활성화 현황·전환 (Mechanism §6-1)")
    p.add_argument("--activate", metavar="RULE")
    p.add_argument("--deactivate", metavar="RULE")
    p.add_argument("--reason", default="")
    p = sub.add_parser("protect", help="[사용자 전속] 보호영역 지정")
    p.add_argument("region"); p.add_argument("--reason", default="")
    p = sub.add_parser("unprotect", help="[사용자 전속] 보호영역 해제")
    p.add_argument("region"); p.add_argument("--reason", default="")
    p = sub.add_parser("approve", help="[사용자 전속] 변경집합 승인")
    p.add_argument("region"); p.add_argument("--reason", default="")
    p = sub.add_parser("revert", help="[사용자 전속] 변경집합 반려(원상 복원)")
    p.add_argument("region"); p.add_argument("--reason", default="")
    p = sub.add_parser("store-reconcile",
                       help="내용 주소 저장소를 파일 이름 기준으로 판독·이행")
    p.add_argument("--apply", action="store_true",
                   help="판독만 하지 않고 색인·작업 트리를 실제로 맞춘다")
    for name, helptext in DELEGATED.items():     # `osk --help` 목록에만 쓰인다
        sub.add_parser(name, help=helptext)      # — 실제 파싱은 위에서 지났다
    return ap


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)

    # 위임 명령은 파서에 넣기 전에 가른다. `argparse.REMAINDER`로 받으면 잔여의
    # 첫 토큰이 `-`로 시작할 때 상위 파서가 그것을 자기 옵션으로 먼저 해석해
    # `osk update --apply`가 "unrecognized arguments: --apply"로 죽는다(실측).
    # 위임의 계약은 "해석하지 않고 넘긴다"이므로, 해석하는 자리를 아예 지난다 —
    # `--help`도 그대로 넘어가 위임 대상 자신의 사용법이 나온다.
    if argv and argv[0] in DELEGATED:
        rest = argv[1:]
        if argv[0] == "update":
            from . import update as _u
            return _u.main(rest)
        from . import release as _r
        return _r.main(rest)

    ap = build_parser()
    a = ap.parse_args(argv)

    if a.cmd == "validate":
        validate.main()
    elif a.cmd == "rechecks":
        from . import rechecks
        items, pending = rechecks.candidates()
        _emit({"baseline_pending": pending, "count": len(items), "items": items,
               "close": rechecks.CLOSE})
    elif a.cmd == "validators":
        # 활성화·해제는 사용자 전속이다(시행령 §11 3항) — 표면(MCP)에는 없다.
        known = ["cluster-overview"]
        rule = a.activate or a.deactivate
        if rule:
            if a.activate and a.deactivate:
                sys.exit("중단 — --activate와 --deactivate는 함께 줄 수 없다")
            if rule not in known:
                sys.exit(f"모르는 규칙: {rule} — 가능한 규칙: {', '.join(known)}")
            kind = "activate" if a.activate else "deactivate"
            cur = "활성" if validate.validator_active(rule) else "비활성"
            print(f"규칙 {rule}: 현재 {cur}")
            if kind == "activate":
                _confirm(f"{rule}을(를) 활성화하면 위반이 검증기 verdict에 "
                         f"산입됩니다(시행령 §11 2항). 활성화합니까? [y/N] ")
            else:
                _confirm(f"{rule}을(를) 해제하면 같은 검사가 보고 전용으로 "
                         f"돌아갑니다. 해제합니까? [y/N] ")
            from .core import VALIDATORS, ledger_append
            rec = ledger_append(VALIDATORS, {
                "kind": kind, "rule": rule, "reason": a.reason})
            print("기록 등재:", rec["rid"])
        else:
            for r in known:
                print(f"{r}: "
                      f"{'활성' if validate.validator_active(r) else '비활성'}")
    elif a.cmd == "status":
        idx = graph.Index()
        regions = approvals.protected_regions()
        try:
            # 건너뛴 정돈은 보인다(§9-3 3항) — scope별 미처분·가장 오래된 나이
            ev = evictions.status()
        except Exception as e:                  # 대장 손상은 현황을 막지 않는다
            ev = {"error": str(e)}
        try:
            from . import scope_memory
            recovery = scope_memory.recovery_status()
        except Exception as e:
            recovery = {"error": str(e)}
        try:
            # 포착이 막힌 대화 — 훅은 막힌 동안 한 줄만 싣는다(§9-3 3항)
            from . import integration
            capture = integration.blocked()
        except Exception as e:
            capture = {"error": str(e)}
        try:
            # 판본과 마지막 릴리스 확인 — 네트워크에 닿지 않는다(`osk.update --check`)
            from . import update_check
            release = update_check.report()
        except Exception as e:
            release = {"error": str(e)}
        gw = approvals.governance_warning()
        print(json.dumps({
            "nodes": len(idx.nodes),
            "protected_regions": {r: approvals.state(r) for r in regions},
            "delegations": [d["title"] for d in authority.enumerate_delegations()
                            if d["effective"]],
            "evictions": ev,
            "scope_recovery": recovery,
            "capture_blocked": capture,
            "update": release,
            **({"warnings": [gw]} if gw else {}),
            "root": str(ROOT),
        }, ensure_ascii=False, indent=2))
    elif a.cmd in ("search", "view"):
        s = search.Searcher()
        rows = s.work_search(a.query, a.k) if a.cmd == "search"\
            else s.view_search(a.query, a.k)
        print(json.dumps(rows, ensure_ascii=False, indent=2))
    elif a.cmd == "check":
        print(json.dumps(authority.check(a.action), ensure_ascii=False, indent=2))
    elif a.cmd == "raw":
        return _raw_cmd(a)
    elif a.cmd == "integration":
        return _integration_cmd(a)
    elif a.cmd == "growth":
        return _growth_cmd(a)
    elif a.cmd == "organization":
        return _organization_cmd(a)
    elif a.cmd == "fork":
        return _fork_cmd(a)
    elif a.cmd == "doctor":
        return _doctor_cmd(a)
    elif a.cmd == "sm":
        return _sm_cmd(a)
    elif a.cmd == "tidy":
        return _tidy_cmd(a)
    elif a.cmd == "protect":
        st = approvals.state(a.region)
        print(f"보호영역 지정: {a.region}\n현재 상태: {st}")
        _confirm("지정 시점의 작업본이 초기 승인본이 됩니다. 지정합니까? [y/N] ")
        rec = approvals.protect(a.region, a.reason)
        print("지정 등재:", rec["rid"], "| 승인본:", rec["accepted"])
    elif a.cmd == "unprotect":
        _confirm(f"{a.region} 보호를 해제합니까? (clean 상태에서만) [y/N] ")
        rec = approvals.unprotect(a.region, a.reason)
        print("해제 등재:", rec["rid"])
    elif a.cmd == "approve":
        st = approvals.state(a.region)
        if st == "stale":
            # 봉합 승인 — 승인 기록이 갈렸다(다기기 병합). 사용자가 갈래를 보고
            # 현재 작업본을 새 승인본으로 삼는다(Mechanism §3 5항).
            forks = approvals.divergence(a.region)
            work = approvals.working_tree_hash(a.region)
            if not forks or work is None:
                raise ValueError("갈래 또는 작업본을 판정할 수 없다 — 봉합하지 않았다")
            print(f"영역이 stale입니다 — 승인 기록이 {len(forks)}갈래로 갈렸습니다.")
            for f in forks:
                print(f"  갈래 {f.get('rid')} {f.get('kind')} "
                      f"base={f.get('base')} accepted={f.get('accepted')} at={f.get('at')}")
                if f.get("kind") == "unprotect":
                    print("  보호 해제 갈래 — 해제 직전 승인본과 현재 작업본의 차이:")
                _print_changeset(a.region, record=f, expect_work=work)
            print(f"현재 작업본: {work}")
            _confirm("이 작업본을 새 승인본으로 삼아 갈래를 봉합합니까? [y/N] ")
            # 검토한 갈래 집합을 프롬프트 **전에** 고정해 넘긴다 — 프롬프트
            # 사이 동기화로 새 갈래가 오면 봉합이 거부된다(본 적 없는 갈래를
            # 함께 봉합하지 않는다).
            rec = approvals.approve(a.region, None, expect_work=work,
                                    reason=a.reason or "분기 봉합",
                                    seal_heads=[f["rid"] for f in forks])
            print("봉합 승인 등재:", rec["rid"], "| 새 승인본:", rec["accepted"])
            return
        if st != "pending":
            sys.exit(f"승인할 변경집합이 없다 — 상태: {st}")
        # 양측 CAS의 두 예상값을 확인 프롬프트 **전에** 고정한다 — 프롬프트
        # 사이에 작업본이 바뀌면 approve가 거부한다(검토한 것만 승인).
        base = approvals.approved_hash(a.region)
        work = approvals.working_tree_hash(a.region)
        print(f"승인 대상: {a.region}\n승인본→작업본: {base} → {work}")
        _print_changeset(a.region, expect_work=work)
        _confirm("검토한 이 변경집합을 승인본으로 받아들입니까? [y/N] ")
        rec = approvals.approve(a.region, base, expect_work=work, reason=a.reason)
        print("승인 등재:", rec["rid"], "| 새 승인본:", rec["accepted"])
    elif a.cmd == "revert":
        st = approvals.state(a.region)
        if st != "pending":
            sys.exit(f"반려할 변경집합이 없다 — 상태: {st}")
        # 반려도 파괴적이므로 승인과 **같은 결속**을 쓴다 — 버릴 변경집합
        # (승인본→작업본)을 프롬프트 **전에** 고정한다. 프롬프트 사이에
        # 에이전트가 더 쓴 변경이 '사용자가 승인한 반려'에 묶여 사라지지 않게.
        base = approvals.approved_hash(a.region)
        work = approvals.working_tree_hash(a.region)
        print(f"반려 대상: {a.region} — 작업본을 승인본으로 원상 복원합니다")
        print(f"버릴 변경집합(작업본→승인본): {work} → {base}")
        _print_changeset(a.region, expect_work=work)
        _confirm("에이전트의 변경을 버리고 승인본으로 되돌립니까? [y/N] ")
        rec = approvals.revert(a.region, base, expect_work=work, reason=a.reason)
        print("반려 등재:", rec["rid"], "| 복원 승인본:", rec["base"])
    elif a.cmd == "store-reconcile":
        # EOL 이행의 저장소 몫. `-text`를 얻은 구획은 어느 쪽을 무조건 택해도
        # 틀린다(작업 트리를 stage하면 옳던 blob이 깨지고, 통째로 빼면 깨진
        # blob이 작업 트리를 덮는다) — 내용 주소에는 파일 이름이라는 심판이
        # 있으므로 그것으로 가른다.
        import subprocess as _sp
        _root = str(ROOT)

        def _index_bytes(rel):
            r = _sp.run(["git", "-C", _root, "cat-file", "blob", ":" + rel],
                        capture_output=True)
            return r.stdout if r.returncode == 0 else None

        def _apply(kind, rel):
            if kind == "stage":
                _sp.run(["git", "-C", _root, "add", "--", rel], check=True)
            else:
                _sp.run(["git", "-C", _root, "checkout", "--", rel], check=True)

        res = approvals.reconcile_store(
            _index_bytes, _apply if a.apply else None)
        print(f"객체 {res['checked']}건 판독 — 색인을 고칠 것 {len(res['stage'])}, "
              f"작업 트리를 고칠 것 {len(res['restore'])}, "
              f"판정 불능 {len(res['broken'])}")
        for rel in res["broken"][:20]:
            print("  판정 불능(양쪽 다 이름과 다름):", rel)
        if not res["ok"]:
            sys.exit("중단 — 어느 쪽도 이름의 digest와 맞지 않는 객체가 있다. "
                     "추측으로 고르지 않았고 아무것도 바꾸지 않았다. 그 객체를 "
                     "참조하는 승인본은 해제 후 재지정이 회복 경로다.")
        if not a.apply:
            print("판독만 했다 — 이행하려면 --apply")
        elif res["stage"] or res["restore"]:
            print("이행했다. 색인 변경은 이어지는 commit에 담긴다.")
    # update·release는 파서 앞에서 위임된다 — 여기에 분기를 두면 죽은 코드다.


if __name__ == "__main__":
    main()
