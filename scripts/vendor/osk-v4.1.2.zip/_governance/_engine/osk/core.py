"""osk.core — vault 루트·시각·식별자·대장 공통 규약.

구현 근거: Mechanism §1(배치)·§2(식별과 시간)·§3(대장 — 인과 DAG).
파일이 정본이고 엔진 상태는 전부 파일에서 재계산한다(시행령 §11 1항).

대장의 인과 모델 (Mechanism §3):
- 각 기록은 `parents`로 하나 이상의 직전 head를 참조한다. 평소에는 1개,
  다기기 병합 직후의 첫 기록은 모든 head를 참조해 분기를 봉합한다(병합 앵커).
- `parents` 도입 전의 유산 기록은 파일 순서를 인과 순서로 간주한다(단일 기기
  이력). 도입 사건(첫 parents 보유 기록 = 앵커)부터 명시 인과가 정본이며,
  **앵커 이후에는 파일 순서 추정을 쓰지 않는다** — parents 없는 기록은 고립
  루트로 강등한다(구 엔진이 다른 클론에서 쓴 행이 병합돼 들어와도 가짜 인과를
  얻지 못한다). 고립 루트도 head이므로 사용자의 새 봉합 기록이 해소한다.
- rid는 잠금 안에서 대장의 정본상 최대 rid로부터 단조 생성한다 — 물리적
  마지막 행이 아니라 최대값이 바닥이다.
- 판정은 rid 정렬이 아니라 인과 극대(causal maxima)로 한다. 같은 노드의
  극대 기록이 유일하지 않으면(비교 불능 분기 또는 순환) 보수적으로
  미확정이다. 이후 모든 head를 조상으로 갖는 새 기록(사용자의 봉합)이
  유일 극대가 되어 해소한다.

손상과 해소 가능성 (fail-closed의 두 갈래):
- **정규화로 해소 가능한 이상** — 자기 참조·미지 rid 참조·전방 참조(파일
  순서상 뒤를 가리키는 parents)는 간선을 잘라 고립 루트로 강등한다. 순환이
  원천 차단되고(항상 DAG), 새 봉합 기록으로 해소되는 길이 남는다.
- **구조 손상** — rid 부재·rid 형식 위반·rid 중복은 기록의 동일성 자체가
  깨진 상태다. 판정은 fail-closed(미확정)로 두되 `ledger_damage`가 이를
  표면화하고, 회복은 Mechanism §3 8항의 수동 복구가 담당한다. 이 상태에서는
  새 기록의 append도 거부한다(손상 위에 이력을 더 쌓지 않는다).
"""
from __future__ import annotations
import errno, hashlib, json, os, random, re, shlex, string, subprocess, sys, tempfile, time
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from . import epoch
from .layout import space_roots, adapt_path
from ._portalock import lock_exclusive, unlock

B36 = string.digits + string.ascii_lowercase
KST = ZoneInfo("Asia/Seoul")          # Mechanism §2 2항 — 표기 시간대는 KST 고정


def vault_root() -> Path:
    env = os.environ.get("OSK_VAULT_ROOT")
    if env:
        return Path(env).resolve()
    # <vault>/_governance/_engine/osk/core.py — 4단계 위가 vault 루트다
    return Path(__file__).resolve().parent.parent.parent.parent


ROOT = vault_root()
SPACE_ROOTS = space_roots(ROOT)
SCOPE, DOMAIN, PERSON = (SPACE_ROOTS[k] for k in ("Scope", "Domain", "Person"))
LEDGER = ROOT / SCOPE / "Workbench/_ledger"
SIGNATURES = LEDGER / "signatures.jsonl"
CANDIDATES = LEDGER / "case" / "candidates.jsonl"
PINS = LEDGER / "pins.jsonl"
VALIDATORS = LEDGER / "validators.jsonl"   # 검증기 활성화 기록 (Mechanism §6-1)
ROUTING = LEDGER / "routing.jsonl"       # 세션→scope 라우팅 (Mechanism §6-2 3항)
EVICTIONS = LEDGER / "evictions.jsonl"   # 퇴출 기록부 (Mechanism §9-2 12항)
_MUTATION_LOCK_PATH: Path | None = None


def local_lock_path(name: str, root: Path | None = None) -> Path:
    """기기 로컬 잠금 파일의 경로 — **추적 트리 밖으로만** 고른다.

    엔진의 primitive다. 동기화는 이 체계의 필수 구성요소가 아니라 쓰는 사람만
    쓰는 편의 모듈이므로, 엔진이 자기 잠금 자리를 알기 위해 그쪽을 부르지
    않는다(의존은 반대 방향이다 — 동기화가 이 함수를 쓴다).

    자리는 git 디렉터리를 **파일시스템으로 읽어** 정한다(git 실행 없음 —
    데몬 tick마다 subprocess를 띄우지 않고 Windows 콘솔 깜빡임도 없다):
    `<root>/.git`이 디렉터리면 그것, 파일이면 `gitdir:` 대상(그 안에
    `commondir`가 있으면 worktree이므로 그쪽을 따라간다). git이 없으면 루트
    경로 해시를 키로 한 임시 디렉터리다(기기 안 vault별 유일).

    추적 트리 안에 두지 않는 이유: `git add -A`에 딸려 들어가고, checkout이
    그 pathname의 inode를 갈면 "같은 경로 = 같은 mutex" 전제가 깨진다."""
    r = Path(root) if root is not None else ROOT
    dot = r / ".git"
    try:
        if dot.is_dir():
            return dot / name
        if dot.is_file():
            head = dot.read_text(encoding="utf-8").strip()
            if head.startswith("gitdir:"):
                g = Path(head.split(":", 1)[1].strip())
                if not g.is_absolute():
                    g = (r / g).resolve()
                common = g / "commondir"
                if common.is_file():
                    c = Path(common.read_text(encoding="utf-8").strip())
                    g = c if c.is_absolute() else (g / c).resolve()
                if g.is_dir():
                    return g / name
    except OSError:
        pass                                  # 판독 불가 → 임시 디렉터리로
    key = hashlib.sha256(str(r).encode("utf-8")).hexdigest()[:16]
    stem = name.rsplit(".", 1)[0]
    return Path(tempfile.gettempdir()) / f"{stem}-{key}.lock"


def mutation_lock_path() -> Path:
    """working-tree 변경 상호배제 잠금의 경로 — 동기화(sync·update)가 잡는
    `osk-mutation.lock`과 **같은 파일**이다.

    이름을 공유해야 데몬의 `pull(rebase)`가 반려의 파괴 구간과 경합하지 않는다.
    프로세스마다 한 번만 해석한다 — 이 잠금은 모든 노드 쓰기가 잡는다."""
    global _MUTATION_LOCK_PATH
    if _MUTATION_LOCK_PATH is None:
        _MUTATION_LOCK_PATH = local_lock_path("osk-mutation.lock")
    return _MUTATION_LOCK_PATH


class StaleEngineError(RuntimeError):
    """이 프로세스가 적재한 엔진이 디스크의 것과 다르다 — 변경을 막았다.

    `write.WriteError`와 같은 모양(`violations`·`extra`)을 갖는다. 표면의
    거부 렌더러가 한 벌로 두 가지를 다루게 하기 위함이며, 호출자에게는 둘 다
    "아무것도 쓰지 않았다"로 같다."""

    def __init__(self, message: str, violations: list[str] | None = None):
        super().__init__(message)
        self.violations = [message] + list(violations or [])
        self.extra: dict = {}


def _fence() -> None:
    """이 프로세스가 낡았으면 아무것도 쓰지 못하게 한다.

    **잠금을 잡은 직후**에 판정한다 — 잠금 밖에서 재면 재고 나서 잡기까지
    사이에 갱신이 끼어들 수 있고, 그러면 판정은 통과했는데 쓰기는 낡은
    코드가 하는 창이 열린다.

    갱신(`update`)과 동기화(`sync`)는 이 관문을 지나지 않는다. 그 둘은 잠금
    파일만 공유할 뿐 이 클래스를 쓰지 않으며, 그래야 한다 — 엔진을 교체하는
    당사자를 낡음으로 막으면 갱신에서 빠져나올 길이 없다."""
    # 판은 **한 번만** 잰다. 두 번 재면 그 사이에 갱신이 끝났을 때 거부문이
    # `적재판 X ≠ 디스크판 X`처럼 같은 값 둘을 찍어 스스로를 반박한다.
    try:
        loaded = epoch.loaded()
        if loaded == epoch.UNKNOWN:
            raise epoch.EpochError(
                "이 프로세스는 시작할 때 자기 판을 잡지 못했다 — 낡았는지 "
                "판정할 수 없다")
        disk = epoch.on_disk()
    except epoch.EpochError as e:
        raise StaleEngineError(
            "엔진 판을 확인하지 못했다 — 쓰지 않았다",
            [str(e),
             "엔진 파일을 읽을 수 있는지 확인한 뒤 이 서버를 재기동하고 같은 "
             "요청을 그대로 다시 보내라. 판을 모르는 채로 쓰는 것이 이 관문이 "
             "막으려는 일이므로, 모름은 통과가 아니라 거부다."]) from e
    if loaded == disk:
        return
    raise StaleEngineError(
        "이 프로세스는 낡은 엔진으로 돌고 있다 — 쓰지 않았다",
        [f"적재판 {loaded} ≠ 디스크판 {disk}. 이 프로세스가 뜬 뒤 엔진이 "
         f"교체됐다(갱신 또는 다른 기기의 변경을 받은 pull). 이 서버를 "
         f"재기동한 뒤 같은 요청을 그대로 다시 보내라 — 낡은 코드가 쓰면 "
         f"폐지된 규칙을 단 노드가 조용히 태어나고, 어느 프로세스가 그랬는지 "
         f"소급 확인이 불가능하다."])


class mutation_lock:
    """엔진이 내는 **모든 working-tree 변경**을 직렬화하는 잠금 — 노드
    쓰기(write)·보호영역 조작(approvals)·동기화(sync·update)가 같은 잠금을 쓴다.

    다른 잠금을 쓰면, 반려가 마지막으로 전제를 확인한 뒤 파일을 덮기까지 사이에
    정상 쓰기나 데몬의 `pull(rebase)`가 끼어들어 **검토하지 않은 변경이
    파괴된다**. 잠금 순서는 언제나 이 잠금 → 대장 잠금(`ledger_append`)이다
    (모든 모듈이 같은 순서라 교착이 없다). 다른 기기에서 사람이 직접 부른
    `git pull`만 이 잠금 밖이며, 그것은 `expect`·전제 재확인이 맡는다.

    **판본 관문이 여기 선다.** 잠금이 모든 의미론적 변경의 유일한 길목이므로,
    관문을 여기 두면 쓰는 쪽이 그것을 잊을 수 없다 — 호출부마다 걸면 새 쓰기
    통로가 생길 때 빠뜨리는 것이 언제나 가능해진다."""

    def __enter__(self):
        path = mutation_lock_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        self._f = open(path, "w")
        lock_exclusive(self._f)
        try:
            _fence()
        except BaseException:
            # `__enter__`가 던지면 `with`는 `__exit__`를 부르지 않는다 —
            # 여기서 풀지 않으면 관문에 걸릴 때마다 잠금이 새어 다음 호출이
            # 영영 막힌다.
            self.__exit__(None, None, None)
            raise
        return self

    def __exit__(self, *exc):
        # 해제가 던져도 핸들은 닫는다 — 안 닫으면 예외 종류가 바뀌어 호출부가
        # 재기동 안내 대신 errno를 받고, 핸들도 참조계수에 기대게 된다.
        try:
            unlock(self._f)
        finally:
            self._f.close()
        return False

TS_FMT = "%Y-%m-%d %H:%M (KST)"          # Mechanism §2 2항 — frontmatter 시각
TS_RE = r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2} \(KST\)$"
# Mechanism §2 1항 — YYMMDD-ssss-rrrrrrrr. 무작위부는 8자이며, 4자인 구형
# id도 그대로 유효하다(길이가 다르므로 신·구가 충돌할 수 없다).
#
# 이것은 유효성 검사가 아니라 **판별자**다 — "이 문자열은 id인가 이름인가"를
# 가르는 자리로 여섯 곳에서 쓰인다(resolve·_score_key·_live_locate·_as_links·
# _check_edges·read_node). 넓히면 id로 읽히는 노드 제목의 집합이 넓어지므로,
# 넓히는 폭은 4|8 두 값으로 한정한다.
ID_RE = r"^\d{6}-[0-9a-z]{4}-[0-9a-z]{4}(?:[0-9a-z]{4})?$"
RID_RE = r"^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[0-9a-f]{4}-[0-9a-f]{12}$"
CASE_RE = r"^CASE-\d{4}-\d+$"            # Mechanism §4 3항 — CASE-<연도>-<일련>
# Mechanism §2 4항 — drafter는 모델명(`fable-5`·`gpt-5.6-sol`) 또는 `user`·`agent`.
# 표면 스키마(mcp_server.Drafter)와 계약 검사가 **같은 식**을 쓴다 — 둘이 갈리면
# 표면이 거부한 값을 손 편집·내부 호출이 앉히고 검증기는 통과시킨다.
DRAFTER_RE = r"^[a-z][a-z0-9.\-]{0,39}$"
AUTHORS = ("user", "agent")              # Mechanism §2 4항


def now_kst() -> str:
    """frontmatter 시각 — 기기 시간대와 무관하게 KST로 적는다."""
    return datetime.now(KST).strftime(TS_FMT)


def now_iso() -> str:
    """대장 기록의 `at` — ISO 8601 유지 (Mechanism §2 2항 단서)."""
    return datetime.now(KST).replace(microsecond=0).isoformat()


def b36(n: int, width: int) -> str:
    s = ""
    while n:
        s = B36[n % 36] + s
        n //= 36
    return s.rjust(width, "0")


def new_node_id(when: datetime | None = None) -> str:
    """생성 시 자동 부여 (Mechanism §2 1항). 날짜·경과초는 created와 같은
    KST 시계에서 뽑는다.

    구판은 여기서 **기존 id 전수와 대조**했다. 그 대조는 frontmatter를 전부
    열어야 성립하므로 25,000 노드에서 생성 하나가 전역 잠금을 6.4초 더 쥐었다
    (실측). 대조를 싸게 하는 길은 없었다 — "오늘 만든 것만 보자"도 어느 것이
    오늘 것인지가 파일 안에 있어 성립하지 않고, 파일 mtime은 clone·복원이
    덮어써 가장 필요할 때 가장 틀린다.

    그래서 담보를 **폭**으로 옮겼다. 앞 11자가 결정적이라 충돌은 같은 초
    안에서만 일어나는데, 무작위 8자(36**8 ≈ 2**41.4)면 같은 초에 23만 건을
    부여해도 충돌이 1%에 못 미친다. 남는 위험은 사후 전수 대조가 잡고, 겹친
    id를 만나면 표면이 읽기도 쓰기도 거부한다(v3.7.2).

    대조를 되살리고 싶어지면 먼저 이것을 보라: 중복 id의 실제 발생원은 이
    함수가 아니라 **파일 복제**(사본 만들기·복원·병합의 수동 해결)이며, 그
    경로는 여기를 거치지 않는다. 대조는 그것을 막지 못했다."""
    d = when or datetime.now(KST)
    secs = d.hour * 3600 + d.minute * 60 + d.second
    return f"{d:%y%m%d}-{b36(secs, 4)}-{''.join(random.choices(B36, k=8))}"


def sha256_file(p: Path | str) -> str:
    return "sha256:" + hashlib.sha256(Path(p).read_bytes()).hexdigest()


def sha256_bytes(b: bytes) -> str:
    return "sha256:" + hashlib.sha256(b).hexdigest()


# ── 디렉터리 엔트리 내구화 (Mechanism §1-2 7항 · §3 1항) ──────────────────

def fsync_dir(d: Path) -> None:
    """디렉터리 엔트리를 내구화 — 파일만 fsync하면 rename·create·unlink가 전원
    차단에 유실될 수 있다(POSIX). 디렉터리 fsync 개념이 없는 파일시스템(EINVAL·
    ENOTSUP)과 열 권한이 없는 디렉터리(EACCES·EPERM)만 넘기고, 그 밖의 오류는
    올려 쓰기가 내구화 없이 성공한 척하지 못하게 한다.

    **Windows에서는 의도된 no-op이다.** 디렉터리를 `os.open`으로 열 수 없고
    (EACCES — 예전에는 그 예외를 삼켜 조용히 no-op이었다), NTFS는 메타데이터를
    저널링하므로 rename·create는 전원 차단 뒤에도 옛 엔트리나 새 엔트리 중
    하나로 남는다(찢긴 엔트리는 없다). 다만 **마지막 변경의 내구성은 보장하지
    않는다** — 저널이 디스크에 닿기 전에 전원이 나가면 직전 상태로 돌아갈 수
    있다. 프로세스 사망에는 두 OS 모두 안전하다(커널 캐시가 살아 있다)."""
    if os.name == "nt":
        return
    try:
        fd = os.open(str(d), os.O_RDONLY)
    except FileNotFoundError:
        return                      # 이미 사라진 디렉터리 — 내구화할 대상이 없다
    except OSError as e:
        if e.errno in (errno.EINVAL, errno.ENOTSUP, errno.EACCES, errno.EPERM):
            return
        raise
    try:
        os.fsync(fd)
    except OSError as e:
        if e.errno not in (errno.EINVAL, errno.ENOTSUP):
            raise
    finally:
        os.close(fd)


def mkdirs_durable(d: Path) -> list[Path]:
    """`d`까지의 없는 조상을 만들고, **만든 각 디렉터리의 부모를 fsync**한다.
    `mkdir(parents=True)` 뒤 자신만 fsync하면 그 엔트리를 소유한 부모가 내구화되지
    않아 전원 차단 시 디렉터리째 유실된다(그 안의 파일은 기록 뒤에도 사라진다).
    반환: 새로 만든 디렉터리(깊은 순) — 갱신 트랜잭션 rollback이 되돌릴 대상이다."""
    missing = []
    p = d
    while not p.exists():
        missing.append(p)
        if p.parent == p:
            break
        p = p.parent
    created = []
    for q in reversed(missing):     # 얕은 곳부터 만든다
        q.mkdir(exist_ok=True)
        created.append(q)
        fsync_dir(q.parent)         # 그 엔트리를 소유한 부모를 내구화
    created.reverse()
    return created


def atomic_write(path: Path, data: bytes) -> None:
    """원자 교체 + 내구화: 임시 파일 fsync → `os.replace` → **부모 디렉터리
    fsync**. 호출부가 이 뒤에 그 파일을 가리키는 대장 기록을 남기므로, 엔트리가
    기록보다 먼저 내구화돼야 전원 차단 뒤 '기록은 있는데 파일은 없는' 상태가
    생기지 않는다. 권한은 mkstemp 기본이다 — 기존 권한을 보존해야 하는 갱신은
    `update._write_atomic`을 쓴다."""
    mkdirs_durable(path.parent)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise
    fsync_dir(path.parent)


# Windows CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP — 콘솔 창 없이, 부모와 떨어져
_DETACHED = 0x08000200


def spawn_worker(module: str, *, env: dict | None = None, stdin: bytes | None = None,
                 stderr=None) -> subprocess.Popen:
    """이 vault 엔진의 모듈을 **분리 프로세스**로 띄우고 기다리지 않는다 — 훅과
    표면은 곧바로 돌아간다. 부모가 끝나도 자식은 남는다(POSIX는 새 세션, Windows는
    새 프로세스 그룹이며 콘솔 창을 만들지 않는다).

    부모의 표준 입출력은 물려주지 않는다. stdio로 도는 MCP 표면의 파이프를 자식이
    쥐면 표면의 입력을 가로채거나 표면의 종료를 붙잡는다. `stdin`을 주면 그 바이트만
    넘기고 닫는다. `stderr`는 열린 파일을 주면 거기 쓰고, 주지 않으면 버린다."""
    child_env = {**os.environ, "OSK_VAULT_ROOT": str(ROOT),
                 "PYTHONPATH": str(Path(__file__).resolve().parents[1]), **(env or {})}
    proc = subprocess.Popen(
        [sys.executable, "-m", module],
        stdin=subprocess.DEVNULL if stdin is None else subprocess.PIPE,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL if stderr is None else stderr,
        env=child_env, cwd=ROOT, shell=False, start_new_session=os.name != "nt",
        creationflags=_DETACHED if os.name == "nt" else 0)
    if stdin is not None:
        try:
            proc.stdin.write(stdin)
        finally:
            proc.stdin.close()
    return proc


_PS_BARE = re.compile(r"[\w\-./\\:=+%]+")


def shell_join(argv) -> str:
    """사람이나 에이전트가 제 터미널에 붙여 넣을 **한 줄 명령** — Windows는 PowerShell,
    그 밖은 POSIX 셸의 인용이다. 경로를 문자열에 이어 붙이면 공백 든 경로가 여러
    인자로 갈린다. 특수 문자가 없는 인자는 그대로 두고, 인용한 명령 이름 앞에는
    PowerShell의 호출 연산자 `&`를 둔다."""
    argv = [str(a) for a in argv]
    if os.name != "nt":
        return shlex.join(argv)
    quoted = [a if _PS_BARE.fullmatch(a) else "'" + a.replace("'", "''") + "'" for a in argv]
    return ("& " if quoted and quoted[0] != argv[0] else "") + " ".join(quoted)


def cli_command(*args: str) -> str:
    """이 vault의 `osk.cli`를 부르는 **한 줄 명령** — 에이전트가 제 셸에 그대로
    붙인다. vault 루트와 엔진 자리를 명령 안에 실으므로 작업 폴더·`PYTHONPATH`와
    무관하다."""
    code = (f"import os,runpy,sys;os.environ['OSK_VAULT_ROOT']={str(ROOT)!r};"
            f"sys.path.insert(0,{str(Path(__file__).resolve().parents[1])!r});"
            "runpy.run_module('osk.cli',run_name='__main__')")
    return shell_join([sys.executable, "-c", code, *args])


def posix_rel(p: Path, relative_to: Path) -> str:
    r"""경로를 **기기 비의존 표기**의 상대 경로 문자열로 — `resolve_in_root`의 역방향.

    `str(Path)`는 OS 표기를 낸다. Windows에서는 구분자가 역슬래시(`_engine\osk`)로
    나오는데, 이 체계의 규칙은 전부 슬래시로 쓰인다(매니페스트 `DENY _engine/`,
    pin 대상 `Scope/W2/`, 대장의 `path`). 그래서 OS 표기를 그대로 비교에 넘기면
    규칙이 **조용히 안 걸린다** — 실측으로 Windows에서 DENY 8개가 0건을 제외했고
    `move_node`의 pin 거부가 통과했다.

    트리는 기기 사이에서 공유되므로 키도 기록도 기기에 의존하면 안 된다.
    비교에 쓰거나 대장에 적는 경로는 전부 이 함수를 거친다."""
    return p.relative_to(relative_to).as_posix()


def resolve_in_root(rel_or_abs: str | Path) -> Path | None:
    """대장·사건부에 적힌 경로 문자열을 **vault 안으로 봉쇄** 해석한다.
    대장은 다기기 병합으로 임의의 내용이 유입될 수 있는 신뢰 밖 입력이므로,
    `..`·절대 경로·심볼릭 링크로 루트를 벗어나면 None(=해석 실패)이다.
    실패는 호출부에서 언제나 거부·불일치 쪽으로 처리한다."""
    try:
        p = Path(rel_or_abs)
        if p.is_absolute() and p.is_relative_to(ROOT):
            p = Path(adapt_path(p.relative_to(ROOT).as_posix(), SPACE_ROOTS))
        elif not p.is_absolute():
            p = Path(adapt_path(str(p), SPACE_ROOTS))
        cand = p if p.is_absolute() else ROOT / p
        real = Path(os.path.realpath(cand))
        root = Path(os.path.realpath(ROOT))
        if real != root:
            real.relative_to(root)      # 벗어나면 ValueError
        return real
    except (ValueError, OSError, TypeError):
        return None


def _within(base: Path, rel: str) -> Path | None:
    """rel을 base 안으로 봉쇄한 **정규 절대 경로** — 아니면 None. release 증빙
    key와 (다기기 병합되는) 저널 path는 **신뢰 밖 입력**이므로, 어느 I/O 전에도
    이 봉쇄를 통과한다. 두 겹으로 막는다: ①`.`/`..` segment·절대경로를 문자열
    단계에서 거부(정규화 전 판정 우회 차단 — `docs/../00_Scope/`로 바닥 재진입
    금지) ②남은 심볼릭 재배치는 realpath로 흡수해 base 안인지 확인. 반환값의
    base-상대(canonical)에만 floor·I/O를 걸어야 한다."""
    try:
        p = Path(rel)
        if not p.parts or p.is_absolute()\
                or any(seg in ("..", ".") for seg in p.parts):
            return None
        broot = Path(os.path.realpath(base))
        real = Path(os.path.realpath(base / p))
        if real == broot:
            return None                          # base 자신은 파일 대상이 아니다
        real.relative_to(broot)                  # 벗어나면 ValueError
        return real
    except (ValueError, OSError, TypeError):
        return None


def _canon_rel(base: Path, rel: str) -> str | None:
    """봉쇄된 canonical base-상대 경로(posix) — 탈출·재진입·**경로 정체성 훼손**은
    None. floor·I/O 판정은 raw 문자열이 아니라 이 canonical 경로에 건다. realpath가
    lexical 경로와 다르면(경로 구성요소에 symlink) 다른 프레임워크 파일로 write가
    재지정된 것이므로 거부한다 — symlink 탈출만이 아니라 ROOT **내부** alias도 막는다
    (예: `docs/SETUP.md -> _engine/osk/core.py`). 정션과 (Windows에서는) 대소문자만 바뀐 이름도
    realpath가 다른 자리를 내므로 같이 걸린다 — 갱신과 반려가 이 계약을 공유한다."""
    p = _within(base, rel)
    if p is None:
        return None
    try:
        canon = p.relative_to(Path(os.path.realpath(base))).as_posix()
    except ValueError:
        return None
    if canon != Path(rel).as_posix():            # lexical ≠ realpath → symlink 재지정
        return None
    return canon


# ── rid — 시각 48비트 + 시퀀스 12비트 (생성 단조 표식) ────────────────────

def _rid_parts(rid: str) -> tuple[int, int]:
    h = rid.replace("-", "")
    return int(h[0:12], 16), int(h[12:16], 16) & 0x0FFF


def _rid_key(rid: str) -> tuple[int, int, str]:
    ms, seq = _rid_parts(rid)
    return (ms, seq, rid)


def _make_rid(ms: int, seq: int) -> str:
    rb = random.getrandbits(62)
    b = ms.to_bytes(6, "big") + ((0x7 << 12 | seq).to_bytes(2, "big")) \
        + ((0b10 << 62 | rb).to_bytes(8, "big"))
    h = b.hex()
    return f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}"


def _next_rid(max_rid: str | None) -> str:
    """대장의 정본상 최대 rid보다 반드시 큰 rid — 병합으로 물리 순서가
    섞여 있어도 최대값이 바닥이다."""
    now_ms = int(time.time() * 1000)
    if max_rid:
        last_ms, last_seq = _rid_parts(max_rid)
        if now_ms > last_ms:
            return _make_rid(now_ms, 0)
        seq = last_seq + 1
        if seq > 0xFFF:
            return _make_rid(last_ms + 1, 0)
        return _make_rid(last_ms, seq)
    return _make_rid(now_ms, 0)


# ── 대장 읽기·손상 진단 ──────────────────────────────────────────────────

_LINE_SEP_ESC = str.maketrans({"\x85": r"\u0085", "\u2028": r"\u2028", "\u2029": r"\u2029"})


def _parse_lines(text: str, path: Path) -> list[dict]:
    # 행 경계는 "\n"뿐이다 — `splitlines()`는 U+2028·U+2029·U+0085에서도 끊는데,
    # 기록은 `ensure_ascii=False`라 그 문자가 필드 값에 날것으로 선다.
    out = []
    for i, line in enumerate(text.split("\n")):
        if not line.strip():
            continue
        try:
            rec = json.loads(line)
        except json.JSONDecodeError as e:
            raise ValueError(
                f"대장 손상(부분 행) {path}:{i+1} — 수동 복구 절차 필요") from e
        if not isinstance(rec, dict):
            raise ValueError(
                f"대장 손상(기록이 아닌 행) {path}:{i+1} — 수동 복구 절차 필요")
        out.append(rec)
    return out


def ledger_read(path: Path) -> list[dict]:
    """파일 순서 그대로 반환한다. 판정의 정본은 인과(parents)이며,
    유산 구간(앵커 이전)은 파일 순서가 인과다."""
    if not path.exists():
        return []
    return _parse_lines(path.read_text(encoding="utf-8"), path)


def ledger_damage(records: list[dict], path: Path | str = "") -> list[str]:
    """기록의 **동일성**이 깨진 구조 손상 목록 — rid 부재·형식 위반·중복.
    정규화로 흡수하면 안 되는(해소를 새 기록에 맡길 수 없는) 이상이며,
    Mechanism §3 8항의 수동 복구 대상이다. 빈 목록이면 건전."""
    out, seen = [], {}
    where = f"{path}:" if path else "행"
    for i, r in enumerate(records):
        rid = r.get("rid")
        if rid is None:
            out.append(f"{where}{i+1} rid 부재 (node={r.get('node')})")
            continue
        if not re.match(RID_RE, str(rid)):
            out.append(f"{where}{i+1} rid 형식 위반: {rid}")
            continue
        if rid in seen:
            out.append(f"{where}{i+1} rid 중복: {rid} (앞선 행 {seen[rid]+1})")
        seen[rid] = i
    return out


def damaged_nodes(records: list[dict]) -> set[str]:
    """구조 손상에 연루된 노드 — 판정은 fail-closed(미확정)."""
    bad, seen = set(), {}
    for i, r in enumerate(records):
        rid, node = r.get("rid"), r.get("node")
        if rid is None or not re.match(RID_RE, str(rid)):
            if node:
                bad.add(node)
            continue
        if rid in seen:
            for j in (seen[rid], i):
                if records[j].get("node"):
                    bad.add(records[j]["node"])
        seen[rid] = i
    return bad


# ── 인과 DAG ─────────────────────────────────────────────────────────────

def effective_parents(records: list[dict]) -> dict[str, list[str]]:
    """rid → 부모 rid 목록. **항상 비순환**으로 정규화한다.

    - 앵커(첫 parents 보유 기록) 이전의 유산 기록만 파일 순서를 인과로
      간주한다. 앵커 이후의 parents 부재 기록은 고립 루트다.
    - parents 원소 중 자기 자신·미지 rid·파일 순서상 뒤(전방 참조)는
      잘라낸다 — 손상이 순환을 만들어 기록을 판정에서 소거하는 것을 막고,
      잘린 기록은 head로 남아 새 기록으로 봉합된다.
    - 구조 손상 기록(rid 부재·형식 위반)은 DAG에 넣지 않는다. 그 노드는
      damaged_nodes가 fail-closed로 잡는다.
    """
    anchor = ledger_anchor_index(records)
    order = {}
    for i, r in enumerate(records):
        rid = r.get("rid")
        if rid is not None and re.match(RID_RE, str(rid)) and rid not in order:
            order[rid] = i
    out: dict[str, list[str]] = {}
    prev_rid = None
    for i, r in enumerate(records):
        rid = r.get("rid")
        if rid is None or not re.match(RID_RE, str(rid)):
            continue
        if isinstance(r.get("parents"), list):
            out[rid] = [p for p in r["parents"]
                        if isinstance(p, str) and p and p != rid
                        and p in order and order[p] < i]
        elif anchor is None or i < anchor:
            out[rid] = [prev_rid] if prev_rid else []   # 유산 구간만 파일 순서
        else:
            out[rid] = []                               # 앵커 이후 = 고립 루트
        prev_rid = rid
    return out


def heads(records: list[dict]) -> list[str]:
    """어느 기록의 부모도 아닌 rid 목록 — 병합·손상 직후에는 둘 이상이다."""
    par = effective_parents(records)
    referenced = {p for ps in par.values() for p in ps}
    return [rid for rid in par if rid not in referenced]


def _ancestors(rid: str, par: dict[str, list[str]]) -> set[str]:
    seen: set[str] = set()
    stack = list(par.get(rid, []))
    while stack:
        x = stack.pop()
        if x in seen:
            continue
        seen.add(x)
        stack.extend(par.get(x, []))
    return seen


def causal_maxima(records: list[dict], value: str,
                  par: dict[str, list[str]] | None = None,
                  field: str = "node",
                  candidate=None) -> list[dict]:
    """같은 키를 가진 기록 중 인과 극대(다른 기록의 조상이 아닌 것). 유일하면
    그것이 판정 기록, 그 밖에는 비교 불능 — fail-closed.

    `field`로 키를 고른다: 서명 기록부는 `node`, 라우팅 대장은 `session`.

    `candidate(r)`를 주면 그 술어를 만족하는 기록만 **후보**로 삼되, 조상 관계는
    여전히 **전체 기록의 DAG**로 계산한다. 후보를 목록에서 미리 빼고 부르면 그
    기록이 맡고 있던 parents 간선이 함께 끊겨(effective_parents가 미지 parent를
    자른다) 남은 기록들이 서로 비교 불능인 거짓 분기가 된다 — 걸러야 할 것은
    후보 자격이지 인과 사슬이 아니다."""
    par = effective_parents(records) if par is None else par
    mine = [r for r in records if r.get(field) == value and r.get("rid") in par]
    if candidate is not None:
        mine = [r for r in mine if candidate(r)]
    rids = {r["rid"] for r in mine}
    anc = {r["rid"]: _ancestors(r["rid"], par) for r in mine}
    return [r for r in mine
            if not any(r["rid"] in anc[o] for o in rids if o != r["rid"])]


def unresolved_nodes(records: list[dict], field: str = "node") -> set[str]:
    """판정이 성립하지 않는 키 — 인과 극대가 유일하지 않거나(분기·순환 잔재)
    구조 손상에 연루된 것. 판정은 보수적으로 미확정."""
    par = effective_parents(records)
    keys = {r.get(field) for r in records if r.get(field)}
    out = set(damaged_nodes(records)) if field == "node" else set()
    for n in keys:
        if n in out:
            continue
        if len(causal_maxima(records, n, par, field)) != 1:
            out.add(n)
    return out


def resolve_one(records: list[dict], value: str, field: str) -> dict | None:
    """인과 극대가 유일할 때만 그 기록을 돌려준다 — 그 밖에는 None(미확정)."""
    maxima = causal_maxima(records, value, None, field)
    return maxima[0] if len(maxima) == 1 else None


def ledger_anchor_index(records: list[dict]) -> int | None:
    """새 계약(명시 parents)의 도입 지점 — 첫 parents 보유 기록의 색인.
    이후 기록은 스키마 검증 대상이다(유산 구간은 호환 경계)."""
    for i, r in enumerate(records):
        if isinstance(r.get("parents"), list):
            return i
    return None


def ledger_append(path: Path, record: dict, expect=None) -> dict:
    """모든 `_ledger/` jsonl 공통 (Mechanism §3):
    잠금 → 전체 판독 → **구조 손상이면 거부** → parents = 현재 head 전부
    (병합 봉합) → rid = 정본 최대 rid로부터 단조 생성 → 행 단위 원자
    append·fsync(대장을 처음 만들었으면 그 디렉터리 엔트리까지).

    `expect`는 **잠금 안에서** 방금 읽은 기록으로 전제조건을 다시 보는 선택적
    검사다 — `expect(records)`가 문자열을 돌려주면 그것을 사유로 거부한다.
    호출부가 잠금 밖에서 검사하고 append 하는 사이에 다른 기기의 기록이
    동기화로 들어오면, 그것을 못 본 행이 그 기록의 **인과 자식**으로 붙어
    분기가 stale로 드러나지 않고 조용히 대체한다(그리고 행에 적은 전제가
    거짓 진술이 된다). 검사와 append를 같은 잠금에 두어야 그 창이 닫힌다."""
    return ledger_extend(path, [record], expect)[0]


def ledger_extend(path: Path, new: list[dict], expect=None) -> list[dict]:
    """`ledger_append`의 여러 기록판 — 한 잠금·한 fsync로 차례로 잇는다.
    첫 기록은 현재 head 전부를, 다음 기록은 바로 앞 기록을 `parents`로 받는다."""
    if not new:
        return []
    for record in new:
        record.setdefault("at", now_iso())
    mkdirs_durable(path.parent)
    with open(path, "a+", encoding="utf-8") as f:
        lock_exclusive(f)
        try:
            f.seek(0)
            text = f.read()
            records = _parse_lines(text, path)
            dmg = ledger_damage(records, path)
            if dmg:
                raise ValueError(
                    f"대장 손상 — 수동 복구 절차 필요 (Mechanism §3 8항): "
                    + "; ".join(dmg[:5]))
            if expect is not None:
                why = expect(records)
                if why:
                    raise ValueError(why)
            last = max((r["rid"] for r in records if r.get("rid")),
                       key=_rid_key, default=None)
            hs, rows = heads(records), []
            for record in new:
                record["rid"] = last = _next_rid(last)
                record["parents"], hs = hs, [last]
                # 줄 구분 문자는 이스케이프해 쓴다 — 같은 JSON 값이고, `splitlines()`로
                # 판독하는 구판 기기가 동기화로 받은 이 행에서 대장 손상을 보지 않는다.
                rows.append(json.dumps(record, ensure_ascii=False).translate(_LINE_SEP_ESC))
            # 판독을 통과했으니 개행 없는 꼬리는 완결 기록이다(찢긴 꼬리는 위에서
            # 손상으로 거부된다) — 개행을 채우지 않으면 새 기록이 그 행에 붙는다.
            lead = "\n" if text and not text.endswith("\n") else ""
            f.write(lead + "\n".join(rows) + "\n")
            f.flush()
            os.fsync(f.fileno())
            if not text:
                # 이번에 처음 만든 대장 — 행만 fsync하면 이름 자체가 전원 차단에
                # 유실돼, 이 기록을 전제로 한 다음 단계가 근거 없이 남는다.
                fsync_dir(path.parent)
        finally:
            unlock(f)
    return new
