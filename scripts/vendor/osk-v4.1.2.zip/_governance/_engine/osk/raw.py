"""osk.raw — `_raw/` 세션 기록의 라운드 append.

구현 근거: 헌법 4조 3~4항(세션을 가진 scope의 `_raw/`·append-only),
시행령 §2(세션당 정본 하나·포착 범위·라운드 제목), Mechanism §8 3항(라운드
제목 문법과 숫자 H2 escape)·§9 4항(접두부 보존 append).

라운드 index는 **엔진 전속**이다. 호출자가 번호를 고르면 중복·역행이 계약
위반으로 들어오는데(Mechanism §8 3항), 그것은 `[[경로#index]]` 라운드 참조의
동일성을 깨뜨린다 — 이미 쓴 근거가 다른 라운드를 가리키게 된다. 번호를 부여할
수 있는 자리는 기존 기록 전체를 읽는 이곳뿐이므로 여기서 부여한다.

바이트는 `secrets.write_raw`를 지난다 — 비밀값 치환과 접두부 보존을 우회하는
`_raw/` 쓰기 경로를 두지 않기 위해서다(Mechanism §9).
"""
from __future__ import annotations
from .core import SCOPE
import json
import re
from pathlib import Path

from .core import ROOT, mutation_lock, posix_rel, resolve_in_root, sha256_file, sha256_bytes
# `write`의 `_title_errors`·`_name_collision`을 그대로 쓴다 — 파일명 이식성
# 규칙(Windows 예약명·링크 파서 충돌·ext4 바이트 상한·대소문자 접기)의 정본은
# 한 벌이어야 한다. 여기서 다시 쓰면 두 규칙이 조용히 갈라진다.
from . import graph, secrets, write

# 라운드 제목 — 행 머리의 `## ` 뒤에 양의 십진 index 하나(Mechanism §8 3항).
# escape된 제목(`\## 3`)은 `^## `에 걸리지 않으므로 이 하나로 판정이 끝난다.
#
# 꼬리 공백에 `\r`을 함께 센다. 기록은 바이트 그대로 읽으므로(`read_exact`),
# CRLF가 섞인 파일에서 `[ \t]*$`만 쓰면 제목 행이 하나도 안 걸려 **라운드가
# 0개로 보인다** — 중복·역행 검출과 `damaged` 보고가 통째로 눈을 감는다.
# 쓰기는 바이트를 보존하고 판독은 관대하게: 이 파일의 규율이 그것이다.
_ROUND = re.compile(r"^## (\d+)[ \t\r]*$", re.M)

# escape 대상 — 대화 본문에 섞인 "숫자 H2와 같은 모양"의 행. 이미 escape된
# 행(`\## 3`)도 함께 잡아 backslash를 하나 더 얹는다. 그래야 escape/unescape가
# 정확히 역연산이 되고, 원문에 `\## 3`이 있어도 회상에서 복원된다.
_NUMERIC_H2 = re.compile(r"^(\\*)(## \d+[ \t\r]*)$", re.M)


def escape_numeric_h2(text: str) -> str:
    """대화 본문의 숫자 H2를 라운드 제목으로 오독하지 않게 첫 `#`을 escape한다
    (Mechanism §8 3항). 되돌리는 것은 `unescape_numeric_h2`다."""
    return _NUMERIC_H2.sub(lambda m: "\\" + m.group(1) + m.group(2), text)


def unescape_numeric_h2(text: str) -> str:
    """회상 시 escape를 되돌린다 — `escape_numeric_h2`의 역연산."""
    return re.sub(r"^\\(\\*)(## \d+[ \t\r]*)$",
                  lambda m: m.group(1) + m.group(2), text, flags=re.M)


def read_exact(p) -> str:
    """기록 파일을 **바이트 그대로** 읽는다 — 개행을 접지 않는다.

    `read_text`의 universal newlines가 `\\r\\n`·`\\r`을 `\\n`으로 바꾼다. 그
    문자열로 전문을 재조립하면 `secrets.write_raw`의 접두부 판정(`read_bytes`)을
    **영원히** 통과하지 못한다 — 대화 한 줄에 `\\r`이 섞이는 순간 그 기록은
    append가 막히고, `_raw/`는 append-only라 되돌릴 수단이 없다(실측 재현).

    Mechanism §8 3~4항도 라운드 범위와 상태 해시를 "정규화하지 않은 UTF-8
    바이트"로 정의한다 — 읽는 자리가 그 정의를 따라야 쓰는 자리와 맞는다."""
    from pathlib import Path as _P
    return _P(p).read_bytes().decode("utf-8")


def rounds(text: str) -> list[int]:
    """기록에 실재하는 라운드 index를 파일 순서대로 돌려준다."""
    return [int(m.group(1)) for m in _ROUND.finditer(text)]


def _next_index(text: str) -> int:
    """다음 라운드 index. 기존 index의 **중복·역행은 계약 위반**이므로(시행령
    §2 7항 · Mechanism §8 3항) 그 위에 덧쓰지 않고 거부한다 — 손상된 기록에
    이어 붙이면 `[[경로#index]]`가 어느 라운드를 가리키는지 정해지지 않는다."""
    seen = rounds(text)
    if seen != sorted(set(seen)) or (seen and seen[0] != 1):
        raise write.WriteError(
            "기록 손상 — 라운드 index가 1부터 단조 증가하지 않는다",
            [f"index 열: {seen} — 중복·역행·시작번호는 계약 위반이므로 "
             f"이어 쓰지 않는다 (시행령 §2 7항)"])
    return (seen[-1] + 1) if seen else 1


def record_path(scope: str, record: str) -> Path:
    """Read the existing record; new records live in hidden non-Markdown storage."""
    d = ROOT / SCOPE / scope / "_raw"
    return _record_file(d / f"{record}.md")


def _record_pair(path: Path | str) -> tuple[Path, Path]:
    """Confined physical path and its old Markdown alias. No content conversion."""
    p = resolve_in_root(path)
    if p is None or graph.space_of(p)[0] != "raw":
        raise write.WriteError("vault 밖 또는 `_raw/` 밖 경로 — 기록을 열지 않았다")
    requested = Path(path) if Path(path).is_absolute() else ROOT / path
    if requested.absolute() != p:
        raise write.WriteError("raw 저장 경로의 심볼릭 링크·우회 경로는 허용하지 않는다")
    if p.parent.name == ".records" and p.suffix.lower() == ".txt":
        d, stem = p.parent.parent, p.stem
    elif p.parent.parent.name == ".records" and p.name == "record.txt":
        d, stem = p.parent.parent.parent, p.parent.name
    elif p.suffix.lower() == ".md" or not p.suffix:
        d, stem = p.parent, p.stem if p.suffix else p.name
    else:
        raise write.WriteError("지원하지 않는 raw 기록 경로")
    old_name = write._name_collision(d, stem, unique=True)
    old = d / (old_name or f"{stem}.md")
    new_dir = d / ".records"
    new_name = write._name_collision(new_dir, old.stem, ".txt", unique=True)
    long_name = write._name_collision(new_dir, old.stem, None, unique=True)
    if new_name and long_name:
        raise write.WriteError("raw 파일·디렉터리 별칭이 함께 있다 — 정본을 고를 수 없다")
    if long_name or (not new_name and len((old.stem + ".txt").encode("utf-8")) > write._MAX_FILENAME_BYTES):
        # A legacy 252-byte stem fits .md, but not .txt. Keep its whole name
        # as a directory component, avoiding a lossy rename or alias registry.
        new = new_dir / (long_name or old.stem) / "record.txt"
    else:
        new = new_dir / (new_name or f"{old.stem}.txt")
    # A symlink must not redirect the alias into another scope or outside raw.
    for candidate in (old, new):
        resolved = resolve_in_root(candidate)
        if resolved is None or resolved != candidate or graph.space_of(resolved) != graph.space_of(p):
            raise write.WriteError("raw 별칭이 저장 구획을 벗어났다")
    return old, new


def _record_file(path: Path | str) -> Path:
    old, new = _record_pair(path)
    if old.exists() and new.exists():
        raise write.WriteError("raw 구·신 저장본이 함께 있다 — 덮어쓰거나 임의로 합치지 않았다")
    return old if old.exists() else new


def _migrate_file(path: Path) -> Path:
    """Caller holds mutation_lock. Rename preserves bytes and survives retry."""
    old, new = _record_pair(path)
    current = _record_file(path)  # Detect conflicts even for a replay with no append.
    if current == old and old.is_file():
        digest = sha256_file(old)
        new.parent.mkdir(parents=True, exist_ok=True)
        old.rename(new)
        if sha256_file(new) != digest:
            raise write.WriteError("raw 이관 후 해시 불일치 — 성공으로 처리하지 않았다")
    return new


def migrate(*, apply: bool = False) -> dict:
    """Preview or move existing raw files. Nodes and raw content are never edited."""
    with mutation_lock():
        plans = []
        for scope in _scope_names():
            directory = ROOT / SCOPE / scope / "_raw"
            for path in sorted(directory.rglob("*")):
                if path.is_file() and path.suffix.lower() == ".md":
                    old, new = _record_pair(path)
                    _record_file(path)  # Preflight every conflict before any rename.
                    plans.append({"from": posix_rel(old, ROOT), "to": posix_rel(new, ROOT),
                                  "hash": sha256_file(old), "bytes": old.stat().st_size})
        if apply:
            for plan in plans:
                _migrate_file(ROOT / plan["from"])
        return {"ok": True, "applied": apply, "count": len(plans), "files": plans}


def canonical_ref(ref: str) -> str:
    """Compare old wiki coordinates and new plain coordinates by the same record."""
    value = ref.strip()
    if value.startswith("[[") and value.endswith("]]"):
        value = value[2:-2].strip()
    path, sep, anchor = value.split("|", 1)[0].partition("#")
    path = path.strip()
    if re.match(r"^https?://", path) or "/_raw/" not in path.replace("\\", "/"):
        return ref  # Node IDs and node links keep their existing identity.
    _, physical = _record_pair(path)
    return posix_rel(physical, ROOT) + (sep + anchor if sep else "")


def _round_body(chunk: str) -> str:
    """라운드에서 제목 줄을 뺀 내용. 재시도가 만드는 중복은 번호만 다르므로,
    같음의 판정은 번호가 아니라 내용으로 한다."""
    return chunk.partition("\n")[2].strip()


def _reject_replay(prior: str, spans: dict, blocks: list) -> None:
    """직전 꼬리와 바이트가 같은 배치는 재시도로 보고 거부한다.

    at-least-once 전송에서는 응답이 유실되면 호출자가 같은 배치를 다시 보낸다.
    그런데 `_raw/`는 append-only라 그렇게 생긴 중복은 **지울 수단이 없다** —
    표면에도 삭제 도구가 없다. 조용히 접지 않고 거부하는 이유는, 접으면 성공을
    보고하면서 아무것도 안 쓰는 것이 되어 호출자가 무슨 일이 있었는지 모르기
    때문이다. 거부하고 무엇을 봐야 하는지 알려 호출자가 판정하게 한다.

    비교는 **치환 뒤** 내용으로 한다 — 저장된 쪽은 통로에서 치환됐으므로,
    비밀값이 든 라운드의 재시도는 치환 전으로 견주면 다른 것이 되어 빠져나간다."""
    n = len(blocks)
    if len(spans) < n:
        return
    incoming = [_round_body(secrets.filter_text(b)[0]) for b in blocks]
    tail = [_round_body(prior[s:e])
            for _, (s, e) in sorted(spans.items())[-n:]]
    if tail != incoming:
        return
    last = sorted(spans)[-n:]
    raise write.WriteError(
        "재시도로 보이는 중복 — 쓰지 않았다",
        [f"직전 라운드 {last}의 내용과 바이트가 같다. 응답을 못 받아 다시 "
         f"보내는 것이라면 이미 기록됐다 — `read_raw`로 목차를 보고 마지막 "
         f"index를 확인하라. 정말 같은 대화가 다시 오간 것이면 그 사실이 "
         f"드러나게 라운드를 고쳐 보낸다."])


_CODEX_V2 = "<!-- osk-capture: codex-user-items-v2 -->"
_CODEX_V3 = "<!-- osk-capture: codex-terminal-v3 "
_DIALOGUE_V1 = "<!-- osk-capture: dialogue-v1 "
_CLAUDE_PREFIX = "<!-- osk-capture: claude-inherited-v1 "


def storage_error(path: str, text: str) -> str | None:
    """Check a changed raw record, without exposing its payload in diagnostics."""
    p = Path(path)
    if "_raw" not in p.parts or not p.parts or p.parts[0] not in {"00_Scope", "= Scope", "Scope"}:
        return None
    if p.suffix.lower() == ".md":
        return "visible Markdown raw; migrate to hidden .txt storage"
    if any(_round_body(text[s:e]).startswith((_CODEX_V2, _CODEX_V3))
           for s, e in _round_spans(text).values()):
        return "legacy capture codec; restore dialogue-v1 from the native transcript"
    return None


def storage_violations() -> list[str]:
    errors = []
    for directory in (ROOT / SCOPE).glob("*/_raw"):
        for p in directory.rglob("*"):
            if p.is_file() and p.suffix.lower() in {".md", ".txt"}:
                rel = posix_rel(p, ROOT)
                error = storage_error(rel, read_exact(p))
                if error:
                    errors.append(f"{rel}: {error}")
    return errors


def inherited_prefix(path: Path) -> dict | None:
    """The immutable raw header survives cursor loss and vault copies."""
    if not path.exists():
        return None
    with path.open("r", encoding="utf-8") as f:
        line = f.readline().rstrip("\n")
    if not line.startswith(_CLAUDE_PREFIX):
        return None
    if not line.endswith(" -->"):
        raise write.WriteError("damaged Claude inheritance header")
    value = json.loads(line[len(_CLAUDE_PREFIX):-4])
    if not isinstance(value, dict) or not isinstance(value.get("rounds"), list):
        raise write.WriteError("damaged Claude inheritance manifest")
    return value


def _block(index: int, user: str, agent: str, *, codex_native: bool = False,
           codex_id: str | None = None, dialogue_id: str | None = None) -> str:
    """한 라운드 = user 발화 + 그에 속한 에이전트 응답(시행령 §2 7항)."""
    stamp = f"{_CODEX_V2}\n\n" if codex_native else ""
    if codex_id is not None:
        stamp = _CODEX_V3 + json.dumps(codex_id) + " -->\n\n"
    if dialogue_id is not None:
        stamp = _DIALOGUE_V1 + json.dumps(dialogue_id) + " -->\n\n"
    return (f"## {index}\n\n{stamp}"
            f"### user\n\n{user.rstrip()}\n\n"
            f"### agent\n\n{agent.rstrip()}\n")


def codex_capture_order(path: Path, codex_v1: dict, codex_v2: dict,
                        saved_ids: tuple[str, ...] = ()) -> list[str]:
    """Recover append order after historical backfill, even without local cursors."""
    if not path.exists():
        return []
    text = read_exact(path)
    ids = []
    for start, end in _round_spans(text).values():
        body = _round_body(text[start:end])
        header = body.splitlines()[0]
        prefix = next((s for s in (_CODEX_V3, _DIALOGUE_V1) if header.startswith(s)), None)
        if prefix:
            if not header.endswith(" -->"):
                raise ValueError("damaged Codex capture identity")
            value = json.loads(header[len(prefix):-4])
            if not isinstance(value, str) or not value:
                raise ValueError("damaged Codex capture identity")
        else:
            native = header == _CODEX_V2
            codec = codex_v2 if native else codex_v1
            candidates = [saved_ids[len(ids)]] if len(ids) < len(saved_ids) else codec
            matches = []
            # ponytail: cursorless legacy matching scans the codec; index body
            # hashes if large legacy archives make this recovery path costly.
            for rid in candidates:
                if rid in ids or rid not in codec:
                    continue
                pair = codec[rid]
                expected = _block(1, escape_numeric_h2(pair['user']),
                                  escape_numeric_h2(pair['agent']), codex_native=native)
                if body == _round_body(secrets.filter_text(expected)[0]):
                    matches.append(rid)
            if len(matches) != 1:
                raise ValueError("legacy Codex capture identity missing, changed or ambiguous")
            value = matches[0]
        ids.append(value)
    if len(ids) != len(set(ids)):
        raise ValueError("duplicate Codex capture identity")
    return ids


# scope 열거·space 표기 판정은 `graph`가 한 벌로 소유한다(`wm`도 같은 것을 쓴다).
_scope_names, _space_list, _scope_of_space = (
    graph.scope_names, graph.space_list, graph.scope_of_space)

# 착지 판정(형식 → 실재 → 결속)은 `write.resolve_landing`이 한 벌로 소유한다.
_CONFINE = ("`_raw/`는 세션당 정본 하나이므로(시행령 §2 1항) 한 세션의 기록을 "
            "다른 scope로 번지게 하지 않는다 —")


def append_rounds(session: str, record: str, pairs: list,
                  space: str | None = None, *, replay_prefix: bool = False,
                  codex_v1: dict | None = None,
                  codex_v2: dict | None = None,
                  dialogue_v1: dict | None = None,
                  inherited: dict | None = None) -> dict:
    """라운드 여럿을 **한 번의 쓰기로** 잇는다.

    배치가 필요한 이유는 성능이 아니라 원자성이다. 라운드마다 따로 쓰면 세
    번째에서 거부됐을 때 앞의 둘만 남아, `_raw/`가 "있었던 대화의 일부"가
    된다 — 표면이 부분 성공을 만들지 않는 것과 같은 규율을 이 경로에도
    건다(Mechanism §6-2 3항). index는 배치 안에서도 엔진이 이어 매긴다.

    착지는 세션 라우팅이 정한다 — 결속이 없으면 `space`를 요구하고, 성공하면
    그 scope로 세션을 확정한다. `space`의 표기는 `create_node`와 같은 군집
    전체 경로(`"00_Scope/W1"`)다 — 같은 값이 같은 뜻이어야 호출자가
    `overview`의 `clusters`를 그대로 옮겨 쓴다."""
    if (codex_v1 is not None or codex_v2 is not None) and not replay_prefix:
        raise ValueError("Codex capture versions require prefix replay")
    if dialogue_v1 is not None and not replay_prefix:
        raise ValueError("dialogue capture requires prefix replay")
    if codex_v2 is not None and codex_v1 is None:
        raise ValueError("Codex v3 capture requires both historical codecs")
    if inherited is not None and (not replay_prefix or codex_v1 is not None):
        raise ValueError("inherited prefixes require Claude capture replay")
    if not pairs:
        raise write.WriteError("빈 배치 — 쓰지 않았다", ["이을 라운드가 없다"])
    norm = []
    for i, r in enumerate(pairs):
        u = r.get("user") if isinstance(r, dict) else (r[0] if r else "")
        a = r.get("agent") if isinstance(r, dict) else (r[1] if len(r) > 1 else "")
        if not (u or "").strip() or not (a or "").strip():
            raise write.WriteError(
                "라운드는 user 발화와 그 응답을 함께 담는다",
                [f"{i + 1}번째 라운드의 user·agent 중 빈 쪽이 있다 — 한 라운드는 "
                 f"user 발화와 그에 속한 에이전트 응답의 쌍이다 (시행령 §2 7항)"])
        norm.append((u, a))
    errs = write._title_errors(record)      # 기록 이름이 곧 파일명이다
    if errs:
        raise write.WriteError("기록 이름 부적격 — 쓰지 않았다", errs)
    # 세션 키는 착지 판정보다 먼저 본다 — 결속은 파일 쓰기 뒤에 오므로
    # 여기서 막지 않으면 부분 성공이 된다.
    errs = write.ephemeral_session_errors(session) + write.routing_errors(session)
    if errs:
        raise write.WriteError("세션 키 부적격 — 쓰지 않았다", errs)

    with mutation_lock():
        dest, bound = write.resolve_landing(session, space, _CONFINE)
        if not dest:
            raise write.WriteError(
                "착지 미정 — 쓰지 않았다",
                [f"세션 `{session}`의 scope 결속이 없다. `space`를 주면 그 자리에 "
                 f"기록하고 결속을 확정한다. 가능한 space: {_space_list()}"])
        if dest not in _scope_names():
            # 결속이 가리키는 scope가 사라진 경우 — `space`는 이미
            # `resolve_landing`이 검사했으므로 여기 남는 것은 낡은 결속뿐이다.
            raise write.WriteError(
                "결속이 가리키는 scope가 없다 — 쓰지 않았다",
                [f"세션 `{session}`은 `{SCOPE}/{dest}`에 결속돼 있으나 그 scope가 "
                 f"없다. 가능한 space: {_space_list()}"])

        p = record_path(dest, record)
        prior = read_exact(p) if p.exists() else ""
        if prior and inherited_prefix(p) != inherited:
            raise write.WriteError("Claude inheritance manifest changed; raw was not altered")
        if not prior and inherited is not None:
            prior = _CLAUDE_PREFIX + json.dumps(inherited, ensure_ascii=False, sort_keys=True) + " -->\n\n"
        first = _next_index(prior)
        spans = _round_spans(prior)
        # Capture adapters resend the complete completed-round sequence. Compare
        # the durable prefix before appending: a crash after write_raw but before
        # its local cursor is saved must not duplicate append-only evidence.
        replayed, legacy_replayed = [], []
        if replay_prefix:
            if len(spans) > len(norm):
                raise write.WriteError("포착 원본이 저장된 기록보다 짧다", ["원본을 복구한 뒤 재시도하라"])
            for pair, (idx, (s, e)), (u, a) in zip(pairs, sorted(spans.items()), norm):
                readable = _round_body(prior[s:e]).startswith(_DIALOGUE_V1)
                extended = codex_v2 is not None and _round_body(prior[s:e]).startswith(_CODEX_V3)
                native = codex_v1 is not None and _round_body(prior[s:e]).startswith(_CODEX_V2 + "\n")
                if readable:
                    selected = (dialogue_v1 or {}).get(pair["id"])
                    if selected is None:
                        raise write.WriteError("dialogue-v1 replay requires its recorded codec")
                    u, a = selected["user"], selected["agent"]
                elif codex_v1 is not None and not extended:
                    # Select the recorded codec before comparing. Never fall
                    # back after a mismatch: v2 rich input must remain checked.
                    # The marker lives in raw so cursor loss/copies retain it.
                    legacy = ((codex_v2 or {}).get(pair["id"]) if native and codex_v2 is not None
                              else pair if native else codex_v1.get(pair["id"]))
                    if legacy is None:
                        raise write.WriteError("과거 Codex 라운드를 재현할 수 없다", [f"라운드 {idx} — 쓰지 않았다"])
                    u, a = legacy["user"], legacy["agent"]
                    if not native:
                        legacy_replayed.append(idx)
                expected = _block(idx, escape_numeric_h2(u), escape_numeric_h2(a), codex_native=native,
                                  codex_id=pair["id"] if extended else None,
                                  dialogue_id=pair["id"] if readable else None)
                if _round_body(prior[s:e]) != _round_body(secrets.filter_text(expected)[0]):
                    raise write.WriteError("포착 원본과 저장된 접두부가 다르다", [f"라운드 {idx} — 쓰지 않았다"])
                replayed.append(idx)
            norm = norm[len(replayed):]
            if not norm:
                p = _migrate_file(p)
                rel = posix_rel(p.resolve(), ROOT)
                return {"ok": True, "path": rel, "indices": replayed,
                        "round_refs": [f"{rel}#{i}" for i in replayed],
                        "filtered": [], "appended": 0, "codex_v1_rounds": legacy_replayed}
        blocks, indices = [], []
        for n, (u, a) in enumerate(norm):
            pair = pairs[len(replayed) + n]
            if dialogue_v1 is not None:
                selected = dialogue_v1.get(pair["id"])
                if selected is None:
                    raise write.WriteError("missing dialogue capture; wrote no partial batch")
                u, a = selected["user"], selected["agent"]
            indices.append(first + n)
            blocks.append(_block(first + n, escape_numeric_h2(u),
                                 escape_numeric_h2(a), codex_native=codex_v1 is not None,
                                 codex_id=pair["id"] if codex_v2 is not None else None,
                                 dialogue_id=pair["id"] if dialogue_v1 is not None else None))
        if not replay_prefix:
            _reject_replay(prior, spans, blocks)
        if prior and not prior.endswith("\n"):
            prior += "\n"
        # 되돌아온 경로를 쓴다 — 통로가 봉쇄·해소한 그 경로가 실제로 기록된
        # 자리이고, `ROOT`도 해소된 값이라 둘의 상대 계산이 어긋나지 않는다.
        written, hits = secrets.write_raw(
            _migrate_file(p), prior + ("\n" if prior else "") + "\n".join(blocks))

        rel = posix_rel(written, ROOT)
        # `round_ref`를 그대로 돌려준다 — 이 값이 곧 `derived-from`의 비노드
        # 대상 표기다(Mechanism §8 2항). 호출자가 경로와 index를 조립하다
        # 틀리면 근거 배선이 dangling으로 앉는다.
        result = {"ok": True, "path": rel, "indices": replayed + indices,
                  "round_refs": [f"{rel}#{i}" for i in replayed + indices],
                  "filtered": sorted(set(hits))}
        if not bound:
            write.bind_after_write(result, session, dest, "첫 세션 기록에서 확정")
        if replay_prefix:
            result["appended"] = len(indices)
            result["codex_v1_rounds"] = legacy_replayed
        return result


def append_round(session: str, record: str, user: str, agent: str,
                 space: str | None = None) -> dict:
    """라운드 하나 — 표면(`append_raw`)이 부르는 단수형."""
    r = append_rounds(session, record, [{"user": user, "agent": agent}], space)
    return {"ok": True, "path": r["path"], "index": r["indices"][0],
            "round_ref": r["round_refs"][0], "filtered": r["filtered"],
            **({"binding": r["binding"]} if "binding" in r else {})}


def record_state(session: str, record: str, space: str | None = None) -> dict:
    """기록의 현재 상태 — 어댑터가 **이미 기록된 분량을 건너뛰는** 데 쓴다.

    자동 포착의 진짜 위험은 유실이 아니라 중복이다. 훅은 같은 대화에 대해
    여러 번 깨어나는데, 그때마다 처음부터 이어 붙이면 같은 라운드가 다른
    번호로 두 번 앉아 기록이 대화가 아니게 된다. 어느 쪽도 그것을 사후에
    되돌릴 수 없으므로(`_raw/`는 append-only다), 붙이기 전에 세는 자리를
    둔다 — 어댑터는 `rounds`를 읽고 그 뒤부터만 보낸다."""
    dest, bound = write.resolve_landing(session, space, _CONFINE)
    if not dest or dest not in _scope_names():
        return {"ok": True, "bound": bound, "scope": None, "path": None,
                "exists": False, "rounds": 0, "next_index": 1, "damaged": False}
    p = record_path(dest, record)
    text = read_exact(p) if p.exists() else ""
    seen = rounds(text)
    try:
        nxt, damaged = _next_index(text), False
    except write.WriteError:
        # 손상 기록에 다음 번호를 알려주면 어댑터가 그 위에 이어 붙이려 든다.
        # 셀 수 없다는 사실을 그대로 낸다 — append도 같은 이유로 거부한다.
        nxt, damaged = None, True
    return {"ok": True, "bound": bound, "scope": dest,
            "path": posix_rel(p.resolve(), ROOT) if p.exists() else None,
            "exists": p.exists(), "rounds": len(seen),
            "next_index": nxt, "damaged": damaged}


# ── 명시 회상 (시행령 §2 5항) ────────────────────────────────────────────
#
# `_raw/`는 작업 검색에서 빠진다(헌법 11조 3항). 빠진 것을 도구 없이 읽으려면
# 경로를 손으로 찾아야 하는데, 기록은 엔진 계약의 언어로 쓰여 있다 — 라운드
# 제목, escape된 숫자 H2, `[[경로#N]]` 좌표. 그 언어를 아는 쪽이 읽는 자리를
# 내주는 것이 맞다. 검색이 아니라 **좌표로 여는** 회상이므로 11조 3항의 제외와
# 충돌하지 않는다.


def parse_ref(ref: str) -> tuple[str, int | None]:
    """`[[경로#N]]` · `경로#N` · `경로` → (경로, index). 저장된 표기가 곧
    입력이다 — 노드의 `derived-from`에서 값을 그대로 옮겨 올 수 있어야 한다."""
    s = (ref or "").strip()
    if s.startswith("[[") and s.endswith("]]"):
        s = s[2:-2].strip()
    path, sep, idx = s.rpartition("#")
    if not sep or not idx.isdigit():
        return s, None
    return path.strip(), int(idx)


def _raw_file(path: str) -> Path:
    """`_raw/` 안의 실재 파일로 해소한다. 봉쇄는 쓰기와 **같은 규율**이다 —
    읽기라고 느슨하게 두면 `[[../../어딘가]]`가 vault 밖을 읽는 창이 된다."""
    from .core import resolve_in_root
    from . import graph
    p = resolve_in_root(path)
    if p is None:
        raise write.WriteError("vault 밖 경로 — 읽지 않았다", [f"경로: {path}"])
    if graph.space_of(p)[0] != "raw":
        raise write.WriteError(
            "`_raw/` 밖 경로 — 이 도구로 읽지 않는다",
            [f"`{path}`는 세션 기록이 아니다. 노드는 `read_node`로 읽는다"])
    p = _record_file(p)
    if not p.is_file():
        raise write.WriteError("없는 기록", [f"그런 세션 기록이 없다: {path}"])
    return p


def _round_spans(text: str) -> dict:
    """index → (시작, 끝). 라운드 범위는 그 제목 행의 첫 바이트부터 다음 숫자
    라운드 제목의 직전까지이고, 다음이 없으면 파일 끝까지다(Mechanism §8 3항)."""
    ms = list(_ROUND.finditer(text))
    return {int(m.group(1)):
            (m.start(), ms[i + 1].start() if i + 1 < len(ms) else len(text))
            for i, m in enumerate(ms)}


def _recalled(chunk: str) -> str:
    """파일 위의 라운드 범위 → 회상 본문. escape를 되돌리고(Mechanism §8 3항)
    범위 경계의 꼬리 개행을 턴다. 목차와 본문이 **같은 함수**를 지나야 둘이
    보고하는 길이가 어긋나지 않는다."""
    return unescape_numeric_h2(chunk).rstrip("\n")


def _preview(chunk: str, width: int = 60) -> str:
    """라운드의 첫 알맹이 한 줄 — 목차가 파일 전문을 쏟지 않게 한다."""
    body = _round_body(chunk).splitlines()
    if (body[:3] == [_CODEX_V2, "", "### user"] or len(body) >= 3
            and body[0].startswith((_CODEX_V3, _DIALOGUE_V1)) and body[1:3] == ["", "### user"]):
        chunk = "\n".join(body[2:])  # Only the header; user quotations stay visible.
    for line in chunk.splitlines():
        s = line.strip()
        if s and not _ROUND.match(s) and not s.startswith("#"):
            return s[:width] + ("…" if len(s) > width else "")
    return ""


def round_hash(stored: str) -> str:
    """Hash stored evidence, excluding only append separators (not a reading view)."""
    return sha256_bytes(stored.rstrip("\n").encode())


def read_round(ref: str, max_chars: int = 20000, view: str = "full",
               query: str | None = None) -> dict:
    """좌표 하나를 연다. `index`가 없으면 그 기록의 **목차**를 낸다 — 전문을
    쏟지 않는 것이 기본값이어야 세션 기록 하나가 맥락을 삼키지 않는다.

    돌려주는 본문은 escape를 되돌린 것이다(Mechanism §8 3항 "회상할 때 이를
    되돌린다") — 기록에 남은 `\\## 3`은 원래 대화의 `## 3`이었다."""
    if view not in {"review", "full"}:
        raise ValueError("view must be review or full")
    path, index = parse_ref(ref)
    if query is not None and (view != "review" or index is None):
        raise ValueError("query requires view=review and an exact #N round")
    p = _raw_file(path)
    text = read_exact(p)
    rel = posix_rel(p, ROOT)
    spans = _round_spans(text)
    if index is None:
        # 목차의 `chars`는 **회상했을 때 오는 길이**다. 파일 위 원시 span 길이를
        # 내면 escape와 꼬리 개행만큼 어긋나, 예산을 재려고 목차를 본 호출자가
        # 실제 응답과 다른 수를 쥔다(감사 지적).
        return {"ok": True, "path": rel, "rounds": len(spans),
                "index": [{"index": i,
                           "chars": len(_recalled(text[s:e])),
                           "preview": _preview(text[s:e])}
                          for i, (s, e) in sorted(spans.items())]}
    if index not in spans:
        raise write.WriteError(
            "없는 라운드",
            [f"`{rel}`에 라운드 {index}이(가) 없다. 있는 라운드: "
             f"{sorted(spans) if spans else '없음'}"])
    stored = text[spans[index][0]:spans[index][1]]
    chunk = _recalled(stored)
    identity = {"ok": True, "path": rel, "index": index,
                "round_ref": canonical_ref(f"{rel}#{index}"), "hash": round_hash(stored)}
    if view == "review":
        from . import raw_view
        return {**identity, **raw_view.project(chunk, max_chars, query)}
    cut = len(chunk) > max_chars
    return {**identity, "view": "full",
            "chars": len(chunk), "truncated": cut,
            "text": chunk[:max_chars] if cut else chunk}


def list_records(space: str) -> dict:
    """한 scope의 세션 기록 목록 — 좌표를 모를 때 여기서 시작한다."""
    scope = _scope_of_space(space)
    if not scope or scope not in _scope_names():
        raise write.WriteError(
            "없는 scope", [f"`{space}`는 scope가 아니다. 가능한 space: "
                          f"{_space_list()}"])
    d = ROOT / SCOPE / scope / "_raw"
    out = []
    files = sorted({*d.glob("*.md"), *(d / ".records").glob("*.txt"),
                    *(d / ".records").glob("*/record.txt")})
    for candidate in files:
        f = _record_file(candidate)
        text = read_exact(f)
        out.append({"record": _record_pair(f)[0].stem, "path": posix_rel(f, ROOT),
                    "rounds": len(rounds(text)), "chars": len(text)})
    return {"ok": True, "scope": scope, "records": out}
