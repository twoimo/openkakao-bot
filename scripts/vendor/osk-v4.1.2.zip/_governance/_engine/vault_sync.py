"""_engine/vault_sync.py — 데몬이 구동하는 git 동기화 헬퍼(이벤트 구동).

git은 서브프로세스 + 하드 타임아웃으로 격리하고, 요청 서빙 경로를 절대 블록하지 않게
호출부(sync_daemon)에서 스케줄한다. Obsidian 그래프의 배율만 다른 충돌은 로컬 값을
보존한다. 그 밖의 충돌은 원복(rebase --abort)·보고한다 — 사용자 데이터 임의 선택 금지.

동기화 대상은 `SYNC_BRANCH`(=main) **고정**이다. 원격 연산은 전부 `origin main`을
명시하며, HEAD가 다른 곳에 있으면 `ensure_branch`가 안전할 때만 되돌린다.
운용 문서는 docs/SETUP.md.

git 환경은 `LC_ALL=C`(영어 메시지 고정 → 출력 분류 안정화) + `GIT_TERMINAL_PROMPT=0`
(자격증명 프롬프트로 매달리지 않게)로 고정한다.

각 함수는 (ok_or_changed: bool, status: str, detail: str)를 반환한다.
status ∈ {"ok","conflict","rejected","error"}.
"""
import json
import math
import os
import subprocess
import uuid
from contextlib import contextmanager

_GIT_ENV = {**os.environ, "LC_ALL": "C", "LANG": "C", "GIT_TERMINAL_PROMPT": "0",
            "GIT_EDITOR": "true"}  # 자동 해결 뒤 rebase --continue도 비대화식이다.

# CREATE_NO_WINDOW: 데몬이 pythonw(콘솔 없음)로 돌 때, 콘솔 서브시스템인 git.exe를 spawn하면
# Windows가 매번 새 콘솔 창을 할당한다. sync 1회가 git을 여러 번 호출하므로 검은 콘솔이
# 여러 개 깜빡인다 → 무창 플래그로 억제. POSIX에선 0(무영향).
_NO_WINDOW = 0x08000000 if os.name == "nt" else 0


def _git(vault_root, args, timeout, *, text=True):
    return subprocess.run(
        ["git", "-C", str(vault_root), *args],
        capture_output=True, text=text, timeout=timeout, env=_GIT_ENV,
        creationflags=_NO_WINDOW,
    )


def is_git_repo(vault_root, timeout=10) -> bool:
    """vault_root가 저장소 **루트**일 때만 참. `--is-inside-work-tree`는 하위
    디렉터리도 통과시켜, OSK_VAULT_ROOT를 잘못 잡으면 상위 저장소 전체를
    커밋·push하게 된다."""
    try:
        r = _git(vault_root, ["rev-parse", "--show-toplevel"], timeout)
        top = r.stdout.strip()
        if r.returncode != 0 or not top:
            return False
        return os.path.realpath(top) == os.path.realpath(str(vault_root))
    except Exception:
        return False


def has_remote(vault_root, timeout=10) -> bool:
    try:
        r = _git(vault_root, ["remote"], timeout)
        return r.returncode == 0 and bool(r.stdout.strip())
    except Exception:
        return False


def _head(vault_root, timeout):
    r = _git(vault_root, ["rev-parse", "HEAD"], timeout)
    return r.stdout.strip() if r.returncode == 0 else None


# 동기화 대상 브랜치는 **고정**이다. 데몬이 HEAD를 따라가면, 어떤 세션이
# 잠깐 다른 브랜치를 checkout해 둔 사이에 그 브랜치가 vault의 정본인 것처럼
# 커밋·push된다 — 정본이 조용히 갈라지는 경로다.
SYNC_BRANCH = "main"


def current_branch(vault_root, timeout=10):
    """현재 브랜치명. detached HEAD면 None."""
    r = _git(vault_root, ["symbolic-ref", "--quiet", "--short", "HEAD"], timeout)
    if r.returncode not in (0, 1):       # 1만 정상 detached HEAD다
        raise RuntimeError(f"git branch 판독 실패: {r.stderr.strip()[-600:]}")
    return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None


def _tracked_dirty(vault_root, timeout):
    """**추적 파일**의 수정·스테이징만 본다. 미추적 파일은 더러움으로 치지 않는다 —
    vault에서 미추적 파일은 대개 새로 생긴 노드이고, checkout은 그것을 그대로
    데리고 넘어가므로 main에서 커밋되는 것이 옳다. 반대로 추적 파일의 수정은
    누군가 그 브랜치에서 진행 중인 작업일 수 있어 옮기면 안 된다."""
    r = _git(vault_root, ["status", "--porcelain", "-z"], timeout)
    if r.returncode != 0:
        raise RuntimeError(f"git status 실패: {r.stderr.strip()[-600:]}")
    return any(e[:2] != "??" for e in r.stdout.split("\0") if e.strip())


def ensure_branch(vault_root, branch=SYNC_BRANCH, timeout=30):
    """동기화 전에 HEAD를 `branch`로 맞춘다 — 여기서 실패하면 동기화하지 않는다.

    이미 그 브랜치면 아무것도 하지 않는다. 다른 브랜치·detached라면 **추적
    파일이 수정돼 있지 않을 때만** 전환한다. 수정돼 있으면 전환하지 않고
    거부한다 — 배경 데몬이 남의 진행 중 작업을 다른 브랜치로 끌고 가거나
    stash로 감추는 것은 사용자 데이터에 대한 파괴적 자동 조치다(이 모듈의
    기본 원칙). 미추적 파일은 새 노드이므로 함께 넘어가는 것이 옳다."""
    try:
        pending = _in_progress(vault_root, timeout)
        if pending:
            return (False, "error", f"{pending} 진행 중 — 동기화하지 않는다(수동 개입 필요)")
        cur = current_branch(vault_root, timeout)
        if cur == branch:
            return (False, "ok", "")
        where = f"'{cur}'" if cur else "detached HEAD"
        if _tracked_dirty(vault_root, timeout):
            return (False, "error",
                    f"{where}에 있고 추적 파일이 수정돼 있다 — {branch}로 전환하지 "
                    f"않았다. 진행 중인 작업일 수 있어 옮기지 않으며, 동기화 대상은 "
                    f"{branch} 고정이므로 이 상태로는 동기화하지 않는다")
        v = _git(vault_root, ["rev-parse", "--verify", "--quiet", branch], timeout)
        if v.returncode != 0:
            return (False, "error", f"로컬에 {branch} 브랜치가 없다 — 동기화하지 않았다")
        c = _git(vault_root, ["checkout", branch], timeout)
        if c.returncode != 0:
            return (False, "error",
                    f"{branch} 전환 실패: " + (c.stdout + c.stderr).strip()[-600:])
        return (True, "ok", f"{where} → {branch} 전환")
    except subprocess.TimeoutExpired:
        return (False, "error", f"git branch 확인 timeout ({timeout}s)")
    except Exception as e:  # noqa: BLE001
        return (False, "error", repr(e))


def _in_progress(vault_root, timeout):
    """사용자가 끝내야 할 git 작업. worktree별 git 디렉터리와 미병합 index를 본다.
    충돌을 이미 stage했어도 작업 표식이 남아 있으면 데몬이 대신 완료하지 않는다."""
    r = _git(vault_root, ["rev-parse", "--absolute-git-dir"], timeout)
    if r.returncode != 0 or not r.stdout.strip():
        raise RuntimeError(f"git 작업 상태 판독 실패: {r.stderr.strip()[-600:]}")
    for name in ("rebase-merge", "rebase-apply", "MERGE_HEAD", "CHERRY_PICK_HEAD",
                 "REVERT_HEAD", "sequencer", "BISECT_START"):
        if os.path.exists(os.path.join(r.stdout.strip(), name)):
            return name
    r = _git(vault_root, ["ls-files", "--unmerged", "-z"], timeout)
    if r.returncode != 0:
        raise RuntimeError(f"git 미병합 index 판독 실패: {r.stderr.strip()[-600:]}")
    return "미병합 index" if r.stdout else None


def _in_rebase(vault_root, timeout) -> bool:
    return _in_progress(vault_root, timeout) in ("rebase-merge", "rebase-apply")


def commit_local(vault_root, message, timeout=60):
    """add -A → commit(변경 없으면 'nothing to commit'을 ok로 처리). push는 하지 않는다.
    pull 전에 로컬을 먼저 commit해 두면 autostash 없이 rebase가 깔끔히 처리한다.
    진행 중 git 작업에서는 커밋을 거부한다 — add -A가 충돌을 해결한 것으로 만든다."""
    try:
        pending = _in_progress(vault_root, timeout)
        if pending:
            return (False, "error",
                    f"{pending} 진행 중 — 커밋하지 않는다(수동 개입 필요)")
        added = _git(vault_root, ["add", "-A"], timeout)
        if added.returncode != 0:
            return (False, "error", (added.stdout + added.stderr).strip()[-600:])
        c = _git(vault_root, ["commit", "-m", message], timeout)
        if c.returncode != 0 and "nothing to commit" not in (c.stdout + c.stderr).lower():
            return (False, "error", (c.stdout + c.stderr).strip()[-600:])
        return (True, "ok", "")
    except subprocess.TimeoutExpired:
        return (False, "error", f"git commit timeout ({timeout}s)")
    except Exception as e:  # noqa: BLE001
        return (False, "error", repr(e))


def _resolve_graph_scale(vault_root, timeout):
    """유일한 충돌이 graph.json이고 양쪽 설정이 scale 외에는 같을 때만 해결한다.

    rebase의 stage 3(theirs)가 재적용 중인 **로컬 커밋**이다. JSON을 재작성하지
    않고 그 blob 그대로 고른다. 검색식·색상 등 다른 설정, 추가/삭제·형식 변경,
    노트와의 혼합 충돌은 여기서 결정하지 않는다.
    """
    path = ".obsidian/graph.json"
    r = _git(vault_root, ["ls-files", "--unmerged", "-z"], timeout)
    if r.returncode != 0:
        return False
    entries = [entry.split("\t", 1) for entry in r.stdout.split("\0") if entry]
    if len(entries) != 3 or any(len(e) != 2 or e[1] != path for e in entries):
        return False
    stages = [entry[0].split() for entry in entries]
    if (any(len(s) != 3 or s[0] != "100644" for s in stages)
            or {s[2] for s in stages} != {"1", "2", "3"}):
        return False

    def unique_object(pairs):
        obj = dict(pairs)
        if len(obj) != len(pairs):
            raise ValueError("중복 JSON 키")
        return obj

    settings = []
    for stage in (2, 3):
        blob = _git(vault_root, ["show", f":{stage}:{path}"], timeout, text=False)
        if blob.returncode != 0:
            return False
        try:
            # blob은 UTF-8이다. OS 기본 디코더·개행 변환을 피하고, 해석 실패도 원복한다.
            obj = json.loads(blob.stdout.decode("utf-8"), object_pairs_hook=unique_object)
            if not isinstance(obj, dict):
                return False
            scale = obj.pop("scale", None)
            if type(scale) not in (int, float) or not math.isfinite(scale) or scale <= 0:
                return False
            # JSON의 bool과 number도 구별한다(True == 1에 기대지 않는다).
            settings.append(json.dumps(obj, sort_keys=True, allow_nan=False))
        except (ValueError, TypeError, OverflowError):
            return False
    if settings[0] != settings[1]:
        return False
    for args in (["checkout", "--theirs", "--", path], ["add", "--", path]):
        if _git(vault_root, args, timeout).returncode != 0:
            return False
    return True


@contextmanager
def fetch_snapshot(vault_root, timeout=60):
    """Fetch without changing the worktree; pin one result until rebase finishes.

    A unique ref avoids another fetch replacing FETCH_HEAD between commands.
    It also keeps the object reachable for GC. Never write shared FETCH_HEAD.
    """
    ref = f"refs/osk-sync/{uuid.uuid4().hex}"
    snapshot, status, detail = None, "error", ""
    try:
        try:
            # pull --rebase computes this BEFORE fetch changes origin/main's
            # reflog. Keep the replay boundary as well as the destination SHA.
            tracking = f"refs/remotes/origin/{SYNC_BRANCH}"
            r = _git(vault_root, ["merge-base", "--fork-point", tracking,
                                  SYNC_BRANCH], timeout)
            fork_point = r.stdout.strip() if r.returncode == 0 else None
            if r.returncode not in (0, 1):
                # A first sync may have no tracking ref or even no local commit.
                refs = [_git(vault_root, ["show-ref", "--verify", "--quiet", name], timeout)
                        for name in (tracking, f"refs/heads/{SYNC_BRANCH}")]
                if any(x.returncode not in (0, 1) for x in refs) or all(x.returncode == 0 for x in refs):
                    raise RuntimeError(f"fork point 확인 실패: {r.stderr.strip()[-600:]}")
            r = _git(vault_root, ["fetch", "--no-write-fetch-head", "origin",
                                  f"refs/heads/{SYNC_BRANCH}:{ref}"], timeout)
            if r.returncode:
                detail = (r.stdout + r.stderr).strip()[-600:]
            else:
                r = _git(vault_root, ["rev-parse", "--verify", f"{ref}^{{commit}}"], timeout)
                if r.returncode:
                    detail = (r.stdout + r.stderr).strip()[-600:]
                else:
                    snapshot, status = (r.stdout.strip(), fork_point), "ok"
        except subprocess.TimeoutExpired:
            detail = f"git fetch timeout ({timeout}s)"
        except Exception as e:
            detail = repr(e)
        yield snapshot, status, detail
    finally:
        r = _git(vault_root, ["update-ref", "-d", ref], timeout)
        if r.returncode:
            raise RuntimeError(f"fetch 임시 ref 정리 실패: {r.stderr.strip()[-600:]}")


def pull(vault_root, timeout=60):
    return _rebase(vault_root, ["pull", "--rebase", "origin", SYNC_BRANCH], timeout)


def rebase_snapshot(vault_root, snapshot, timeout=60):
    """Apply a frozen destination and replay boundary under the mutation lock."""
    commit, fork_point = snapshot
    upstream = commit
    try:
        if fork_point:
            r = _git(vault_root, ["merge-base", "--is-ancestor", fork_point, "HEAD"], timeout)
            if r.returncode:
                return False, "error", "fetch 중 로컬 이력이 바뀌어 분기점을 적용할 수 없다"
            r = _git(vault_root, ["merge-base", "--is-ancestor", fork_point, commit], timeout)
            if r.returncode == 1:
                # The remote discarded old upstream commits: replay only ours.
                upstream = fork_point
            elif r.returncode:
                return False, "error", f"원격 분기점 확인 실패: {r.stderr.strip()[-600:]}"
        else:
            # An expired/missing reflog cannot distinguish local work from
            # discarded upstream commits. Only an unambiguous fast-forward is safe.
            r = _git(vault_root, ["merge-base", "--is-ancestor", "HEAD", commit], timeout)
            if r.returncode:
                return False, "error", "분기점을 확인할 수 없어 이력 재적용을 보류한다(수동 개입 필요)"
    except (OSError, subprocess.TimeoutExpired) as e:
        return False, "error", f"분기점 확인 실패: {e}"
    return _rebase(vault_root, ["rebase", "--onto", commit, upstream], timeout)


def _rebase(vault_root, command, timeout):
    """fetch + rebase. 호출 전 로컬 변경은 commit_local로 커밋돼 있어야 한다(autostash 미사용).
    HEAD가 바뀌면 changed=True. 배율만의 충돌은 로컬 값을 보존해 계속하고,
    나머지 충돌은 rebase --abort로 원복하고 ("conflict")로 표면화한다.
    abort가 실패하면 저장소가 충돌 상태로 남으므로 ("error")로 올린다 — 다음 주기가
    충돌 마커를 커밋하지 않게 하기 위해서다."""
    try:
        pending = _in_progress(vault_root, timeout)
        if pending:
            return (False, "error", f"{pending} 진행 중 — pull하지 않는다(수동 개입 필요)")
        before = _head(vault_root, timeout)
        r = _git(vault_root, command, timeout)
        resolved = set()
        while r.returncode != 0 and _in_rebase(vault_root, timeout):
            pick = _git(vault_root, ["rev-parse", "--verify", "REBASE_HEAD"], timeout)
            if (pick.returncode != 0 or pick.stdout in resolved
                    or not _resolve_graph_scale(vault_root, timeout)):
                break
            resolved.add(pick.stdout)  # 같은 커밋에서 멈추면 다시 고르지 않는다.
            r = _git(vault_root, ["rebase", "--continue"], timeout)
        if r.returncode != 0:
            out = (r.stdout + r.stderr)
            low = out.lower()
            if (_in_rebase(vault_root, timeout)
                    or any(s in low for s in ("conflict", "could not apply"))):
                ab = _git(vault_root, ["rebase", "--abort"], timeout)
                if ab.returncode != 0 or _in_rebase(vault_root, timeout):
                    return (False, "error",
                            ("rebase --abort 실패 — 저장소가 충돌 상태다(수동 개입 필요): "
                             + (ab.stdout + ab.stderr).strip())[-600:])
                # 뒤쪽 hint가 파일명을 밀어내지 않게 실제 충돌 진단을 따로 남긴다.
                conflicts = "\n".join(line for line in out.splitlines()
                                      if line.startswith("CONFLICT "))
                return (False, "conflict", (conflicts + "\n" + out.strip()[-600:]).strip())
            return (False, "error", out.strip()[-600:])
        after = _head(vault_root, timeout)
        detail = (f".obsidian/graph.json 배율 충돌 {len(resolved)}개 자동 해결 — 로컬 값 보존"
                  if resolved else "")
        return (before != after, "ok", detail)
    except subprocess.TimeoutExpired:
        return (False, "error", f"git pull timeout ({timeout}s)")
    except Exception as e:  # noqa: BLE001
        return (False, "error", repr(e))


def commit_push(vault_root, message, timeout=60):
    """commit_local → push. push가 non-fast-forward로 거부되면 ("rejected")로 표면화
    (호출부가 pull-rebase 후 재시도한다)."""
    committed, status, detail = commit_local(vault_root, message, timeout)
    if status != "ok":
        return (False, status, detail)
    return push_snapshot(vault_root, SYNC_BRANCH, timeout)


def push_snapshot(vault_root, commit, timeout=60):
    """Push the given ref; the daemon passes a captured SHA, not moving HEAD."""
    try:
        # refspec 명시 — 밀어 넣는 곳이 언제나 origin의 SYNC_BRANCH다.
        p = _git(vault_root, ["push", "origin", f"{commit}:refs/heads/{SYNC_BRANCH}"], timeout)
        if p.returncode != 0:
            out = (p.stdout + p.stderr)
            low = out.lower()
            if "rejected" in low or "non-fast-forward" in low or "fetch first" in low:
                return (False, "rejected", out.strip()[-600:])
            return (False, "error", out.strip()[-600:])
        return (True, "ok", "")
    except subprocess.TimeoutExpired:
        return (False, "error", f"git push timeout ({timeout}s)")
    except Exception as e:  # noqa: BLE001
        return (False, "error", repr(e))
